-- Race Manager - client GE extension (BeamMP bridge + checkpoint editor)
--
-- Multiplayer-only for racing. The BeamMP server (server/RaceManager/main.lua)
-- owns the session state; this extension does what only a client can do:
--   1. Checkpoint editor: place gate-style checkpoints at the local vehicle's
--      position AND heading. Each checkpoint is a FLAT RECTANGLE standing
--      perpendicular to the travel direction - a width (lateral span) by a
--      height (vertical extent, so high banking still gets covered). Both are
--      adjustable globally and per checkpoint from the UI.
--   2. Detect the LOCAL vehicle crossing each gate, in order, by intersecting
--      the frame-to-frame movement segment with that rectangle (the server has
--      no physics access). The last checkpoint placed is the start/finish line;
--      completing the checkpoint sequence and crossing it again scores a lap,
--      which is timed locally and reported upstream on RM_Lap. ONE event for
--      both kinds of session: which laps count is the server's rule, not this
--      file's (qualifying, for one, does not count the first).
--   3. Starting grid: place start positions along the grid, then put the local
--      car on the slot the server assigns and hold it there until GO.
--   4. Receive the server's state broadcasts, reset local lap tracking on
--      session changes, and hand the data to the UI app via guihooks.
--
-- Runs in BeamNG's GE Lua (LuaJIT / Lua 5.1 semantics) and talks to the
-- server through BeamMP's client bridge (TriggerServerEvent / AddEventHandler).
--
-- Author: Phoenix

local M = {}

-- ---------------------------------------------------------------------------
-- Tunables
-- ---------------------------------------------------------------------------
-- One table rather than a local apiece, and that is not a style preference:
-- Lua allows at most 200 locals in a function, the top level of this file IS a
-- function, and it was already within a handful of that ceiling. Going over is
-- not a warning -- the file does not compile, and the whole mod is simply
-- absent. Constants are the cheapest thing to group, so they are grouped.
local TUNE = {
  DEFAULT_WIDTH = 20,    -- meters across the gate (lateral span)
  MIN_WIDTH = 2,
  MAX_WIDTH = 120,
  -- HEIGHT IS UP, DEPTH IS DOWN, both measured from the placement point.
  --
  -- A gate used to be `height` tall CENTERD on where the car was standing, so
  -- half of every gate hung below the road. Making a gate tall enough to see
  -- buried an equal amount of it under the map, and there was no way to have one
  -- without the other. They are separate now: height raises the top bar, depth
  -- lowers the bottom bar.
  --
  -- The default is weighted upward for exactly that reason. The total is the 10
  -- meters it always was; where it sits is what changed.
  DEFAULT_HEIGHT = 8,     -- meters the gate rises ABOVE the placement point
  MIN_HEIGHT = 1,
  MAX_HEIGHT = 100,
  DEFAULT_DEPTH = 2,      -- meters it drops BELOW it
  -- Zero is the floor: the bottom bar reaches down from the placement point or
  -- sits level with it, never above. Lifting it clear was tried and taken back
  -- out; a gate you have to float by hand is a strange thing to ask of somebody
  -- who just wants one on a road.
  MIN_DEPTH = 0,
  MAX_DEPTH = 100,
  EDGE_RADIUS = 0.15,  -- meters; thickness of the drawn rectangle edge
  -- Thickness of a race POLE. Fatter than an editor edge -- this is the one a
  -- driver reads at a hundred miles an hour -- but only just: the first attempt
  -- at 0.35 read as a pair of pillars rather than a gate.
  POLE_RADIUS = 0.18,
  GHOST_ALPHA = 0.35,  -- mesh alpha applied to a ghosted car
  -- HOW HIGH A PLACED THING SITS ABOVE THE GROUND UNDER IT.
  --
  -- A gate placed by DRIVING takes the car's origin, which is roughly this far
  -- up; one placed by ctrl+click takes a raycast hit, which is the terrain
  -- surface itself. That difference is why clicked gates ended up buried and why
  -- a Last Checkpoint reset onto one spawned the car half in the dirt. Both
  -- paths now clear the ground by this much.
  GROUND_CLEAR = 0.5,
  -- Meters a shift+scroll step raises or lowers a selected gate. Small enough to
  -- fine-tune a gate on a crest, big enough to dig one out of the terrain
  -- without spinning the wheel for a minute.
  NUDGE_LIFT_PER_STEP = 0.75,
  -- One press of Raise/Lower. Bigger than a scroll click on purpose: the wheel
  -- is for settling a gate, the buttons are for getting one out of a hillside.
  NUDGE_LIFT_PER_PRESS = 2.0,
  -- Furthest one drag or ctrl+click may move a gate, in meters.
  --
  -- The cursor ray is cast at the world and lands on whatever it hits. Aimed
  -- near the horizon that is terrain kilometers away, so a drag that clipped the
  -- skyline flung the gate somewhere the admin cannot see it, let alone drag it
  -- back. Generous enough to cross any sane arena or straight in one motion.
  NUDGE_MAX_REACH = 500,
  -- Meters the cursor must travel before a drag starts moving anything. A hand
  -- resting on a mouse is never perfectly still, and the raycast jitters over
  -- uneven ground even when it is.
  NUDGE_DRAG_MIN = 0.15,
  -- Frames a panel press suppresses world picking and dragging for. Enough to
  -- cover the button's Lua running a frame or two after the click was seen here,
  -- and far too short for a human to notice: at sixty frames a second this is
  -- gone before the mouse has finished moving off the button.
  NUDGE_UI_GRACE = 3,
  -- How far up a ground probe starts and how far down it looks. The start has to
  -- clear anything a gate might legitimately be standing on (a bridge deck, a
  -- ramp) and the range has to reach the bottom of a ravine.
  -- Heights to look for a BURIED point's surface at, shortest first, so the
  -- lowest surface above it wins and overhead geometry is never reached.
  GROUND_RESCUE_STEPS = { 2, 5, 12, 30, 60, 150 },
  GROUND_PROBE_DOWN = 200,
  -- Reset ghosting. The DURATIONS are not here: they are a league rule, so the
  -- server owns them and broadcasts them (see ghost.rules). What is left is
  -- local presentation and local geometry, which no other client has an opinion
  -- about and which must never differ between two clients in a way that matters.
  GHOST_FADE_OUT_SEC     = 1.0,   -- fade back to solid over the last second
  GHOST_OVERLAP_MARGIN   = 0.25,  -- meters added to every bound before testing
  GHOST_OVERLAP_WARN_SEC = 10.0,  -- blocked this long: warn the driver, tell the server
  -- Last-resort separation when a car cannot be measured at all. Comfortably
  -- larger than the longest vehicle pair, so it is conservative -- but finite,
  -- which is the point: an unmeasurable car far away must not block a ghost
  -- forever.
  GHOST_FALLBACK_RADIUS = 9.0,
  -- Longest a ghost will wait for its car to report a bounding box before
  -- starting the timer anyway.
  GHOST_SETTLE_MAX = 1.0,
  -- Seconds; double-fire guard on the S/F gate. Kept low so even very short
  -- circuits report: this only needs to swallow same-crossing re-fires, not
  -- bound real lap times.
  LAP_DEBOUNCE = 2.0,
  -- Meters a start position may be from the start/finish line and still count as
  -- a grid stretching back from it. Sixty cars at eight meters a row is under
  -- 250, so past this the grid is somewhere else on the circuit and the first
  -- crossing is a part lap (see branch.gridIsOff).
  GRID_ON_LINE_RANGE = 250,
  -- Most cars a generated grid may put in one row. Two is a road-race grid and
  -- an oval's; three and four are short-track and dirt formats.
  GRID_MAX_WIDTH = 8,
  -- Meters a legal reset may move a car before it is treated as a RECOVERY
  -- teleport and undone. A repair in place moves it centimeters; BeamNG's
  -- recover/load-home drops it at a spawn point that is never this close.
  RECOVER_SNAP_RANGE = 25,
  PROGRESS_EVERY = 0.3,   -- seconds between live-position reports
  -- Meters before the start/finish line that the white flag is shown.
  --
  -- A marshal waves it AT you on the approach, not once you have gone past, so
  -- the driver meets the flag before the line rather than reading about it
  -- afterwards. Not measured off the live-position report either: that is
  -- throttled to PROGRESS_EVERY, which at 90 mph is twelve meters between
  -- samples and would show the flag anywhere from here to the line itself.
  WHITE_FLAG_AT = 50,
  -- Live lap clock for the driver's own HUD. Pushed on a slow cadence and
  -- INTERPOLATED in the UI between pushes, which keeps the readout smooth
  -- without a guihook every frame. ~3.3 Hz: responsive enough to resolve a
  -- side-by-side fight, light enough that a full grid does not flood the server.
  LAP_TIME_EVERY = 0.25,
  -- Grid hold enforcement. The client tolerance is deliberately TIGHTER than the
  -- server's 0.5 m: the client checks every frame and the server four times a
  -- second, so the client should normally have pulled the car back before the
  -- server ever sees it move. A correction that reaches the server means the
  -- local guard did not fire, which is worth knowing about.
  HOLD_DRIFT       = 0.75,  -- meters off the settled slot before putting it back
  HOLD_CREEP_SPEED = 0.60,  -- m/s on the slot: a lost freeze, re-pin where it is
  -- A car dropped onto a start position falls onto its suspension. None of the
  -- enforcement above runs until that has finished, or it fights the settling
  -- and the car never comes to rest.
  HOLD_SETTLE_GRACE = 3.0,  -- seconds allowed for a placed car to come to rest
  HOLD_SETTLED_SPEED = 0.20, -- m/s under which a car counts as settled
  -- ...but not before this much of the grace has passed. A car reports no
  -- velocity on the frame it is placed, because it has not started falling yet,
  -- so "it is not moving" means nothing that early and would anchor the car at
  -- the height it was dropped from -- the very thing the settle window exists
  -- to avoid.
  HOLD_SETTLE_MIN  = 1.0,   -- seconds before stillness counts as settled
  HOLD_REPORT_EVERY = 0.25, -- seconds between position reports while held
  HOLD_CORRECT_COOLDOWN = 0.5, -- seconds after a correction before another
  -- Pit stalls. The dwell is what makes a stop cost something: long enough to
  -- be a real decision against carrying damage, short enough not to be a
  -- punishment. The repair lands part-way through so the car is whole before
  -- the driver gets it back.
  PIT_HOLD_SEC   = 5.0,
  -- Seconds spent re-asserting the freeze and the ghost after a stop is
  -- serviced. recoverInPlace reloads the vehicle's Lua VM to do its work and
  -- both of those are vehicle-side calls, so both quietly go with it; this is
  -- how long the mod keeps putting them back. Generous on purpose -- it costs
  -- two calls a frame on one car, and the alternative is a car that is briefly
  -- solid and free to drive in the middle of its own pit stop.
  PIT_SETTLE_SEC = 1.5,
  -- Meters per direction-marker chevron. Small enough that a board reads as a
  -- run of marks rather than a couple of big arrows, large enough to see from
  -- the far end of a straight.
  MARKER_CELL     = 3.0,
  -- Ceiling on marks per board, so an enormous one does not turn into a solid
  -- block of geometry drawn every frame.
  MARKER_MAX_MARKS = 60,
  -- Mark thickness as a fraction of the mark's own size, and how much fatter
  -- the dark outline behind it is drawn.
  MARKER_STROKE   = 0.17,
  MARKER_EDGE     = 1.9,
  -- Shapes (U turn, fork, P) are drawn two to five times larger than a tiled
  -- cell, so they take a thinner ratio to land at a comparable stroke width in
  -- METERS. Sharing one ratio is what made them unreadable. See place() in
  -- render.lua.
  MARKER_SHAPE_STROKE = 0.07,
  PIT_COOLDOWN   = 8.0,   -- before the same stall can trigger again
  PIT_DEPTH      = 3.0,   -- meters along the stall a car counts as being in it
  -- m/s below which the car counts as stopped IN the stall. A pit stop is
  -- something a driver performs, not something that happens to them: the stall
  -- used to trigger on the box alone, so clipping a corner of it at racing
  -- speed froze the car mid-lane. Now you have to bring it to a stop in the box
  -- yourself, and driving through without stopping simply misses the stop.
  -- Same threshold the derby uses for a stationary car, and generous enough to
  -- swallow physics jiggle.
  PIT_STOP_SPEED = 0.7,
  PIT_PROMPT_EVERY = 1.5, -- seconds between "stop in the box" reminders
  -- How high a pit stall's side walls are DRAWN. Not a rule: the height half of
  -- pit.inside excludes nobody, so the walls are kept low and out of the way
  -- while the footprint, which is the part that decides, is drawn honestly.
  -- Unused since a stall became two poles: the poles take the layout's gate
  -- height so they can be raised like every other marker on the track. Kept
  -- because it is the wall height paint.pitFloor's box wants if the footprint
  -- is ever drawn again.
  PIT_WALL_H     = 1.4,
  START_SLOT_LEN  = 4.6,  -- meters; roughly one car long
  START_SLOT_WIDE = 2.2,
  -- The joker gate's pole color, and its color once the joker has been taken.
  -- Pole colors set outright rather than lifted, because their stock value is
  -- black and there is no brighter version of black to compute.
  --
  -- `next` is the gate AFTER the one being aimed at. The engine ships it black
  -- because in its own races that gate is not your concern yet; this mod puts a
  -- marker there on purpose, so the line through the corner reads before the
  -- driver gets there. Orange, matching the editor's color for the route
  -- ahead, and a shade under the gate actually being aimed at so the two are
  -- never confused for one another.
  POLE_MODE_RGB = {
    next = { 0.95, 0.45, 0.12 },
  },
  ROUTE_FILE = 'settings/raceManager/route.json',
}

-- Build stamp, pushed to the UI. Must match the server plugin and app.js -- see
-- the note in main.lua for why a mismatch is otherwise invisible.
local RM_BUILD = '0.14.2'

-- ---------------------------------------------------------------------------
-- State
-- ---------------------------------------------------------------------------
-- THE SESSION, AS ONE OBJECT.
--
-- Eighteen top-level locals describing what the race is doing right now: the
-- phase, this driver's lap and armed gate, the joker's state, the flag, the
-- reset allowance, the grid slot, the spectator lock.
--
-- Same reasoning as `track` above. Loose scalars are cheap to read and
-- expensive to SHARE: every one of them is rebound constantly, so anything
-- outside this file needed a getter per name -- which is what made the renderer
-- extraction cost twenty-five handles instead of three.
--
-- Mirrored from the server on every broadcast, not owned here. The server is
-- authoritative for all of it; this is the client's copy, and the only fields
-- the client decides for itself are the per-driver ones it measures locally
-- (localLap, armedWp, timingActive) because only the client has physics.
local session = {
  -- Mirrored from the server broadcast.
  phase      = 'waiting',   -- waiting | grid | countdown | racing | qualifying | finished
  totalLaps  = 5,
  raceFlag   = 'green',     -- green | yellow | red
  maxResets  = -1,          -- -1 unlimited, 0 none, N per driver per session
  resetMode  = 'inplace',   -- inplace | checkpoint
  jokerEnabled = false,
  -- THE PACE LAP, mirrored from the server in its two halves (see the note on
  -- the server's race.paceLap).
  --
  --   paceLap  the RULE: this race is started behind the pace car. Needed here
  --            and not only in the panel, because the lap that ends the race is
  --            one crossing further out than the lap box says and the white and
  --            checkered flags are waved from this side -- see effectiveLapTarget.
  --   pacing   the CONDITION: the formation lap is running right now. Yellow is
  --            already on screen for it, but yellow also means "there has been
  --            an incident", and those are not the same instruction.
  paceLap      = false,
  pacing       = false,
  -- THE CAUTION. Distinct from raceFlag being yellow, and the distinction is
  -- the whole point: an advisory yellow is a local hazard, a caution is a
  -- neutralised race with the running order frozen. A driver who cannot tell
  -- them apart does not know whether the places they are making count.
  caution      = false,
  cautionLaps  = 0,
  -- Called and not yet official: the yellow is out and the field is RACING BACK
  -- TO THE LINE. A different instruction from the frozen caution that follows
  -- it, and the one a driver has to act on first.
  cautionPending = false,
  -- THE BLUE FLAG, from both ends, read off this client's own driver row. The
  -- server decides both (it is the only side that can see where every car is);
  -- these are what the flag and the two notices are driven from.
  --
  --   beingLapped   a car a lap or more up is close behind. Blue flag.
  --   lappingAhead  the car close ahead is a lap or more down.
  beingLapped  = false,
  lappingAhead = false,
  -- A restart is called and the green falls as the leader reaches the line.
  restartPending = false,
  -- The heat program, for one reason only: a heat can run a distance of its own,
  -- and the white and checkered flags are waved from this side. See
  -- effectiveLapTarget.
  heatCount    = 0,
  heatCurrent  = 0,
  heatLaps     = 0,
  -- Which heat WE were drawn into, read off our own driver row. nil means no
  -- draw has happened (or we are not in it); it is only ever compared against
  -- heatCurrent, to tell a driver waiting out somebody else's heat why their
  -- car has gone intangible.
  myHeat       = nil,
  -- This driver's own lap, measured here because only the client sees the car
  -- cross anything. The server scores what this reports.
  localLap     = 1,
  armedWp      = 1,         -- next gate the local car must cross
  timingActive = false,     -- quali: false until the first S/F crossing (out lap)
  lapStart     = 0,         -- localTime at the start of the current lap
  prevPos      = nil,       -- vehicle position last frame (the crossing segment)
  resetsUsed   = 0,         -- what THIS client has spent
  -- Joker lap progress, per driver and per session.
  jokerArmed   = 1,         -- next joker gate the local car must cross
  jokerTaken   = false,     -- joker route already completed this race
  jokerLapUsed = nil,       -- lap the joker was taken on, for the UI
  -- Where the server put this car for the start, and whether the hold is on.
  gridSlot   = nil,
  gridFrozen = false,
  -- TIMED RACE, mirrored from the server. Two flags because there are two
  -- states and they mean different things to a driver:
  --   raceExpired  the clock is out, nothing has changed yet, and the final lap
  --                begins when the LEADER next takes the line. Two laps to go
  --                from here: finish this one, then run the last.
  --   lastLapNum   the leader has been past. Completing this lap number ends
  --                your race, so a car behind the leader still gets a full lap
  --                rather than being flagged off at the line.
  -- The checkered flag after that is `finalLap`, which a race now reaches as
  -- well as qualifying and which means the same thing in both: your next
  -- crossing is your last.
  raceExpired  = false,
  lastLapNum   = nil,
  -- 'laps' | 'timed' | 'endurance'. Needed HERE and not only in the panel: the
  -- white and checkered flags are decided per driver on this client, and they
  -- have to know that a timed race has no lap target for them to count towards.
  raceMode     = 'laps',
  -- Out of the session: finished, retired, or eliminated. 'race' | 'derby'.
  spectatorLock = nil,
  -- Is this client an authenticated admin?
  --
  -- Cached here on purpose so it survives the pause menu, and corrected by the
  -- server whenever it refuses a command -- BeamMP REUSES session ids, so a
  -- reconnect can inherit a stale one. Session-scoped rather than editor state:
  -- it gates the editor, but it is not part of it.
  isAdmin = false,
}

-- Checkpoints: ordered list of { x, y, z, hx, hy } where (hx, hy) is the
-- normalized direction of travel captured at placement. The gate rectangle runs
-- perpendicular to it; the last checkpoint is the start/finish line. A gate may
-- also carry per-checkpoint width/height overrides; absent, it inherits the
-- global defaults below. Each checkpoint is a flat, upright rectangle:
-- width = lateral span, height = vertical extent (covers banking).
-- THE TRACK, AS ONE OBJECT.
--
-- These eight were eight separate top-level locals, and being separate is what
-- made them expensive to hand to anything else. Four are REBOUND wholesale when
-- a layout loads (route = cps), so anything holding a reference would keep the
-- old table forever -- which is why every consumer of them would have needed a
-- getter rather than the value.
--
-- One table fixes that by construction: `track.route` is rebound, `track` never
-- is, so anything handed this table sees every later change for free. It is the
-- same reason branch, pit, nudge, marker, field and spectate are tables. This is
-- simply the last part of the state that never got the treatment, and it is the
-- part everything else reads.
--
-- It buys the register budget back too: eight locals become one, in a file that
-- had none left.
local track = {
  -- Checkpoints: ordered { x, y, z, hx, hy }, where (hx, hy) is the normalized
  -- direction of travel captured at placement. The LAST one is the start/finish
  -- line. A gate may carry its own width/height/depth; absent, it inherits the
  -- defaults below.
  route = {},
  -- Optional rallycross joker route: a second, independent gate sequence.
  jokerRoute = {},
  -- Pit stalls. Never part of the checkpoint sequence.
  pitRoute = {},
  -- The pit lane's mouth and its exit. Arrays, because a lane can have more
  -- than one way in. Declared HERE and not only where a layout is applied: the
  -- renderer reads them every frame, including before any layout exists, and a
  -- nil here is a crash in the draw path rather than an empty lane.
  pitEntry = {},
  pitExit  = {},
  -- Starting grid, slot 1 is pole. Travels with the layout.
  startPositions = {},
  -- Circuit or sprint. A point-to-point stage is driven once, first gate to
  -- last, and its last gate is a FINISH rather than a line you come back round
  -- to.
  pointToPoint = false,
  -- Size given to newly placed gates, and the layout's stored default for any
  -- gate without an override of its own.
  checkpointWidth  = TUNE.DEFAULT_WIDTH,
  checkpointHeight = TUNE.DEFAULT_HEIGHT,
  checkpointDepth  = TUNE.DEFAULT_DEPTH,
}
-- Is this track a circuit or a sprint?
--
-- A point-to-point stage is driven once, from the first gate to the last, and
-- the last gate is a FINISH rather than a line you come back round to. Setting
-- a circuit to one lap gets the same timing, which is why it worked as a
-- workaround -- but it reads as a one-lap circuit everywhere it is shown, and a
-- driver on a sprint stage wants to be told they are on a sprint stage. It
-- belongs to the TRACK, so it travels with the layout.

-- WHO OWNS THE ROUTE BUFFER RIGHT NOW.
--
-- route, jokerRoute, pitRoute, startPositions and branch.list are two things at
-- once: the track this client races against, and the working copy the editor
-- appends to. Nothing separated them, so an incoming layout overwrote whatever
-- an admin had half-built.
--
-- That is the cross-admin bug, and the controller back button was a symptom
-- rather than the cause. The app asks the server for state on every mount, the
-- server answers with whichever layout is globally loaded, and the reply landed
-- here as an unconditional overwrite. A rejoin, a HUD apps toggle or a UI scale
-- change did it just as well as the back button did.
--
-- ONE TABLE, not three locals: the top level of this file is a function, Lua
-- allows it 200 locals, and 196 are spoken for. There are four left.
local edit = {
  -- IS THE PANEL OPEN, and what is it pointed at. Mirrored here because the
  -- authoring furniture -- start-slot outlines, gate rectangles, marker boards
  -- -- is drawn from Lua and the panel's open/closed state only exists in the
  -- UI. A closed app means a closed editor.
  open   = false,
  -- Which list the editor appends to: main | joker | pit | branch | marker | start.
  target = 'main',
  -- Draw the gates at all. The Hide/Show toggle, and it belongs with the editor
  -- rather than with the session: it is about this client's VIEW, not the race.
  visualize = true,
  -- Fingerprint of the buffer as the server last handed it over. nil until a
  -- layout has been applied, which is what keeps a fresh client, a late joiner
  -- and every non-admin driver on the unconditional path.
  stamp   = nil,
  -- Name of a layout whose apply was refused, held so the panel can say which
  -- one is waiting rather than only that something was.
  refused = nil,
}

-- DIRECTION MARKERS: signage, and nothing else.
--
-- A marker is placed exactly the way a checkpoint is and does nothing at all
-- once it is there. It is not armed, not crossed, not timed, not counted, and
-- never appears in a lap, a split or a results file -- the crossing code has no
-- idea these exist. On a long point-to-point stage the problem is not scoring,
-- it is that a driver arriving at a junction at speed has no idea which way the
-- route goes, and a checkpoint placed to answer that would be a checkpoint they
-- have to hit.
--
-- ONE TABLE, and this one is not a style preference: the file has exactly one
-- top-level local left of Lua's 200. Everything markers need -- the list, the
-- symbol the editor is placing, the symbol geometry -- hangs off this. The next
-- feature after this one has to start by extracting a module.
local marker = {
  -- Placed markers: { x, y, z, hx, hy, width, height, depth, kind }.
  list = {},
  -- The symbol the NEXT placed marker gets, and what the mode buttons set. A
  -- marker's symbol is changed after placement too, which is the point of
  -- keeping it as a field rather than baking it into seven placement buttons.
  kind = 'right',
}

-- Every symbol, in one place. The order is the order the panel offers them.
marker.KINDS = { 'right', 'left', 'up', 'down', 'uturn', 'splitRight', 'splitLeft', 'pit' }
marker.LABEL = {
  right = 'Right', left = 'Left', up = 'Straight on', down = 'Slow / stop',
  uturn = 'U turn', splitRight = 'Split, keep right', splitLeft = 'Split, keep left',
  pit = 'Pit lane',
}

-- SYMBOL GEOMETRY, as line segments in a unit cell.
--
-- Each entry is a list of { x1, y1, x2, y2 } in a box running -1..1 across and
-- -1..1 up, with +x to the marker's RIGHT as a driver faces it and +y up. The
-- draw pass scales the cell and repeats it across the marker's width, so a
-- symbol is authored once at one size and works at every size.
--
-- Drawn as segments rather than as text because debugDrawer text does not
-- scale with distance the way a shape does: a glyph readable in the editor is
-- a speck at two hundred meters, which is exactly where a direction marker has
-- to be readable.
marker.GLYPH = {
  -- CHEVRONS, not arrows. A stemmed arrow tiled ten times reads as ten arrows;
  -- a chevron tiled ten times reads as ONE arrow ten cells long, which is what
  -- a lane marking on a real road does and what ">>>>>>>>" says at a glance.
  right = { {-0.55,0.8, 0.45,0}, {0.45,0, -0.55,-0.8} },
  left  = { {0.55,0.8, -0.45,0}, {-0.45,0, 0.55,-0.8} },
  up    = { {-0.8,-0.55, 0,0.45}, {0,0.45, 0.8,-0.55} },
  down  = { {-0.8,0.55, 0,-0.45}, {0,-0.45, 0.8,0.55} },
  -- These three are SHAPES rather than repeating marks, so they carry a stem:
  -- a U turn tiled across a board still has to look like a U turn.
  -- SQUARE, not arced, for the reason the P is a stencil. A mark is not a line:
  -- each stroke is drawn as a fattened dark outline with a face on top, so
  -- strokes meeting at a shallow angle overlap into a blob. The arced top here
  -- was four such joins and the glyph read as a cyan smear.
  --
  -- Up the left, across, down the right, and an arrowhead pointing DOWN so the
  -- symbol says which way round it is travelled. Only the two barbs are angled,
  -- which is what an arrowhead is, and the chevrons already prove two short
  -- angled strokes read cleanly.
  -- SQUARE, not arced, and the reason is arithmetic rather than taste. A mark
  -- is not a line: every stroke is a filled quad, drawn once fattened as a dark
  -- outline and once as the face, with both ends extended by half the
  -- thickness so mitres do not open up. The arced top was four short segments,
  -- each shorter than its own end extension, so each was drawn nearly three
  -- times its true length and the four overlapped into one cyan smear.
  --
  -- Up the left, across, down the right, and an arrowhead pointing DOWN so the
  -- mark says which way round it is travelled. Every segment is longer than the
  -- stroke is wide, and the two legs are far enough apart that the gap between
  -- them survives the outline: that gap is the only thing that makes it a U.
  uturn = { {-0.45,-0.85, -0.45,0.55},
            {-0.45,0.55, 0.45,0.55},
            {0.45,0.55, 0.45,-0.25},
            {0.45,-0.25, 0.10,0.10},
            {0.45,-0.25, 0.80,0.10} },
  splitRight = { {0,-0.8, 0,-0.1}, {0,-0.1, -0.45,0.5}, {0,-0.1, 0.5,0.5},
                 {0.5,0.5, 0.1,0.42}, {0.5,0.5, 0.44,0.08} },
  splitLeft  = { {0,-0.8, 0,-0.1}, {0,-0.1, 0.45,0.5}, {0,-0.1, -0.5,0.5},
                 {-0.5,0.5, -0.1,0.42}, {-0.5,0.5, -0.44,0.08} },
  -- A LETTER P, drawn rather than written, for the reason above the table: this
  -- has to read from the far end of a straight, and debugDrawer text does not
  -- shrink with distance. A P is the sign every driver already knows, and as
  -- one shape rather than a tiled mark it stays a P at any board width.
  --
  -- A STENCIL P: stem, top bar, right side, waist bar. Four strokes, every one
  -- axis-aligned, and that is the whole design.
  --
  -- The first attempt rounded the bowl with angled segments and came out lumpy,
  -- because a mark is not a line: each stroke is drawn as a fattened dark
  -- outline with a face on top, so two strokes meeting at an angle overlap into
  -- a blob with a ragged silhouette. Right angles meet cleanly, which is also
  -- why real stencil letters look like this.
  pit = { {-0.40,-0.80, -0.40,0.80},
          {-0.40,0.80, 0.30,0.80},
          {0.30,0.80, 0.30,0.15},
          {0.30,0.15, -0.40,0.15} },
}

-- Which symbols TILE as a repeating mark and which are one shape.
-- A chevron field wants to be dense; a U turn wants to be legible.
marker.TILES = { right = true, left = true, up = true, down = true }

function marker.validKind(k)
  k = tostring(k or '')
  for i = 1, #marker.KINDS do
    if marker.KINDS[i] == k then return k end
  end
  return nil
end

-- BRANCHING ROUTES (the other ways through a checkpoint).
--
-- A checkpoint can have more than one gate. Slot i is cleared by crossing the
-- main gate `route[i]` OR any branch gate authored against slot i, whichever the
-- car actually drives through. NOTHING is remembered about which one it was: the
-- next slot is decided from scratch the same way, so a driver is never on a
-- "line" and there is no identity to assign, lock, carry or report.
--
-- A branch gate therefore cannot add or remove slots, only offer another way
-- through one that exists, and that is the whole design: `armedWp` stays an
-- integer index bounded by #route, the lap still completes on armedWp >= #route
-- whichever gates a driver took, and the checkpoint count reported to the server
-- means the same thing for all of them. The running order needed no changes.
--
-- Both gates are drawn, both are armed, and either one is the checkpoint. That
-- covers a split lane and a head-on oval with the same rule, and the direction a
-- driver goes is settled by which way their start position points them.
--
-- ONE TABLE, not eight locals. The top level of this file is a function and Lua
-- allows it 200 of them; this chunk is close enough to that ceiling that the tail
-- of the file is already scoped into a do...end block to get its registers back
-- (see the note above the server -> client handlers). `pit` is grouped the same
-- way for the same reason.
local branch = {
  -- As authored, flat: { { slot, x, y, z, hx, hy, ... }, ... }
  list   = {},
  -- Resolved once, when a layout is applied: slot -> array of gates for it. Nil
  -- for a slot with no branch gate, which is every slot on every track that
  -- existed before this -- so the per-frame path is one table index that comes
  -- back nil, with no search and no allocation.
  bySlot = {},
  -- Does this track grid its cars away from the start/finish line? Mirrored from
  -- the layout. Decides whether the first crossing is an out lap, and -- until it
  -- happens -- that the ONLY armed gate is the line itself (see armedGate).
  gridOffLine = false,
  -- Editor: the checkpoint the next placed branch gate belongs to.
  editSlot = 1,
}
local selfSpectating   = false     -- this player has opted out of the field

-- Starting grid: ordered list of { x, y, z, hx, hy } placed by the race
-- creator. Slot 1 is pole. Travels with the track layout; the server assigns a
-- slot number per driver and this client puts its own car on that slot.
-- What the session WANTS held ('race' | 'derby' | nil), as opposed to whether
-- the freeze is currently applied. Separating intent from state is what lets the
-- freeze be put back at the one moment it is known to be lost: the vehicle reset
-- that a placement teleport causes. Forward-declared with the setter because
-- onVehicleResetted sits above the hold code and needs both.
local holdWanted     = nil
local setLocalVehicleFrozen      -- forward declaration, assigned further down

-- Grid hold enforcement.
--
-- The freeze used to be issued ONCE, at placement, and never checked again. That
-- is fine while it sticks and silently wrong when it does not, and there were
-- four ways for it not to stick: the placement teleport reports back as a
-- vehicle reset which reloads the vehicle's Lua VM and takes the freeze with it,
-- and the re-apply only happened when that report was recognized as our own echo
-- -- so a report arriving later than the 0.6 s echo window, a driver pressing
-- reset on the grid, and a vehicle reloaded or respawned on the grid all left
-- the car free. Nothing re-asserted it and nothing noticed, so any one of those
-- was permanent, and the driver simply drove away during the countdown.
--
-- So intent is now separated from effect and the effect is VERIFIED: while a
-- hold is wanted the car's distance from the slot it was put on is watched, and
-- drift is corrected. Correction is driven by observed movement and never by a
-- timer, which matters -- re-applying the freeze re-pins the car and resets the
-- drivetrain, so a car that is behaving has to be left completely alone or
-- revving against the hold and pre-selecting a gear (the point of a standing
-- start) would stop working.
--
-- Declared up here because onVehicleResetted, several hundred lines above the
-- hold code, is one of the places that has to put the hold back.
local hold = {
  -- Where the car came to REST after being placed. Captured once it has stopped
  -- moving, and it is what drift is measured against -- the slot coordinates are
  -- where the car was dropped, which is above the ground by however far it then
  -- falls onto its suspension.
  anchor      = nil,
  -- The slot itself, as a fallback for putting a car back before it has ever
  -- settled (a reset on the grid during the settle window).
  slot        = nil,
  rot         = nil,   -- the rotation it was placed with
  settleLeft  = 0,     -- seconds of grace left for a just-placed car to rest
  reportLeft  = 0,     -- seconds until the next position report to the server
  correctLeft = 0,     -- cooldown after a correction, so one slip is not a storm
  corrections = 0,     -- how many times this car has been pulled back
}
-- Ghosting is defined with the qualifying rules further down, but the placement
-- scheduler above it needs to switch it on: a field of cars being teleported
-- into position has to pass through each other on the way in. Forward-declared
-- rather than moved so the ghost code stays beside the rule it was built for.
local setGhostReason             -- forward declaration, assigned further down

-- Everything ghosting knows, in ONE table: its state, its mirrored rules and
-- its functions. Two reasons, and neither is a style preference.
--
-- The first is the local ceiling this file's TUNE table already exists for --
-- 181 of the 200 a function may hold are spoken for, and a module that needed a
-- local apiece for its state and another for each of its eight functions simply
-- would not compile. Hanging them off one table costs one.
--
-- The second is that it has to be declared HERE, above onVehicleResetted, which
-- is what arms a reset ghost -- while the ghost code itself belongs beside the
-- qualifying rule it grew out of, several hundred lines below. A table can be
-- declared early and filled in late; a local function cannot.
local ghost = {
  -- Per-VEHICLE ghost reasons: veh[gameVehId] = { reason = true, ... }, and a
  -- vehicle is ghosted while that set is non-empty. Per vehicle and not one
  -- global flag, because two drivers resetting a second apart are two
  -- independent ghosts and neither may end the other's.
  veh     = {},
  -- OUR OWN car's id while we are a finished driver, or nil. Read by alphaFor,
  -- which is the one place that keeps a finished driver's own car unfaded, and
  -- held as an id rather than derived from ownVehicle() so the reason comes off
  -- the car that was ghosted even if the driver has since reset into another.
  finishedOwn = nil,
  -- Everyone ELSE's finished cars: [tostring(pid)] = gameVehId (or true while
  -- their car has not appeared in our world yet). Walked to notice a pid that
  -- has dropped out of the authoritative list, which is how a disconnect
  -- mid-ghost stops leaving a ghost behind.
  finishedRemote = {},
  applied = {},   -- [gameVehId] = true while the ghost is actually applied
  -- Cars whose reasons have all gone but which still had another car inside
  -- them when the moment came. They stay ghosts and are retried until the space
  -- is clear -- no car is handed its collisions back with something in it.
  pending = {},
  -- Seconds of ghost left per vehicle, which is what the fade reads. Only reset
  -- ghosts have a remaining time; a quali or placement ghost has no clock and
  -- sits at a flat alpha until the reason is dropped.
  left    = {},
  -- Last mesh alpha actually pushed to each car, so the per-frame fade can skip
  -- the engine call when nothing moved.
  alpha   = {},
  -- The field-wide reasons currently in force ('quali', 'placement'), kept so
  -- the sweep can re-assert them onto cars that appeared since.
  field   = {},
  -- This client's own reset ghost. Only ever one: a repeat reset restarts this
  -- timer rather than stacking a second ghost beside it.
  own = {
    pid      = nil,    -- our BeamMP id, as the server knows us
    vehId    = nil,    -- the car the ghost is on
    settling = false,  -- placed, but not yet reporting a usable bounding box
    settleLeft = 0,    -- ...and a cap on how long that wait may last
    left     = 0,      -- seconds of base timer remaining
    total    = 0,      -- base duration this ghost was granted (for the fade)
    blocked  = 0,      -- seconds spent waiting for an occupied space to clear
    warned   = false,  -- the "move clear" warning has been sent once
  },
  -- Ghosts other clients told us about, so their cars are ghosts on OUR screen
  -- too: remote[pid] = the SERVER-CLOCK time the ghost ends.
  --
  -- An absolute end time and not a countdown, because a countdown starts the
  -- moment the message is opened -- so 200 ms of latency would buy the sender
  -- 200 ms of extra ghost on every other screen, and every receiver would
  -- disagree slightly about when the car goes solid. An end time on a clock both
  -- ends share means a late message produces a SHORTER remainder, never a longer
  -- one, and every receiver lands on the same instant.
  remote = {},
  -- Our best estimate of the server clock (race.time). Set from every state
  -- broadcast and advanced locally in between, so the remainder above is still
  -- meaningful on the frames between pushes.
  serverTime = 0,
  -- League rules, mirrored from the server broadcast. Defaults match the
  -- documented ones so a client that has not heard from the server yet still
  -- behaves sanely rather than ghosting forever.
  rules = { onReset = true, minSec = 5.0, maxSec = 15.0 },
  -- Why the local ghost is currently held past its timer, for the log. nil when
  -- it is not blocked.
  blockReason = nil,
  refresh  = 0,       -- seconds until the next re-assert sweep
  -- [pid] = the local vehicle id that player owns, resolved when a ghost is
  -- applied and re-checked on the sweep. Cached because the lookup builds a
  -- table and the fade below runs every frame.
  remoteVeh = {},
  hudLeft  = 0,       -- seconds until the next HUD push is due
  hudShown = false,   -- a HUD push has been sent that the UI is still showing
  -- [vehId] = seconds left of a derby respawn ghost. Counted down locally
  -- because a derby has no shared clock to hang an end time on: race.time is
  -- frozen for the length of one (RM_Tick returns early with no racing session),
  -- so an end time computed from it would never arrive.
  respawn  = {},
}

-- ---------------------------------------------------------------------------
-- Display names on the BeamMP nametag
-- ---------------------------------------------------------------------------
-- A driver called `guest5961302` has a readable name on the leaderboard and
-- their guest number floating over the car. This puts the readable one up there
-- too.
--
-- IT ADDS A SUFFIX AND DOES NOTHING ELSE, and that constraint is the whole
-- design. BeamMP renders nametags itself in MPVehicleGE.onPreRender, and that
-- rendering carries a lot that players are attached to: distance fade,
-- hide-behind-objects, the spectator list, role tags, color, alpha. There IS a
-- way to take the whole thing over -- MPVehicleGE.hideNicknames(true) and draw
-- your own, which is what BeamJoy does -- and it is rejected here on purpose.
-- Owning the render means owning the fade, the occlusion and every setting a
-- player has already chosen, and getting any of it slightly wrong is worse for
-- them than a guest number.
--
-- So this goes through BeamMP's own API instead:
--
--   MPVehicleGE.setPlayerNickSuffix(guestName, tagSource, text)
--
-- which files the text under `player.nickSuffixes[tagSource]` and lets BeamMP's
-- renderer concatenate it. Text in, nothing else touched.
--
-- THE `tagSource` KEY IS WHY THIS IS SAFE ALONGSIDE OTHER MODS. Suffixes are a
-- map keyed by source, not a single string, so BeamJoy or CEI can hold their own
-- tag on the same driver and neither of us overwrites the other. Ours is
-- namespaced under RM_TAG_SOURCE below.
--
-- WHAT IS DELIBERATELY NOT DONE: writing `MPVehicleGE.getPlayers()[pid].name`.
-- That getter hands back the live table rather than a copy, and the renderer
-- looks players up by ID, so assigning to it really would replace the guest
-- number outright rather than appending to it. It is still wrong. `name` is
-- BeamMP's own lookup key in five places, and one of them is onPlayerLeft --
-- which matches `player.name == name` to remove somebody who has disconnected.
-- Rename them and they are never cleaned up, on every client on the server. We
-- would be leaking entries inside BeamMP's bookkeeping to save four characters.
local nametag = {
  -- Namespaced so BeamMP files our suffix separately from every other mod's.
  SOURCE  = 'raceManager',
  -- [guest name] = the suffix we last set on it, so the sweep below knows what
  -- it has to undo. Keyed by NAME because that is what the API takes.
  applied = {},
  on      = false,     -- mirrored from the server broadcast
  sig     = nil,       -- last applied alias set, to skip unchanged broadcasts
}

-- CLEARING PASSES AN EMPTY STRING, NEVER nil, and this is a live trap rather
-- than a style preference. BeamMP's setter opens with
--
--   if text == nil then text = tagSource; tagSource = 'default' end
--
-- so calling it with a nil text does not clear anything: it shifts the arguments
-- and writes the literal word `raceManager` onto that driver's nametag, under
-- the 'default' source where we can no longer even find it to remove it.
function nametag.set(guestName, text)
  if type(guestName) ~= 'string' or guestName == '' then return end
  if not (MPVehicleGE and type(MPVehicleGE.setPlayerNickSuffix) == 'function') then
    return
  end
  pcall(MPVehicleGE.setPlayerNickSuffix, guestName, nametag.SOURCE, text or '')
end

-- Take every suffix back off. Called when the rule is switched off, when the
-- session ends and when the extension unloads -- a tag left behind by a mod that
-- is no longer running is somebody else's bug report.
function nametag.clearAll()
  for guestName in pairs(nametag.applied) do nametag.set(guestName, '') end
  nametag.applied = {}
  nametag.sig = nil
end

-- Apply the alias set from the latest broadcast.
--
-- `drivers` carries both halves already: `name` is the BeamMP guest name, which
-- is exactly the key setPlayerNickSuffix matches on, and `alias` is what an
-- admin typed. No lookup, no mapping table, nothing to keep in step.
--
-- SKIPPED WHEN NOTHING CHANGED. The state broadcast lands three times a second
-- and the setter is a linear search through BeamMP's player list per call, so
-- re-applying an unchanged set would be a scan per driver per broadcast for the
-- length of a race. Aliases change a handful of times an evening.
function nametag.apply(drivers)
  if not nametag.on then
    if next(nametag.applied) ~= nil then nametag.clearAll() end
    return
  end
  if type(drivers) ~= 'table' then return end

  local parts = {}
  for i = 1, #drivers do
    local row = drivers[i]
    if type(row) == 'table' and type(row.name) == 'string' and row.alias then
      parts[#parts + 1] = row.name .. '=' .. tostring(row.alias)
    end
  end
  table.sort(parts)
  local sig = table.concat(parts, '\1')
  if sig == nametag.sig then return end
  nametag.sig = sig

  local wanted = {}
  for i = 1, #drivers do
    local row = drivers[i]
    if type(row) == 'table' and type(row.name) == 'string' and row.alias then
      wanted[row.name] = ' (' .. tostring(row.alias) .. ')'
    end
  end
  -- Off first: a driver whose alias was removed, or who was renamed, must lose
  -- the old suffix even if nothing is going back on.
  for guestName in pairs(nametag.applied) do
    if not wanted[guestName] then
      nametag.set(guestName, '')
      nametag.applied[guestName] = nil
    end
  end
  for guestName, text in pairs(wanted) do
    if nametag.applied[guestName] ~= text then
      nametag.set(guestName, text)
      nametag.applied[guestName] = text
    end
  end
end

-- Rallycross joker route (Module 2): a second, completely separate gate set
-- describing the alternate route. Same checkpoint format as `route`; it travels
-- with the track layout and is only policed when the server arms the rule.
-- Pit stalls: a pit-lane AREA, deliberately kept out of `route`.
--
-- A pit stall is somewhere a driver may choose to go, not a checkpoint they
-- must pass in order. Putting one in the main route would make it mandatory
-- every lap and would put it inside lap and split validation, which is exactly
-- the contamination this is meant to avoid -- so pit stalls live in their own
-- list, like the joker route, and the checkpoint sequence never sees them.
--
-- Driving into one stops the car, repairs it in place and lets it go again.
local pit = {
  active   = false,  -- a stop is running
  left     = 0,      -- seconds until release
  -- Seconds left of re-asserting the freeze and the ghost after servicing. The
  -- repair reloads the vehicle's Lua VM asynchronously and takes both with it,
  -- so they are kept re-applied until the car has settled rather than put back
  -- once at a moment guessed in advance.
  settleLeft = 0,
  cooldown = 0,      -- a short delay before the same stall is live again
  -- The car has to LEAVE a stall before it can serve another stop in one.
  --
  -- The cooldown above was meant to be what stopped the box you are standing in
  -- re-triggering, but a timer only delays that: a car still parked in the
  -- stall when it expires is simply caught again, and again, forever -- frozen
  -- and ghosted each time, which reads from the driver's seat as "my car is
  -- stuck as a ghost for the rest of the race". Resetting in the pits puts you
  -- there, because a reset in place leaves the car exactly where it stood.
  --
  -- A stop is something a driver DRIVES INTO. Arriving is the trigger, so
  -- having left is the thing that re-arms it.
  mustLeave = false,
  -- IN THE PIT LANE, which is what decides whether the stalls are drawn at all.
  --
  -- A lane's stalls are three draws each and were on screen for the whole race,
  -- off to the side, for something a driver uses once. Now one gate is drawn at
  -- the lane's mouth and the stalls appear behind it.
  --
  -- Set by crossing an entry gate. Cleared by an exit gate OR by clearing any
  -- route checkpoint, because a driver who misses the exit is plainly back on
  -- the racing line and would otherwise carry the stalls to the flag.
  inLane = false,
  -- The previous sampled position, kept here rather than shared with the gate
  -- loop: see the note in pit.update for why session.prevPos cannot be used.
  prevPos = nil,
  stops    = 0,      -- how many this session, for the log
  -- Standing in a stall but still rolling. Held so the "stop in the box"
  -- reminder can be throttled: without it the prompt is a push per frame for
  -- as long as a car creeps through the box.
  promptLeft = 0,
  -- The vehicle this stop ghosted, so it can be un-ghosted again even if the
  -- car has since been replaced under us (a repair reloads the vehicle VM).
  ghostVeh = nil,
  -- Whether THIS stop is the thing that announced the ghost to the server. False
  -- when a reset ghost was already running and owns that broadcast.
  ghostSent = false,
}
-- Is the editor panel open in the UI app? Mirrored here because the start-slot
-- markers are drawn from Lua (debugDrawer) and the panel's open/closed state
-- only exists in the UI. Pushed by the app whenever its admin tab changes, on
-- mount, and on teardown -- so a closed app means a closed editor.

-- Local lap tracking (reset on every session change)
local localTime    = 0

-- FREE PRACTICE: driving a track on your own, timed, with nothing at stake.
--
-- Entirely local. The server hands over an approved layout and says "you are
-- practising"; everything after that -- arming gates, timing laps, counting
-- them -- happens on this client and is reported to nobody. No RM_Lap, no
-- progress telemetry, no leaderboard row, no cup round.
--
-- It is deliberately NOT a session. sessionRunning() stays false throughout, so
-- the grid, the hold, the reset allowance, the flags and the spectator lock all
-- go on ignoring a practising driver, which is exactly right: those rules exist
-- to make a race fair, and there is no race.
--
--   on        practising right now
--   layout    the track pulled up, for the readout
--   lapTarget how many laps the driver asked for, 0 = unlimited
--   lapsDone  laps completed since practice started
local practice = { on = false, layout = nil, lapTarget = 0, lapsDone = 0 }

-- SELF-TIMING: this driver's lap and sector deltas.
--
-- Entirely local, and deliberately so. The server already stamps every
-- checkpoint crossing into rec.splits, but that table exists to build the gap
-- to the LEADER -- comparing two drivers on one clock. A driver's delta to
-- their own previous lap compares them to themselves, so it needs no other
-- car, no server round trip, and cannot be blanked by a dropped packet the way
-- a cross-driver gap can.
--
-- One table rather than four locals: this chunk is near Lua's 200-local ceiling
-- (see docs/ARCHITECTURE.md), and grouping is what the rest of the file does.
--
--   sectorStart  localTime the current sector began
--   prevLap      the last TIMED lap, which the lap delta is measured against
--   bestSector   [n] = fastest time seen for sector n this session
--   sectors      [n] = this lap's sector times, for the readout
local timing = { sectorStart = 0, prevLap = nil, bestSector = {}, sectors = {} }

-- Wipe the lot. A session change makes every stored time meaningless: a
-- different track, or the same one from a standing start with a new grid.
local function timingReset()
  timing.sectorStart = localTime
  timing.prevLap     = nil
  timing.bestSector  = {}
  timing.sectors     = {}
end

-- Live position telemetry: seconds until the next report of this car's distance
-- to the next checkpoint is due. The distance itself is computed inside that
-- report and nowhere else, so it needs no state up here.
local progressLeft = 0

-- Countdown to the state request fired after joining a BeamMP server (see the
-- session lifecycle hooks at the bottom of the file). nil = nothing pending.
local joinRequestLeft = nil

-- Vehicle reset ruleset (Module 1). maxResets mirrors the server: -1 unlimited,
-- 0 none, N allowed per session. resetsUsed counts what this client has spent.
-- Once the allowance is gone the reset is BLOCKED rather than punished: the car
-- is put straight back where it was, so pressing R buys nothing and costs
-- nothing. `snapshot` below is the rolling sample that restore uses.
local snapshot = {
  pos   = nil,    -- vec3-ish { x, y, z } sampled while driving
  rot   = nil,    -- quaternion { x, y, z, w } for the same sample
  left  = 0,      -- seconds until the next sample is due
  EVERY = 0.25,   -- seconds between "last good position" samples
}

-- What a LEGAL reset does while racing (mirrored from the server):
--   'inplace'    -- BeamNG's normal repair-where-you-stand (the default)
--   'checkpoint' -- the car is moved to the last checkpoint it crossed
local lastGate       = nil       -- last checkpoint the local car crossed (a wp table)
-- Was that crossing made BACKWARDS through the gate?
--
-- A gate driven both ways is stored with one heading, so which way a car went
-- cannot be read off the gate afterwards -- and relocateToGate stands the car
-- facing the gate's heading. On a
-- head-on layout that would respawn half the field pointing into the oncoming
-- one. Recorded per crossing rather than declared per gate, so it is right for
-- shared gates, branch gates and ordinary gates alike.
local lastGateBack   = false

-- Reset and teleport blocking, in ONE table: the two action groups, whether
-- each is currently filtered out, the echo window that tells this mod's own
-- teleports from the driver's, and the rate limit on blocked-attempt feedback.
--
-- Grouped for the local ceiling, like `hold` and `nudge`. Nine names up here
-- cost nine of the 200 this file may hold; one table costs one. The fields are
-- assigned below rather than in a literal so each keeps the comment it earned.
local block = {}

-- Once the allowance is spent the reset INPUTS themselves are switched off via
-- BeamNG's input action filter, so pressing R/Insert does nothing at all - the
-- car never resets, not even in place. The onVehicleResetted restore below
-- stays as a fallback for reset paths the filter cannot see.
--
-- That fallback is not optional any more: BeamNG v0.39 added a Vehicle
-- Management flow to the Pause menu with its own "repair and reset" buttons,
-- which is a reset the driver can reach without ever triggering one of the
-- input actions below. The filter still covers the keys and pads; the restore
-- in onVehicleResetted is what covers the Pause menu.
block.RESET_ACTIONS = {
  'reset_physics', 'reset_all_physics', 'recover_vehicle', 'recover_vehicle_alt',
  'recover_to_last_road', 'reload_vehicle', 'reload_all_vehicles',
  'loadHome', 'dropPlayerAtCamera',
}
block.resetInputs = false

-- THE TELEPORTS, as their own group, blocked for the whole of a session rather
-- than only once a driver is out of resets.
--
-- These two do not reset a car, they MOVE it: loadHome (Home) puts it on its
-- spawn point and dropPlayerAtCamera puts it wherever the camera is. Neither is
-- a recovery in any racing sense -- a driver who presses Home mid-race is at the
-- far end of the map, still classified and still being timed, having pressed the
-- key they press every other day of the week.
--
-- WHY BLOCKED RATHER THAN TURNED INTO A RESET. The undo in onVehicleResetted
-- already makes the RECOVERY key behave like the in-place one, and the obvious
-- next step is to do the same for these. It does not work: that undo hangs off
-- BeamNG's reset hook, and a teleport that never reports itself as a reset never
-- reaches it. Watching for the jump per frame instead was tried and withdrawn --
-- telling a teleport from a fast car needs a speed the mod cannot always read,
-- and a false positive drags a LEADING driver backwards for going quickly, which
-- is a worse bug than the one being fixed.
--
-- So the key does nothing during a session, which is honest and cannot misfire.
-- A driver who wants Home to reset can bind it to Recover Vehicle in BeamNG's
-- own controls, and the mod then treats it exactly like the reset key it is.
block.TELEPORT_ACTIONS = { 'loadHome', 'dropPlayerAtCamera' }
block.teleportInputs = false

-- BeamNG reports a teleport as a vehicle reset, and this mod teleports the car
-- itself (blocked-reset restore, grid placement, editor preview). Without a way
-- to tell those apart from the driver pressing reset, a blocked reset restored
-- the car, heard its own restore back as a fresh reset, restored again... an
-- endless loop that pinned the car in place and flooded the UI until the game
-- locked up. Every teleport we perform is recorded here (where and when), and a
-- reset reported from that spot inside the window is our own echo.
block.selfTeleport = { left = 0, x = 0, y = 0, z = 0 }
block.TELEPORT_WINDOW = 0.6      -- seconds an echo of our own teleport can arrive in
block.TELEPORT_RADIUS = 2.0      -- meters from where we put the car
-- Reset fires repeatedly while the key is held, so the feedback for a blocked
-- attempt (notice, log line, server report) is rate limited. The block itself
-- is applied on every single attempt.
block.noticeLeft = 0
block.NOTICE_EVERY = 1.0   -- seconds between blocked-reset reports

-- Admin session. This lives HERE, not in the UI app, and that is the whole
-- point: BeamNG tears the HUD layer down and rebuilds it whenever the pause
-- menu opens, which destroys the app's Angular scope and everything in it. The
-- server session survives that (it is keyed by BeamMP player id and only
-- dropped on disconnect or an explicit logout), so the client's copy has to
-- survive it too, or every pause reads as a logout. This extension is resident
-- across the pause menu -- modScript sets it to manual unload -- so it is the
-- durable place to keep it. Pushed to the UI with every route state, and
-- re-confirmed by the server on RM_RequestState (which the app sends on mount).

-- Qualifying: ghost mode + session limits, all mirrored from the server.
-- finalLap is the timed session's post-expiry state: the clock has run out and
-- the lap this driver is on is their last.
local finalLap       = false
-- Who holds the session's fastest lap, as of the last broadcast. Remembered so
-- the driver who sets it is congratulated once rather than on every broadcast
-- that carries the same pid afterwards.
local lastBestLapPid  = nil
-- ...and the time they set, so beating your OWN fastest lap is announced too.
local lastBestLapTime = nil
local ghostQuali     = false
local qualiLapLimit  = 0         -- 0 = unlimited
local qualiTimeLimit = 0         -- seconds, 0 = unlimited
-- Does this session open with an out lap -- one trip past the line that is not
-- timed and not scored? The server decides (it is off on a sprint stage, which
-- is driven once), and this client mirrors the answer so it can say so on the
-- driver's own readout before they have crossed anything.
local qualiOutLap    = false
-- Connected while somebody else's session was already running. Mirrored from
-- this client's own driver row: the server refuses to enter a mid-session
-- arrival and flags them instead, and the flag is what ghosts their car so they
-- cannot interfere with a race they are not in. Cleared when the next grid forms.
local isBystander    = false

-- Forced spectator mode (Module 1). Non-nil while this client is out of the
-- session: it holds the source ('race' or 'derby') that imposed the penalty, so
-- the isolated derby module and the racing state machine can never release each
-- other's spectators.
local spectatorReason = nil

local function inMultiplayer()
  return MPGameNetwork ~= nil and TriggerServerEvent ~= nil
end

-- The local player's vehicle. This is called several times per frame (gate
-- crossing, telemetry, the reset snapshot, the derby checks), so it goes
-- through the GE-side accessor BeamNG recommends: getPlayerVehicle(0) hands
-- back the object with no garbage collector churn, while be:getPlayerVehicle(0)
-- crosses into C++ and back on every call. v0.39 added a startup warning for
-- extensions that cost too much time, and BeamNG's own performance guide names
-- be:* accessors as the thing to stop doing, so the fast path is preferred and
-- the old call is kept only as the fallback for builds without it.
-- Which accessor exists is decided once, not per call.
local vehicleAccessor = nil    -- nil = undecided, 'ge' | 'engine'
local function playerVehicle()
  if vehicleAccessor == nil then
    if type(getPlayerVehicle) == 'function' and pcall(getPlayerVehicle, 0) then
      vehicleAccessor = 'ge'
    else
      vehicleAccessor = 'engine'
    end
  end
  if vehicleAccessor == 'ge' then return getPlayerVehicle(0) end
  if be then return be:getPlayerVehicle(0) end
  return nil
end

-- ---------------------------------------------------------------------------
-- "Our" vehicle, in a world full of other people's
-- ---------------------------------------------------------------------------
-- playerVehicle() answers "which vehicle is this client currently attached to",
-- and in multiplayer that is NOT the same question as "which vehicle is ours".
-- The moment our own car is deleted -- which is exactly what happens to a driver
-- who takes the flag -- BeamNG hands the camera (and getPlayerVehicle) to
-- whatever vehicle is nearest to hand, which is another player's car.
--
-- Every consequence of that was in this session's bug report. The respawn is
-- guarded by "do I already have a car?", so a finisher watching a rival's car
-- was told yes and never got their own back. The camera was left wherever the
-- game had put it, so the whole field ended up watching the one driver whose
-- car still existed. And removeLocalVehicle would happily have deleted the
-- rival's car instead of ours.
--
-- So ownership is asked about explicitly, and everything that removes, respawns
-- or points a camera at "our" vehicle goes through ownVehicle() below.
-- nil when this BeamMP build (or singleplayer) cannot tell us who owns what, in
-- which case the attached vehicle is the best answer available and is used as-is.
local function ownershipFn()
  if MPVehicleGE and type(MPVehicleGE.isOwn) == 'function' then return MPVehicleGE.isOwn end
  return nil
end

local function isOwnVehicle(vehId)
  if vehId == nil then return false end
  local isOwn = ownershipFn()
  if not isOwn then return true end   -- singleplayer: it is all ours
  local ok, own = pcall(isOwn, vehId)
  return ok and own == true
end

-- THE CLOSURE IS NOT WASTE HERE, AND pcall(veh.getID, veh) IS NOT THE SAME.
--
-- That rewrite looks like a free win -- same protection, one less allocation --
-- and it is wrong on the one case this pcall exists for. `veh.getID` is an
-- INDEX on the vehicle, and a BeamNG vehicle is userdata whose __index is a
-- binding function. Written as an argument it is evaluated BEFORE pcall is
-- called, so a dangling or deleted vehicle whose __index raises takes the
-- caller down instead of failing into `not ok`. Inside the closure the index
-- happens under the protection, which is the whole point.
--
-- Verified rather than reasoned about: an object whose __index errors returns
-- nil from this and throws from the argument form.
local function vehicleId(veh)
  if not veh then return nil end
  local ok, id = pcall(function () return veh:getID() end)
  if ok then return id end
  return nil
end

-- The local player's OWN vehicle, or nil when they genuinely have none.
-- Falls back to a scan when the attached vehicle turns out to belong to someone
-- else: our car may still exist, we are simply not looking at it.
local function ownVehicle()
  local veh = playerVehicle()
  if not ownershipFn() then return veh end
  if veh and isOwnVehicle(vehicleId(veh)) then return veh end
  if type(getAllVehicles) == 'function' then
    local ok, list = pcall(getAllVehicles)
    if ok and type(list) == 'table' then
      for _, v in ipairs(list) do
        if v and isOwnVehicle(vehicleId(v)) then return v end
      end
    end
  end
  return nil
end

-- Per-frame vehicle sample.
--
-- Several update steps want the same two things in the same frame -- the local
-- car and where it is -- and each used to go and fetch them itself. getPosition()
-- crosses into C++ and back, so the gate-crossing test and the position
-- telemetry were paying for that round trip twice a frame to read one value that
-- cannot have changed between them.
--
-- Sampled LAZILY, not at the top of onUpdate: outside a session nothing asks,
-- and querying a vehicle every frame while sitting in the menus would be a
-- worse deal than the one this replaces. `localTime` advances exactly once per
-- frame, which makes it the frame stamp.
local sample = { at = -1, veh = nil, pos = nil }

local function sampledVehicle()
  if sample.at == localTime then return sample.veh, sample.pos end
  sample.at  = localTime
  sample.veh = playerVehicle()
  sample.pos = sample.veh and sample.veh:getPosition() or nil
  return sample.veh, sample.pos
end

-- This client's BeamMP session id, so a broadcast that carries every driver can
-- be narrowed down to our own row. nil offline.
local function localServerId()
  if MPConfig and MPConfig.getPlayerServerID then
    local ok, id = pcall(MPConfig.getPlayerServerID)
    if ok then return tonumber(id) end
  end
  return nil
end

-- Position + normalized heading of the local car, the one measurement every
-- editor placement (checkpoints, start positions, derby markers) is built from.
-- ---------------------------------------------------------------------------
-- Nudge mode: move and turn placed gates with the mouse, from free cam
-- ---------------------------------------------------------------------------
-- The second way into the editor, beside driving to a gate and pressing the
-- button. Driving is still how a track gets built: it puts the gate exactly
-- where a car fits and facing exactly the way one travels, which no amount of
-- clicking from above can work out for you. This is for the pass afterwards,
-- where a gate is ten meters late or a couple of degrees off and re-driving the
-- whole corner to fix it is the expensive part.
--
-- ONE top-level local, like `branch` and `spectate`. This file sits at Lua's
-- 200-active-locals ceiling and going over it does not warn: the file simply
-- stops compiling and the whole mod is gone.
--
-- THE MOUSE IS BORROWED, NOT TAKEN. In free cam the mouse IS the camera, so
-- there is no way to drag anything without first releasing it. That is why this
-- is a mode you turn on and off rather than something always live: a stray click
-- while flying around looking at a track must never move a gate.
local nudge = {
  on       = false,   -- mode active: cursor released, picking live
  sel      = nil,     -- index into the ACTIVE editor list, not always `route`
  -- The list `sel` indexes. Remembered rather than looked up, because the
  -- drawing asks about it and the drawing runs above activeEditorRoute.
  list     = nil,
  dragging = false,
  -- WHERE THE CURSOR RAY LANDED when the gate was grabbed, and nil when nothing
  -- is grabbed. A drag moves the gate BY the distance the cursor has travelled
  -- since here, never TO where the ray currently lands: the ray goes through a
  -- gate (no collision on a debug drawing) to the ground behind it, so "to"
  -- teleported gates the instant they were picked.
  grabX    = nil,
  grabY    = nil,
  -- Frames left in which a click is assumed to have come from the PANEL.
  --
  -- The HUD app is a CEF overlay, and ImGui's WantCaptureMouse knows nothing
  -- about it -- so pressing Up, Down or a turn button registers here as a click
  -- on the world as well. Every M.nudge* entry point is only ever reached from
  -- that panel, so one being called is the signal.
  uiGrace  = 0,
  -- Engine bits, resolved once and remembered as false when a build has none.
  -- Everything here is optional: a build without them leaves the mode simply
  -- unavailable rather than erroring in the frame loop.
  im       = nil,
  cv       = nil,
  ready    = nil,
  -- Was the cursor free before this mode took it? true / false / nil = unknown.
  wasFree  = nil,
}

-- How close the cursor ray has to pass to a gate to pick it, in meters. Gates
-- are up to 120m wide but are PICKED BY THEIR CENTER, because two gates whose
-- rectangles overlap are exactly the case where a generous radius picks the
-- wrong one.
nudge.PICK_RADIUS  = 8
nudge.TURN_PER_STEP = math.rad(5)   -- one scroll notch

local function vehiclePlacement()
  local veh = playerVehicle()
  if not veh then return nil end
  local pos = veh:getPosition()
  local dir = veh:getDirectionVector()
  local len = math.sqrt(dir.x * dir.x + dir.y * dir.y)
  local hx, hy = 0, 1
  if len > 1e-4 then hx, hy = dir.x / len, dir.y / len end
  return { x = pos.x, y = pos.y, z = pos.z, hx = hx, hy = hy }
end

local function clampWidth(w)
  w = tonumber(w) or TUNE.DEFAULT_WIDTH
  if w < TUNE.MIN_WIDTH then w = TUNE.MIN_WIDTH elseif w > TUNE.MAX_WIDTH then w = TUNE.MAX_WIDTH end
  return w
end

local function clampHeight(h)
  h = tonumber(h) or TUNE.DEFAULT_HEIGHT
  if h < TUNE.MIN_HEIGHT then h = TUNE.MIN_HEIGHT elseif h > TUNE.MAX_HEIGHT then h = TUNE.MAX_HEIGHT end
  return h
end

-- Effective rectangle dimensions for a checkpoint: a per-gate override wins,
-- otherwise the global default. Always returned clamped so bad stored data
-- can't produce a degenerate (zero/negative) trigger surface.
-- A gate's size. Every gate placed or loaded now carries its own, so the
-- fallback is only reached by a gate from a layout saved before sizes were
-- per-gate -- and onApplyLayout fills those in from the layout's own stored
-- width/height as it loads, so even they only pass through here once.
local function clampDepth(d)
  d = tonumber(d) or TUNE.DEFAULT_DEPTH
  if d < TUNE.MIN_DEPTH then d = TUNE.MIN_DEPTH elseif d > TUNE.MAX_DEPTH then d = TUNE.MAX_DEPTH end
  return d
end

-- Width across, height ABOVE the placement point, depth BELOW it.
--
-- A gate saved before the two were separate carries a height and no depth, and
-- back then height meant the FULL span, centerd. Splitting it in half here is
-- what makes such a gate keep the exact shape it has always had, rather than
-- silently doubling in size the day this shipped. Anything the editor touches is
-- written back with both fields, so a track only reads this way once.
local function gateDims(wp)
  local w = clampWidth(wp.width or track.checkpointWidth)
  if wp.depth == nil and wp.height ~= nil then
    local half = wp.height * 0.5
    return w, clampHeight(half), clampDepth(half)
  end
  return w, clampHeight(wp.height or track.checkpointHeight),
         clampDepth(wp.depth or track.checkpointDepth)
end

-- ---------------------------------------------------------------------------
-- UI push helpers
-- ---------------------------------------------------------------------------
-- The server needs to know how big this track's grid is so it can warn when
-- there are more drivers than start positions, but it has no way to see the
-- placements. Report the count whenever it actually changes - placing a slot,
-- deleting one, loading a layout - and never more often than that.
local lastReportedStarts = nil
-- Tell the server how many start positions this track has -- and, now, WHERE
-- they are.
--
-- The count alone was enough while the grid was purely a client-side affair: the
-- server handed out slot numbers and only needed to know how many existed. It
-- cannot police the hold with that, though, because "is this car on its slot" is
-- a question about coordinates. So the positions travel too, and the server
-- judges distance itself rather than trusting a client's arithmetic about its
-- own compliance.
--
-- Only sent on a change, which in practice means once when a track is loaded or
-- edited: the payload is a few dozen numbers, not something to repeat.
local function reportStartCount()
  if not inMultiplayer() then return end
  local n = #track.startPositions
  if n == lastReportedStarts then return end
  lastReportedStarts = n
  local positions = {}
  for i, sp in ipairs(track.startPositions) do
    positions[i] = { x = sp.x, y = sp.y, z = sp.z, hx = sp.hx, hy = sp.hy }
  end
  -- Branch gates are NOT reported. The server has no physics and never tests a
  -- crossing, and now that a branch gate carries no name and puts nobody on a
  -- line, there is nothing about one the server could use. It counts checkpoints
  -- cleared, and a branch gate clears the same checkpoint the main gate does.
  TriggerServerEvent('RM_StartPositionCount', jsonEncode({
    count = n, positions = positions,
    gridOffLine = branch.gridIsOff(),
    -- The joker lap cannot be armed on a track with no joker route: the rule
    -- disqualifies anyone who did not complete it, and with no route that is
    -- everyone. The server needs the count to refuse it.
    jokerGates  = #track.jokerRoute,
  }))
end

-- THE LAP NUMBER THAT ENDS THIS DRIVER'S RACE, or nil when nothing does yet.
--
-- This is the client's copy of the server's sessionLapTarget, and it exists
-- because the flags are decided here. A driver's white and checkered flags are
-- per-driver events on their own lap counter, so only this client can wave them
-- -- and it was waving them off `session.totalLaps` alone.
--
-- IN A TIMED RACE THAT IS THE WRONG NUMBER AND ALWAYS WAS. The lap box is inert
-- on the server (nobody knows how many laps ten minutes is), but it was still
-- being broadcast and still being counted against here, so a timed race waved a
-- second white flag and a second checkered flag at whatever the lap box happened
-- to say. Two of each, one pair from the clock and one from a limit that was not
-- being enforced by anything.
--
-- Order matters. lastLapNum wins whenever it is set: once the leader has started
-- the final lap, THAT is the distance, whatever the lap box says and whichever
-- mode armed it.
-- WHICH LAP OF THE RACE THIS DRIVER IS ON, as opposed to how many times they
-- have crossed the line.
--
-- Behind the pace car those are different numbers, and the difference is the
-- whole bug this exists to stop. The formation lap is a crossing nobody is
-- scored for, so `localLap` 1 is the lap run under yellow and `localLap` 2 is
-- racing lap 1.
--
-- IT LIVED INLINE IN checkJokerGates AND NOWHERE ELSE, which is how the joker
-- came to be enforced on one rule and DRAWN on another: the crossing test
-- subtracted the pace lap and the two gate-drawing sites did not, so with a
-- pace lap enabled the joker showed OPEN through the whole of racing lap 1
-- while any attempt on it was being invalidated. A driver taking the gate it
-- was inviting them through lost the run.
--
-- One rule, one function, handed to the renderer through init like the rest.
local function racingLap()
  return (session.localLap or 0) - (session.paceLap and 1 or 0)
end

-- Is the joker still shut for this driver? True on the pace lap and on racing
-- lap 1, which is the rule the crossing test enforces.
local function jokerClosed()
  return racingLap() <= 1
end

local function effectiveLapTarget()
  if track.pointToPoint then return 1 end
  if session.lastLapNum then return session.lastLapNum end
  -- A timed race has no lap target at all until the leader has been past.
  -- Endurance keeps one: it is the other half of "whichever comes first".
  if session.raceMode == 'timed' then return nil end
  -- A HEAT MAY RUN A DISTANCE OF ITS OWN, and the server's raceDistance is the
  -- rule this mirrors: heatLaps when a heat is being run and the number is set,
  -- the race's laps otherwise. Waving these flags off the race's lap box during
  -- an eight-lap heat of a thirty-lap night would end the heat twenty-two laps
  -- late, on this client only.
  local laps = session.totalLaps
  if session.heatCount > 0 and session.heatCurrent > 0 and session.heatLaps > 0 then
    laps = session.heatLaps
  end
  if laps <= 0 then return nil end
  -- A PACE LAP IS A CROSSING NOBODY IS SCORED FOR, so it goes on top of the
  -- distance -- exactly as the server's sessionLapTarget adds it. Waving off the
  -- lap box alone would put the white flag out a lap early on every race started
  -- behind the pace car, and the checkered one a lap early behind it.
  return laps + (session.paceLap and 1 or 0)
end

-- GREEN, YELLOW or WHITE, for this driver, right now.
--
-- Yellow is the server's and beats everything: a caution is a fact about the
-- session. White is the last lap and is per-driver, which is why it cannot be
-- decided server-side for everybody at once. A sprint stage never shows one,
-- having only the one lap there ever was.
local function driverFlag()
  -- CHECKERED FIRST, because it outranks every condition below it. Once a driver
  -- has taken the flag their race is over and stays over: a caution called for
  -- somebody still running, or a red thrown to stop the field, says nothing to
  -- them and showing it would read as their race resuming. It is held until the
  -- session actually ends, which is the moment the lock is released.
  --
  -- Race only. A derby elimination is not a finish and has its own overlay.
  if session.spectatorLock and session.spectatorLock ~= 'derby' then return 'checkered' end
  -- RED NEXT. Held on the grid is a red flag, and so is an admin calling one:
  -- both mean the same thing to a driver, which is that nobody is racing right
  -- now. It is a CONDITION rather than a state change, and the session is still
  -- running underneath it: red goes to yellow, then back to green.
  if session.raceFlag == 'red' or session.phase == 'grid' or session.gridFrozen then return 'red' end
  if session.raceFlag == 'yellow' then return 'yellow' end
  local target = effectiveLapTarget()
  if session.phase == 'racing' and not track.pointToPoint and target
     and session.localLap >= target then
    return 'white'
  end
  -- BLUE, below white and above green. Below white because a driver on their own
  -- last lap is being told their race is ending, which outranks being told to
  -- move over; above green because green is the absence of anything to say.
  --
  -- It sits under the yellow above for a reason a driver would give: nobody is
  -- letting anybody by under a caution. The server stops setting it there too,
  -- so this is agreement rather than a second rule.
  if session.beingLapped then return 'blue' end
  return 'green'
end

-- Cheap fingerprint of everything an admin can author, used to tell an editor
-- buffer that has DRIFTED from the one the server handed over from one that is
-- still exactly as it arrived.
--
-- Counts alone would miss a nudge, and a nudge is the edit somebody is most
-- likely to be part-way through when another admin presses Load. Positions fold
-- in at centimeter resolution deliberately: a fingerprint carrying raw floats
-- would change on physics noise alone and report every buffer as dirty, which
-- would refuse every layout on the server and look exactly like the bug it is
-- meant to fix.
function edit.fingerprint()
  local n = 0
  local function fold(list)
    n = (n * 31 + #list) % 2147483647
    for i = 1, #list do
      local w = list[i]
      n = (n * 31
        + math.floor((w.x or 0) * 100)
        + math.floor((w.y or 0) * 100)
        + math.floor((w.z or 0) * 100)) % 2147483647
    end
  end
  fold(track.route)
  fold(track.jokerRoute)
  fold(track.pitRoute)
  fold(track.startPositions)
  fold(branch.list)
  return n
end

-- Is the local editor holding work that an incoming layout would destroy?
--
-- All three have to be true. The editor is OPEN, so a driver never holds the
-- buffer and never has a layout refused. The buffer has DRIFTED, so an admin
-- sitting in a clean editor still gets layouts normally. And no session is
-- under way, because a layout pushed for a race outranks anything unsaved: the
-- alternative is a driver racing a track nobody else is on.
-- RUNNING A RACE OR CONFIGURING ONE. The line between the two modes, in one
-- place, phrased as the question every caller actually has.
--
-- 'grid' counts as running even though the lights have not gone out: the field
-- is placed and frozen on its slots, and moving a gate under a car already
-- standing on the grid is the same mistake as moving one under a car at speed.
-- Qualifying counts for the obvious reason and used to be missed everywhere --
-- the panel's own guards tested for countdown and racing only, so every editor
-- control in the app was live for the whole of a qualifying session.
-- The DERBY is deliberately not consulted here. It is a separate editor with a
-- separate gate of its own (derbyMarkersEditable, server side), and reaching for
-- it from this far up the file would resolve `derby` as a global: the module is
-- required several thousand lines below this, so the upvalue does not exist yet
-- and the mistake costs a nil index at runtime rather than a compile error.
function edit.running()
  return session.phase == 'grid' or session.phase == 'countdown'
      or session.phase == 'racing' or session.phase == 'qualifying'
end

-- The capability the editor is gated on. ONE function, so a permissions system
-- has one place to plug into rather than a boolean spread through the UI.
--
-- MODE, not identity, and the distinction is load-bearing. Admin is the
-- server's question and it already answers it where it counts: save, load and
-- delete all go through requireAuth, and the panel that reaches them is drawn
-- only for an admin. Asking it again here would break the case with no admin in
-- it at all -- building a track offline, and the headless tests that do the
-- same thing -- for no gain, since a local placement is invisible to everyone
-- else and is overwritten by the server's own layout the moment a grid forms.
function edit.canConfigure()
  return not edit.running()
end

function edit.holdsBuffer()
  if not edit.open then return false end
  if edit.stamp == nil then return false end
  if edit.running() then return false end
  return edit.fingerprint() ~= edit.stamp
end

local function pushRouteState()
  reportStartCount()
  guihooks.trigger('RaceManagerRoute', {
    clientBuild  = RM_BUILD,
    waypoints    = track.route,
    nextWp       = session.armedWp,
    width        = track.checkpointWidth,
    height       = track.checkpointHeight,
    depth        = track.checkpointDepth,
    visualize    = edit.visualize,
    -- Free practice, so the panel can offer the lap target and a way out of it.
    -- lapsLeft is computed here rather than in the UI because the target may be
    -- 0 (unlimited), and "unlimited minus four" is a subtraction the readout
    -- should never be asked to reason about.
    practice       = practice.on,
    practiceLayout = practice.layout,
    practiceLaps   = practice.lapTarget,
    practiceDone   = practice.lapsDone,
    practiceLeft   = (practice.on and practice.lapTarget > 0)
                     and math.max(0, practice.lapTarget - practice.lapsDone) or nil,
    -- Starting grid
    startPositions = track.startPositions,
    pointToPoint   = track.pointToPoint,
    gridSlot       = session.gridSlot,
    gridFrozen     = session.gridFrozen,
    -- Admin session, so a freshly mounted UI app knows straight away that this
    -- client is still logged in (see the isAdmin declaration above).
    isAdmin      = session.isAdmin,
    -- Joker route (Module 2)
    pitRoute     = track.pitRoute,
    pitEntry     = track.pitEntry,
    pitExit      = track.pitExit,
    pitInLane    = pit.inLane,
    pitActive    = pit.active,
    pitLeft      = pit.left,
    jokerRoute   = track.jokerRoute,
    jokerNext    = session.jokerArmed,
    jokerTaken   = session.jokerTaken,
    jokerLap     = session.jokerLapUsed,
    jokerEnabled = session.jokerEnabled,
    -- The pace lap rides here as well as on the server broadcast, so the panel
    -- has it in single player and the instant the switch is thrown rather than
    -- on the next state push.
    paceLap      = session.paceLap,
    pacing       = session.pacing,
    editorTarget = edit.target,
    -- Which flag is out FOR THIS DRIVER. Resolved here rather than in the UI
    -- because the white flag is a fact about one driver's own lap, and the panel
    -- has no idea which lap that is. One field, one meaning, both panels.
    driverFlag   = driverFlag(),
    nudgeOn      = nudge.on,
    nudgeSel     = nudge.sel,
    -- Direction markers: signage, armed by nothing.
    markers      = marker.list,
    markerKind   = marker.kind,
    markerKinds  = marker.KINDS,
    markerLabels = marker.LABEL,
    -- Branch gates (the other ways through a checkpoint)
    branches     = branch.list,
    branchSlot   = branch.editSlot,
    gridOffLine  = branch.gridIsOff(),
    -- Is there a GENERATED grid the spacing sliders may move? They only ever
    -- touch slots the generator laid out; a grid placed by hand is left alone.
    gridGenerated = branch.gridTool.generated,
    gridSpacing   = branch.gridTool.spacing,
    gridStagger   = branch.gridTool.stagger,
    gridWidth     = branch.gridTool.width,
    -- Reset ruleset (Module 1)
    maxResets    = session.maxResets,
    resetsUsed   = session.resetsUsed,
    resetMode    = session.resetMode,
    -- YOUR CAR HAS BEEN TAKEN AWAY, which is not the same question as whether
    -- you entered. A finisher and a driver serving a penalty are both in freecam
    -- without having opted out of anything. Named apart from the entry decision
    -- because they shared one field once, and every route push overwrote "I am
    -- sitting this one out" with "my car is gone".
    carTaken     = session.spectatorLock ~= nil,
  })
end

-- Dedicated, dismissable notice channel for regulation events (reset denied,
-- joker invalidated, vehicle rejected) so they don't get lost among the
-- editor's transient messages.
-- `extra` carries the two things a full-panel flash needs that a strip never
-- did: a second line, and which color the flash is. Optional, so every one of
-- the thirty-odd existing callers keeps working untouched.
-- BeamNG's own Messages HUD app, which is on screen by default for everybody.
--
-- WHY THIS EXISTS AT ALL: every other surface this mod has is its own. The
-- notice strip, the full-panel flash and the red vehicle banner are drawn by
-- the Race Manager app, and the server's chat line needs the chat window open.
-- A driver running with the app minimised and chat closed sees none of them,
-- and "RED FLAG: stop where you are" is not a message that can be allowed to
-- depend on which windows somebody happens to have up.
--
-- ui_message is BeamNG's GE wrapper; the guihooks call underneath it is the
-- fallback for a build that does not expose the wrapper.
--
-- `category` is PER KIND, not one shared string. A category makes a repeat
-- REPLACE the message on screen rather than stack another copy, which is what
-- keeps a repeating notice (a grid hold correction, the config poll) from
-- filling the HUD. Sharing one category across kinds would give that same
-- behavior the wrong way round: a pit call would wipe a red flag.
-- Material icon per kind, because the HUD shows one and a glanced-at icon is
-- read before the words are. Anything not listed falls back to the flag.
local HUD_ICON = {
  vehicle = 'directions_car', spectate = 'visibility', resetsout = 'block',
  pit = 'build', finish = 'emoji_events', grid = 'grid_on',
  session = 'timer', joker = 'alt_route', derby = 'warning',
}

-- TEN SECONDS, not six. A driver reads this at racing speed, out of the corner
-- of an eye, while deciding what to do about the corner in front of them. Six
-- was set when these were mostly confirmations an admin would see; they are the
-- primary channel now, because a regular client has no multiplayer chat app and
-- a message they cannot see is not a message.
local HUD_TTL = 10
local function hudMessage(kind, text, ttl)
  kind = tostring(kind or 'info')
  local category = 'raceManager_' .. kind
  local icon = HUD_ICON[kind] or 'flag'
  if type(ui_message) == 'function' then
    if pcall(ui_message, text, ttl or HUD_TTL, category, icon) then return end
  end
  pcall(guihooks.trigger, 'Message', {
    ttl = ttl or HUD_TTL, msg = text, category = category, icon = icon,
  })
end


-- Which notices leave the app. The test is "would a driver with their eyes on
-- the road have to ACT on this", not "is it interesting".
--
-- So the flags, the out lap, being put out of a session, running out of resets,
-- a refused car, a joker ruling, where you start, a pit call and the derby are
-- all in; the running commentary is not. `reset` ("Reset 2/5 used") and
-- `fastest` are things a driver already knows they did, `ghost` and `server`
-- describe a state that is visible, and `alias` is a name change. Pushing those
-- through as well is how a channel that must be read becomes one that is not.
local HUD_NOTICE = {
  flag = true, session = true, spectate = true, resetsout = true,
  vehicle = true, joker = true, finish = true, grid = true,
  pit = true, derby = true,
}

local function pushNotice(kind, msg, extra)
  local payload = { kind = kind, msg = msg }
  if type(extra) == 'table' then
    payload.sub    = extra.sub
    payload.color = extra.color
  end
  guihooks.trigger('RaceManagerNotice', payload)
  -- ONE FUNNEL, deliberately. Every driver-facing notice in this mod already
  -- comes through here, so the HUD copy is decided in one place by kind rather
  -- than bolted onto forty call sites -- and a notice added later is carried by
  -- whichever kind it is filed under, with no second thing to remember.
  if HUD_NOTICE[kind] then
    hudMessage(kind, payload.sub and (msg .. ': ' .. payload.sub) or msg)
  end
end

-- FLAG TRANSITIONS, which are not the same thing as flag STATE.
--
-- driverFlag() answers "what is this driver's flag right now" and the header
-- glyph asks it every frame. Nothing in a query can tell "still white" from
-- "just went white", and a flash needs the second one. These are the latches
-- that turn the standing state into an event exactly once.
local flags = {
  -- Lap this client has already been shown each approach flag for. An approach
  -- lasts several seconds and is sampled every frame, so without these the
  -- flash would re-arm continuously for the whole run down to the line.
  whiteLap     = nil,
  checkeredLap = nil,
  -- The approach flash already happened, so taking the flag a moment later says
  -- the placing rather than the flag again.
  checkeredSeen = false,
  -- The flag has been shown for this session by whichever of the two paths got
  -- there first.
  checkered = false,
}

-- Every state broadcast from the current server plugin carries this stamp. A
-- broadcast without it comes from an OUTDATED copy of the server plugin still
-- installed alongside this one - two copies alternating broadcasts is exactly
-- what made every UI element flicker between two states on each tick - so
-- unstamped payloads are dropped (and the problem reported once).
local RM_PROTOCOL = 2
local staleServerWarned = false
local function fromCurrentServer(data)
  if type(data) == 'table' and data.rmProtocol == RM_PROTOCOL then return true end
  if not staleServerWarned then
    staleServerWarned = true
    pushNotice('server', 'Ignoring broadcasts from an outdated Race Manager server plugin: '
      .. 'remove old copies from the server\'s Resources/Server folder')
    log('W', 'raceManager', 'Dropped a state broadcast without the current protocol stamp: '
      .. 'an outdated copy of the server plugin appears to be installed alongside this one')
  end
  return false
end

-- ---------------------------------------------------------------------------
-- Gate geometry
-- ---------------------------------------------------------------------------
-- Flat rectangle crossing test. A checkpoint is an upright rectangle centered
-- on (wp.x, wp.y, wp.z), standing perpendicular to the stored heading:
--   forward f = (hx, hy)      the direction the car must be traveling
--   lateral r = (hy, -hx)     span = width
--   up      z                 span = height  (covers the banking)
-- The car scores the gate when its frame-to-frame movement segment crosses the
-- rectangle's plane and the intersection point lands inside the width/height
-- half-extents. Sampling the segment rather than the position means the test
-- never tunnels, no matter how fast the car is going or how thin the gate is.
-- Dimensions are passed in so the same math can be unit-tested headlessly
-- (see tests/gate_test.lua); the live caller feeds gateDims(wp).
--
-- EITHER DIRECTION COUNTS, unless the gate is marked one-way. A driver who
-- missed a checkpoint is already driving back to it, and the forward-only rule
-- made them pass through, turn, and come back. Nothing was protected by it: a
-- gate is ARMED once, and that is what stops it scoring twice, with
-- TUNE.LAP_DEBOUNCE guarding the one-gate route.
--
-- `oneWay` is the per-gate escape hatch for geometry where direction IS the
-- separation: a hairpin or a figure-8 crossover.
--
-- Returns (crossed, backwards). The second matters because a gate shared between
-- both ways is stored with one heading and driven from either side, so relocateToGate
-- cannot read the car's direction off the gate afterwards.
local function rectCrossesGate(wp, prev, cur, w, h, d)
  local fx, fy = wp.hx, wp.hy

  -- Signed distance to the gate plane before and after this frame's movement.
  local dPrev = (prev.x - wp.x) * fx + (prev.y - wp.y) * fy
  local dCur  = (cur.x  - wp.x) * fx + (cur.y  - wp.y) * fy
  local forward  = (dPrev < 0 and dCur >= 0)
  local backward = (not wp.oneWay) and (dPrev > 0 and dCur <= 0)
  if not (forward or backward) then return false end

  local t  = dPrev / (dPrev - dCur)
  local ix = prev.x + (cur.x - prev.x) * t
  local iy = prev.y + (cur.y - prev.y) * t
  local iz = prev.z + (cur.z - prev.z) * t
  local lateral = (ix - wp.x) * fy - (iy - wp.y) * fx
  if math.abs(lateral) > w * 0.5 then return false end
  -- Not symmetric any more: `h` above the placement point, `d` below it. Passing
  -- the two separately is what lets a gate stand tall enough to see without an
  -- equal amount of it being buried under the road.
  local dz = iz - wp.z
  if dz > h or dz < -d then return false end
  return true, backward
end

-- Live wrapper: resolve the gate's effective rectangle dimensions, then run the
-- crossing test. Keeps callers unchanged (segmentCrossesGate(wp, a, b)), and
-- passes the backwards flag straight back out.
local function segmentCrossesGate(wp, prev, cur)
  local w, h, d = gateDims(wp)
  return rectCrossesGate(wp, prev, cur, w, h, d)
end

-- ---------------------------------------------------------------------------
-- Lap logic
-- ---------------------------------------------------------------------------
-- One session is running (the lights are out and laps count). Qualifying and
-- racing are the same thing here on purpose: both start from the grid, both
-- report a lap per completed circuit of the route, and both report it upstream
-- on the same event. Qualifying used to have detection of its own -- an out-lap
-- before the clock started, and no defined starting point because there was no
-- grid -- which is why a three-lap session took five or six laps to get through.
--
-- Qualifying's first lap is given away again (see onOutLap), and deliberately
-- not by going back to that: the crossing is still detected here, still reported
-- on the same event, and the SERVER decides it does not count. What this file
-- does about it is presentation -- it does not show the driver a time for a lap
-- that was not timed.
local function sessionRunning()
  return session.phase == 'racing' or session.phase == 'qualifying'
end

-- ---------------------------------------------------------------------------
-- STICKY HUD STATE
-- ---------------------------------------------------------------------------
-- Some things are not events, they are CONDITIONS: the field is forming up, the
-- race is neutralised, the green is coming at the line. A driver who looks up
-- four seconds after the flash has missed it, and the fact is still true.
--
-- BeamNG replaces a HUD message that shares a category, so a condition is held
-- on screen by simply re-asserting it. That is the whole mechanism: no second
-- message system, and the transient notices go on flashing over the top.
--
-- IT EXPIRES AFTER A LAP OR TWO, counted in LAPS rather than seconds, because
-- that is the unit the thing it describes is measured in. A caution that has run
-- two laps is a caution everybody has seen; leaving it up turns the HUD into
-- furniture and teaches drivers to stop reading it. The panel's own badge stays
-- for as long as the condition really lasts -- that is what a badge is for.
--
-- The seconds cap is a backstop for a driver who is stationary, or out of the
-- car, and therefore completing no laps at all.
local sticky = {
  key = nil, lap = 0, left = 0, due = 0,
  LAPS    = 2,
  MAX_SEC = 180,
  REFRESH = 2.0,
}

-- What the HUD should be holding up right now, or nil. Ordered by what a driver
-- has to act on FIRST, and only one is ever showing: these conditions exclude
-- each other on the road even where the flags overlap.
local function stickyMessage()
  if not sessionRunning() or session.spectatorLock then return nil end
  if session.pacing then
    return 'pace', 'PACE LAP - hold position, 40 mph / 64 km/h. Green at the line.'
  end
  if session.restartPending then
    return 'restart', 'RESTART THIS LAP - green as the leader reaches the line. Get ready.'
  end
  if session.cautionPending then
    return 'caution', 'CAUTION - race back to the line. Positions lock as you complete this lap.'
  end
  if session.caution then
    return 'caution', 'CAUTION - hold position, no overtaking. Places are frozen.'
  end
  return nil
end

local function stickyUpdate(dt)
  local key, text = stickyMessage()
  if not key then
    sticky.key = nil
    return
  end
  if key ~= sticky.key then
    -- A NEW CONDITION, so the allowance starts again. "Race back to the line"
    -- becoming "positions frozen" is a different instruction, not the same one
    -- continuing, and a driver gets the full two laps to read each of them.
    sticky.key, sticky.lap = key, session.localLap or 0
    sticky.left, sticky.due = sticky.MAX_SEC, 0
  end
  sticky.left = sticky.left - dt
  sticky.due  = sticky.due - dt
  local lapsShown = (session.localLap or 0) - sticky.lap
  if sticky.left <= 0 or lapsShown > sticky.LAPS then return end
  if sticky.due > 0 then return end
  sticky.due = sticky.REFRESH
  -- Slightly longer than the refresh, so the message never blinks out between
  -- two assertions on a frame that ran late.
  hudMessage('flag', text, sticky.REFRESH + 2)
end

local function resetLapTracking()
  session.timingActive = false
  session.lapStart     = localTime
  session.localLap     = 1
  timingReset()
  session.prevPos      = nil
  -- The flags go with the session. A white flag latched on lap 4 of the last
  -- race would suppress it on lap 4 of the next one, and a checkered left set
  -- would suppress it entirely.
  flags.whiteLap      = nil
  flags.checkeredLap  = nil
  flags.checkeredSeen = false
  flags.checkered     = false
  -- Joker credit and the reset allowance are per-session too: a new phase means
  -- a clean sheet on both.
  session.jokerArmed   = 1
  session.jokerTaken   = false
  session.jokerLapUsed = nil
  session.resetsUsed   = 0
  lastGate     = nil
  lastGateBack = false
  block.noticeLeft = 0   -- a fresh session may report its first blocked attempt at once
  -- Telemetry restarts with the session; report immediately on the next frame
  -- so the leaderboard has a distance for this driver from the first moments.
  progressLeft = 0
  -- Cars launch from the grid at the line, so the first target is checkpoint 1
  -- and detection is live from GO - for a qualifying session exactly as much as
  -- for a race. (In qualifying that first circuit is the out lap: it is detected
  -- and reported like any other, and the server is what declines to score it.
  -- Nothing here stops timing, because a lap the client did not measure is a lap
  -- the client cannot report.) Outside a running session the start/finish line is
  -- armed, so a driver pottering about before the lights still gets sensible
  -- gate colors.
  if sessionRunning() then
    session.armedWp = 1
    session.timingActive = true
  elseif session.phase == 'grid' or session.phase == 'countdown' then
    -- STANDING ON THE GRID IS STANDING AT THE LINE, so the gate ahead is
    -- checkpoint 1, exactly as it will be a second later at GO. Arming the
    -- finish line here highlighted the gate BEHIND the field and dimmed CP1 as
    -- "the one after", so both markers a driver reads while waiting for the
    -- lights were one gate late, and the first corner was the one not shown.
    --
    -- Presentation only: checkGates refuses to run outside a running session,
    -- so nothing can be crossed or scored from the grid.
    session.armedWp = 1
  else
    session.armedWp = math.max(#track.route, 1)
  end
  pushRouteState()
end

-- Strict track-state purge: throw away every checkpoint table and reset lap
-- tracking to a virgin state. The 3D gate poles are immediate-mode
-- debugDrawer shapes redrawn from `route` every frame, so emptying the table
-- removes them from the world on the next update tick - nothing else holds a
-- reference to them. Runs before any new layout is applied and whenever the
-- server broadcasts RM_ClearTrack, so ghost checkpoints from an earlier
-- session cannot survive.
local function clearTrackState(reason)
  track.route        = {}
  track.jokerRoute   = {}
  -- The pit lane goes too. Stalls used to survive a purge, stay standing on the
  -- next track, and ride along into the next save.
  track.pitRoute     = {}
  track.pitEntry     = {}
  track.pitExit      = {}
  track.startPositions = {}
  session.gridSlot     = nil
  session.armedWp      = 1
  session.jokerArmed   = 1
  session.jokerTaken   = false
  session.jokerLapUsed = nil
  session.timingActive = false
  session.localLap     = 1
  session.lapStart     = localTime
  timingReset()
  session.prevPos      = nil
  progressLeft = 0
  lastGate     = nil
  lastGateBack = false
  -- Markers go too. They arm nothing, so a stray one cannot affect a lap -- but
  -- a sign pointing left on a track that no longer turns left is worse than no
  -- sign, and it would ride along into the next save.
  marker.list   = {}
  -- The branch gates go with the main ones. One left standing after a purge would
  -- arm a gate from a track that is no longer loaded.
  branch.list   = {}
  branch.bySlot = {}
  branch.gridOffLine = false
  branch.editSlot    = 1
  pushRouteState()
  log('I', 'raceManager', 'Track state cleared (' .. tostring(reason or 'local') .. ')')
end

-- UI/console entry point: purge locally and, when on a BeamMP server, ask the
-- server to broadcast the purge to every client.
function M.clearTrackState()
  clearTrackState('ui request')
  if inMultiplayer() then TriggerServerEvent('RM_ClearTrackState', '') end
end

-- Nothing loaded: no race track, no derby arena, one press.
--
-- The local purge runs either way so the button does something offline too, but
-- on a server the SERVER is what makes it stick: it clears its own copy, tells
-- every other client, and refuses the whole thing if a session or a derby is
-- running. Purging here first would otherwise leave this one admin looking at an
-- empty map that nobody else agrees with.
function M.clearEverything()
  clearTrackState('clear everything')
  if inMultiplayer() then
    TriggerServerEvent('RM_ClearEverything', '')
  else
    -- pushNotice, not editorMsg. editorMsg is declared five thousand lines
    -- below this and would resolve to a nil global here: it compiles clean and
    -- throws the first time somebody presses the button offline.
    pushNotice('session', 'Cleared: nothing is loaded')
  end
end

-- Is the lap this driver is on the out lap -- the one that is given away?
--
-- Worked out locally rather than read off this client's own driver row, and the
-- distinction matters: the row is authoritative but arrives on a broadcast three
-- times a second, so a readout driven by it would go on saying NOT TIMED for up
-- to a third of a second after the driver had crossed the line and started a
-- lap that very much was. The two agree by construction - both count crossings
-- from the grid, and the server's rule (qualiOutLap) is what gates this.
--
-- The server's flag is no longer qualifying's alone: a RACE on a track that grids
-- its cars away from the start/finish line owes one for the same reason, so the
-- phase test is gone and the session rule is the only thing deciding it. The wire
-- field kept its old name; what it means widened underneath.
-- The spectator test is here rather than at the two call sites because it is true
-- of both of them: a driver who has taken the flag is neither on an out lap for
-- the HUD's purposes nor owed an armed gate for the crossing code's.
local function onOutLap()
  return qualiOutLap and sessionRunning() and session.localLap <= 1 and not session.spectatorLock
end

local function onLapCompleted()
  local lapTime = localTime - session.lapStart
  if session.timingActive and lapTime < TUNE.LAP_DEBOUNCE then return end  -- double-fire guard

  -- Hand the finished time to this driver's own HUD so it can hold it on screen
  -- long enough to read. Display only, and deliberately separate from the
  -- reports above: the server is still told the same lapTime it always was, and
  -- lapStart is reset either way, so the lap clock never pauses for the hold.
  local function announceLap(n)
    -- DELTA TO THE PREVIOUS LAP, not to the best one. "Am I still improving"
    -- is the question a driver asks at the line, and against a best lap the
    -- answer is +ve for most of a race once a good one is set, which stops
    -- telling them anything. The SECTOR readout compares to best instead --
    -- different question, different baseline.
    --
    -- nil on the first timed lap: there is nothing to compare it to, and a
    -- delta of 0.000 would be a lie rather than a blank.
    local delta = timing.prevLap and (lapTime - timing.prevLap) or nil
    timing.prevLap = lapTime
    guihooks.trigger('RaceManagerLapDone', { lapTime = lapTime, lap = n, delta = delta })
  end

  -- ONE report, for both kinds of session, and for the out lap as much as for a
  -- scored one. The server knows which session is running and scores the lap
  -- accordingly (best lap in qualifying, running order and laps led in a race,
  -- nothing at all for the out lap); the client's job is only to say "that was a
  -- lap, and it took this long". The separate RM_QualiLap channel this replaced
  -- is what let qualifying's lap counting drift away from the race's, and a
  -- client that withheld the out lap because it knew it would not be scored
  -- would be the same mistake in a new place -- the server needs the crossing
  -- either way, to advance the lap counter and clear the checkpoint telemetry.
  -- A PRACTICE LAP IS ANNOUNCED AND NEVER REPORTED. It is the only path here
  -- that returns before the server is told anything: no RM_Lap, so no
  -- leaderboard row, no best lap, no cup round, and nothing for a real session
  -- to notice. There is no out lap either -- practice starts when the driver
  -- says so, from wherever they are.
  if practice.on then
    practice.lapsDone = practice.lapsDone + 1
    announceLap(practice.lapsDone)
    log('I', 'raceManager', string.format('Practice lap %d: %.3fs',
      practice.lapsDone, lapTime))
    session.lapStart = localTime
    timing.sectors = {}
    return
  end
  if not sessionRunning() then return end
  local outLap = onOutLap()
  if inMultiplayer() then
    TriggerServerEvent('RM_Lap', jsonEncode({ lapTime = lapTime }))
  end
  if outLap then
    -- No time is presented for a lap that was not timed. The readout says what
    -- happened instead, and the notice channel says what happens next -- this is
    -- the moment the driver most needs to know their timing has started, and it
    -- is the moment they are least able to go looking for it.
    guihooks.trigger('RaceManagerLapDone', { outLap = true, lap = session.localLap })
    -- Qualifying only. In a race the first lap is scored either way, so
    -- "you are on a TIMED lap now" is answering a question nobody asked and
    -- lands in the middle of the first corner.
    if session.phase == 'qualifying' then
      pushNotice('session', 'OUT LAP COMPLETE: you are on a TIMED lap now')
    end
    log('I', 'raceManager', string.format('Out lap done: %.3fs (not timed)', lapTime))
  else
    announceLap(session.localLap)
    log('I', 'raceManager', string.format('Lap %d done: %.3fs (%s)',
      session.localLap, lapTime, session.phase))
  end
  session.localLap = session.localLap + 1
  session.lapStart = localTime
  -- A new lap starts a new set of sectors. The stamp is NOT reset here -- the
  -- crossing that ended the lap already moved it, and resetting again would
  -- hand sector 1 of the next lap the few microseconds in between.
  timing.sectors = {}
end

-- ---------------------------------------------------------------------------
-- Joker route detection (Module 2)
-- ---------------------------------------------------------------------------
-- The joker gates are crossed in their own order, tracked independently of the
-- main route so a driver diverting onto the alternate loop keeps their main
-- checkpoint progress. Two rules are enforced here, on the only side that can
-- see the car move:
--   * Lap 1 restriction - any joker attempt started on lap 1 is invalidated
--     outright (progress thrown away, nothing reported to the server).
--
--     LAP 1 IS A RACING LAP, NOT A CROSSING. Behind the pace car the first
--     crossing is the formation lap, so `localLap` 1 is the lap run under yellow
--     and `localLap` 2 is the lap the race actually starts on. Tested against
--     the raw counter, the rule closed the joker on the formation lap -- where
--     nobody was going to take it anyway -- and left it OPEN on the first racing
--     lap, which is the one lap it exists to close.
--   * Once per race - a completed joker route is reported exactly once; every
--     later run is ignored and flagged to the driver.
local function checkJokerGates(prev, cur)
  if not session.jokerEnabled or #track.jokerRoute == 0 then return end
  if session.phase ~= 'racing' then return end
  local wp = track.jokerRoute[session.jokerArmed]
  if not wp or not segmentCrossesGate(wp, prev, cur) then return end

  -- The lap of the RACE this driver is on, and the same rule the gates are DRAWN
  -- with. Behind the pace car it is one less than the number of times they have
  -- crossed the line, because the first of those crossings ended a lap nobody
  -- was scored for. Reported as well as tested: the results file prints
  -- "joker: lap 4", and a driver whose board said lap 3 cannot reconcile the two.
  local lapNow = racingLap()
  if jokerClosed() then
    -- Lap 1: the attempt never counts. Re-arm from the first joker gate so a
    -- legal run on a later lap still works.
    session.jokerArmed = 1
    pushNotice('joker', 'JOKER LAP NOT ALLOWED ON LAP 1: attempt invalidated')
    log('W', 'raceManager', 'Joker route attempted on lap 1: attempt invalidated')
    pushRouteState()
    return
  end

  if session.jokerTaken then
    session.jokerArmed = 1
    pushNotice('joker', 'Joker Lap already taken: this run does not count')
    pushRouteState()
    return
  end

  if session.jokerArmed >= #track.jokerRoute then
    -- REPORTED AS THE RACING LAP, for the same reason the leaderboard counts
    -- them: the results file prints "joker: lap 4", and a driver whose board
    -- said lap 3 at that moment has no way to reconcile the two.
    session.jokerTaken   = true
    session.jokerLapUsed = lapNow
    session.jokerArmed   = 1
    if inMultiplayer() then
      TriggerServerEvent('RM_JokerLap', jsonEncode({ lap = lapNow }))
    end
    pushNotice('joker', 'JOKER LAP COMPLETE (lap ' .. lapNow .. ')')
    log('I', 'raceManager', 'Joker route completed on lap ' .. lapNow)
  else
    session.jokerArmed = session.jokerArmed + 1
  end
  pushRouteState()
end

-- ---------------------------------------------------------------------------
-- Branching routes: did this movement clear slot i, by any of its gates?
-- ---------------------------------------------------------------------------
-- The main gate first, then any branch gate authored against the same slot.
-- Returns the gate that was crossed and whether it was taken backwards, or nil.
--
-- On a track with no branch gates `bySlot[i]` is nil, so this costs one table
-- index more than testing the main gate alone -- which is every track that
-- existed before this, and most of the ones that come after. On a branched slot
-- it is one segment test per gate, and a slot has two of them in practice.
--
-- Hung off the branch table rather than given a local of its own, for the
-- register budget noted where that table is declared.

-- Does this track grid its cars somewhere other than the start/finish line?
--
-- Inferred rather than asked for. An admin who put the grid somewhere else has
-- already said so by putting it there, and a switch they have to remember to set
-- is a switch they will forget -- which here costs the whole field a fastest lap
-- nobody drove.
--
-- Two signals, either of which settles it:
--   * A start position facing AGAINST the start/finish line. That is a head-on
--     layout, where one row of slots on the line is impossible by construction.
--   * A start position further from the line than any grid is long. A sixty-car
--     grid at eight meters a row is under 250m, so beyond that it is not a grid
--     stretching back from the line, it is a grid somewhere else on the circuit.
function branch.gridIsOff()
  local sf = track.route[#track.route]
  if not sf or #track.startPositions == 0 then return false end
  local r2 = TUNE.GRID_ON_LINE_RANGE * TUNE.GRID_ON_LINE_RANGE
  for _, sp in ipairs(track.startPositions) do
    if (sp.hx or 0) * (sf.hx or 0) + (sp.hy or 1) * (sf.hy or 1) < 0 then return true end
    local dx, dy = sp.x - sf.x, sp.y - sf.y
    if dx * dx + dy * dy > r2 then return true end
  end
  return false
end

function branch.crossedAt(i, p0, p1)
  local wp = track.route[i]
  if wp then
    local crossed, backwards = segmentCrossesGate(wp, p0, p1)
    if crossed then return wp, backwards end
  end
  local alts = branch.bySlot[i]
  if alts then
    for k = 1, #alts do
      local crossed, backwards = segmentCrossesGate(alts[k], p0, p1)
      if crossed then return alts[k], backwards end
    end
  end
  return nil, false
end

-- The gate for slot i nearest this position, which on a checkpoint with branch
-- gates is the one this car is actually driving towards. Ranking a head-on field
-- by the distance to a gate half of them are driving AWAY from would put one
-- whole direction last all race.
function branch.nearestAt(i, pos)
  local best = track.route[i]
  local alts = branch.bySlot[i]
  if not alts then return best end
  local bd = math.huge
  if best then
    local dx, dy, dz = pos.x - best.x, pos.y - best.y, pos.z - best.z
    bd = dx * dx + dy * dy + dz * dz
  end
  for k = 1, #alts do
    local g = alts[k]
    local dx, dy, dz = pos.x - g.x, pos.y - g.y, pos.z - g.z
    local d = dx * dx + dy * dy + dz * dz
    if d < bd then best, bd = g, d end
  end
  return best
end

-- Run `fn` over every gate that clears slot i: the main one, then its branch
-- gates. Takes a callback rather than returning a list because the drawing pass
-- calls it every frame and a list would be an allocation per gate per frame.
function branch.eachAt(i, fn, arg)
  local wp = track.route[i]
  if wp then fn(wp, arg) end
  local alts = branch.bySlot[i]
  if alts then
    for k = 1, #alts do fn(alts[k], arg) end
  end
end

local function checkGates()
  if session.spectatorLock then return end     -- out of the session: no more timing
  if #track.route == 0 and #track.jokerRoute == 0 then return end
  -- ...or while practising, which is the whole of what makes practice timed.
  -- Everything else about a session stays switched off.
  if not practice.on
     and session.phase ~= 'qualifying' and session.phase ~= 'racing' then return end
  local veh, pos = sampledVehicle()
  if not veh or not pos then return end
  if session.prevPos then
    -- The checkpoint this car must clear next, by whichever of its gates the car
    -- drives through. Nothing is carried between slots: the next one is decided
    -- the same way from scratch, which is what a branch gate being another way
    -- through CP i, rather than a lane the driver is on, actually means.
    --
    -- THE OUT LAP ARMS THE CHECKPOINTS LIKE ANY OTHER LAP. An earlier version
    -- armed only the start/finish line on the reasoning that a lap nobody is
    -- scoring has nothing to police -- which is true, and which also took the
    -- checkpoints off the driver's screen for the whole of their first lap. The
    -- out lap is the lap where a driver least knows the circuit; it is the worst
    -- possible one to hide the gates on.
    --
    -- The line is accepted as well, further down, so a car gridded PAST slot 1
    -- (which a head-on layout does, spreading its grid round the circuit) can
    -- still end the out lap by reaching the line rather than being sent most of
    -- the way round backwards to arm a gate behind it.
    local onOut = onOutLap()
    local wp, backwards = branch.crossedAt(session.armedWp, session.prevPos, pos)
    local crossed = wp ~= nil

    -- On the out lap the LINE ends the lap from wherever the driver has got to,
    -- even with slots still uncleared. Nothing on this lap is scored, so there is
    -- nothing to protect by making them go back for a gate.
    --
    -- BUT ONLY ONCE THEY HAVE ACTUALLY GONE SOMEWHERE. A grid sits BEHIND the
    -- start/finish line on an ordinary circuit, so the line is the first gate a
    -- driver reaches: seconds after the green, with nothing cleared, this ended
    -- the out lap and started timing. Measured from a live log, out laps
    -- "completed" in 2.1s, 2.4s, 4.4s and 5.6s. The formation lap is mechanically
    -- an out lap, so the same crossing dropped the green the moment the leader
    -- rolled over the line.
    --
    -- Requiring a cleared checkpoint says the difference plainly: reaching a line
    -- you have not driven a route to is not completing a lap.
    --
    -- ONE RULE, NO GEOMETRY. An earlier attempt let gridIsOff() waive this, to
    -- keep the head-on case the shortcut was written for. That is a 250 m
    -- distance test, so a grid merely set further back down the straight would
    -- have gone on ending its out lap in seconds: the same bug, hiding behind a
    -- threshold.
    --
    -- The head-on car is not stranded by this. It clears nothing on the way to
    -- the line, so it simply runs on to slot 1 and starts its lap there. That is
    -- a longer out lap, never a backwards one, and never a two-second one.
    local lineEndedOutLap = false
    if onOut and not crossed and session.armedWp > 1
        and session.armedWp < #track.route then
      local line = track.route[#track.route]
      if line then
        crossed, backwards = segmentCrossesGate(line, session.prevPos, pos)
        if crossed then wp, lineEndedOutLap = line, true end
      end
    end

    if crossed then
      lastGate     = wp   -- the "Last Checkpoint" reset mode respawns here
      lastGateBack = backwards
      -- BACK ON THE RACING LINE, so the pit lane is behind us however we left
      -- it. The exit gate is the tidy way out; this is the one that cannot be
      -- missed, and without it a driver who drove past the exit would carry the
      -- stall markers to the flag.
      if pit.inLane then pit.leaveLane('cleared a checkpoint') end

      -- SECTOR CLOSED. Every checkpoint ends one, so the sector number is the
      -- gate number and the last sector of a lap ends at the line.
      --
      -- Taken BEFORE the armedWp branches below, because one of them calls
      -- onLapCompleted, which moves session.lapStart out from under this.
      --
      -- The out lap is stamped but never scored: it is a lap driven from a
      -- standing start, and letting it set the best sector would leave every
      -- later comparison measured against a time nobody was trying to beat.
      do
        local n = session.armedWp
        local sectorTime = localTime - timing.sectorStart
        timing.sectorStart = localTime
        -- NOT ON A BACKWARDS CROSSING. Reversing through the gate ahead still
        -- clears it -- that is the route's rule, and the "Last Checkpoint"
        -- reset mode depends on it -- but a sector closed by driving backwards
        -- through its end is not a time anybody drove. It would also poison the
        -- best, which every later delta is then measured against.
        if sectorTime > 0 and not backwards and not onOutLap() then
          timing.sectors[n] = sectorTime
          local best = timing.bestSector[n]
          local delta = best and (sectorTime - best) or nil
          if not best or sectorTime < best then timing.bestSector[n] = sectorTime end
          guihooks.trigger('RaceManagerSector', {
            sector = n, count = #track.route, time = sectorTime,
            delta = delta, best = not best or sectorTime <= timing.bestSector[n],
          })
        end
      end
      if lineEndedOutLap then
        -- Reached the line with slots still owing. The out lap is over; slot 1
        -- arms behind it with timing running. onLapCompleted reports the crossing
        -- like any other -- the SERVER is what declines to score it, exactly as
        -- it always has for qualifying.
        onLapCompleted()
        session.armedWp = 1
      elseif session.armedWp >= #track.route then
        onLapCompleted()
        session.armedWp = 1
      else
        session.armedWp = session.armedWp + 1
      end
      -- Clearing a checkpoint is exactly when a position can change hands, so
      -- jump the throttle and report the new count on the next frame.
      progressLeft = 0
      pushRouteState()
    end
    checkJokerGates(session.prevPos, pos)
  end
  -- THE CARRY-OVER SAMPLE, MUTATED IN PLACE.
  --
  -- This was the one allocation left in a steady frame, and it did not have to
  -- be one: every consumer (rectCrossesGate, branch.crossedAt, checkJokerGates,
  -- and the recovery-undo test in onVehicleResetted) reads .x/.y/.z and nothing
  -- else. No vec3 method, no operator, and none of them keeps the reference past
  -- the call. A plain table reused frame to frame takes a driver's draw path to
  -- zero allocations.
  --
  -- Anything that starts doing vec3 ARITHMETIC on prevPos has to allocate its
  -- own copy rather than change this back.
  local pp = session.prevPos
  if pp then
    pp.x, pp.y, pp.z = pos.x, pos.y, pos.z
  else
    session.prevPos = { x = pos.x, y = pos.y, z = pos.z }
  end
end

-- ---------------------------------------------------------------------------
-- Live lap clock (display only)
-- ---------------------------------------------------------------------------
-- Strictly a HUD feed. The lap time that counts is still the one measured at
-- the crossing in onLapCompleted and scored by the server; nothing here is ever
-- reported upstream or used for timing. The UI interpolates forward from the
-- last push with its own clock, so this cadence sets the correction rate, not
-- the visible frame rate of the readout.
local lapTimeLeft    = 0
local lapTimerArmed  = false     -- was the clock running on the previous tick?

local function lapTimerUpdate(dt)
  -- Running whenever this client's own lap clock is: any session from GO
  -- onwards (both kinds start from the grid with the clock already on), AND
  -- free practice.
  --
  -- PRACTICE WAS MISSING, and it took the sector times with it. checkGates
  -- already runs in practice, so every sector was being closed and pushed - but
  -- the app draws the sector readout INSIDE the lap-time block, and that block
  -- only appears when there is a lap clock or a held lap time. With no clock,
  -- the only moment anything showed was the instant a lap completed and parked a
  -- time there, by which point the sector on hold was the last one of the lap.
  -- Hence "only the final sector and the lap time, at the line".
  local running = sessionRunning() or practice.on
  if not running then
    -- Tell the UI once on the way down so it can drop the readout instead of
    -- leaving the last value frozen on screen looking like a stalled clock.
    if lapTimerArmed then
      lapTimerArmed = false
      guihooks.trigger('RaceManagerLapTime', { running = false })
    end
    return
  end
  lapTimerArmed = true
  lapTimeLeft = lapTimeLeft - dt
  if lapTimeLeft > 0 then return end
  lapTimeLeft = TUNE.LAP_TIME_EVERY
  guihooks.trigger('RaceManagerLapTime', {
    running = true,
    -- session.localLap does not move in practice: onLapCompleted counts practice
    -- laps in practice.lapsDone and returns before the session counter. Reading
    -- it here would leave the readout saying LAP 1 all afternoon.
    lap     = practice.on and (practice.lapsDone + 1) or session.localLap,
    elapsed = localTime - session.lapStart,
    -- The clock still runs and is still sent; what changes is what the app is
    -- allowed to do with it. On the out lap it shows the lap for what it is
    -- instead of a number that looks like a time being taken -- a driver
    -- watching a lap clock tick has every reason to think it counts.
    outLap  = onOutLap(),
  })
end

-- ---------------------------------------------------------------------------
-- Live position telemetry
-- ---------------------------------------------------------------------------
-- The server decides the running order but has no physics access, so the third
-- tie-break metric - how far a car is from the next checkpoint - can only be
-- measured here. A few times a second that distance goes up to the server
-- together with the lap and the number of checkpoints already cleared on it. The
-- send is throttled (TUNE.PROGRESS_EVERY) so a full grid costs the server a
-- handful of small events per second, not one per frame per driver.
--
-- The DISTANCE is throttled with it. It used to be recomputed every frame -- a
-- vehicle query and a square root -- for a value that is only ever read by the
-- payload below, so ~55 out of every 60 were thrown away unused.
-- THE WHITE FLAG, WAVED AT THIS DRIVER, on the run down to the line that starts
-- their last lap.
--
-- Per driver, and it has to be: the field is spread around the circuit and the
-- leader takes the flag a lap before the backmarkers do. It follows the local
-- lap counter for the same reason everything else about this driver's lap does.
--
-- Runs every frame rather than off the throttled position report, because that
-- report fires every 0.3 s and a car at 90 mph covers twelve meters between two
-- of them: the flag would appear anywhere between here and the line. The cost of
-- that is paid back in the early-outs, which are ordered cheapest first and
-- reject on a single integer compare for every driver who is not on the
-- second-to-last lap. Nothing is allocated and the vehicle is not touched until
-- everything else has already passed.
local function whiteFlagWatch()
  if session.phase ~= 'racing' or session.spectatorLock then return end
  -- Driving at the start/finish line specifically. The last checkpoint IS the
  -- line, so any other armed gate means this driver is still out on the lap.
  if session.armedWp ~= #track.route or #track.route == 0 then return end

  -- WHICH FLAG IS ON THIS APPROACH, if either.
  --
  -- The last lap is announced on the run down to the line that STARTS it, and
  -- the finish on the run down to the line that ends it. Same fifty meters,
  -- same per-driver lap counter, one lap apart -- so they are one watcher
  -- rather than two that could disagree about where the line is.
  --
  -- A sprint stage has no white flag (there is no earlier lap to be waved at
  -- on) but very much has a finish, so point-to-point only rules out the first.
  local which, latch
  if track.pointToPoint then
    -- A SPRINT IS DRIVEN ONCE. Its last gate is a finish rather than a line you
    -- come back round to, so the only approach there is is the one to it -- and
    -- the lap counter never reaches a lap TARGET to compare against, which is
    -- why this cannot be folded into the test below.
    which, latch = 'checkered', 'checkeredLap'
  else
    -- nil target = a timed race whose leader has not been past yet. There is no
    -- lap to be waved at, and waving one off the inert lap box is exactly the
    -- bug this replaces.
    local target = effectiveLapTarget()
    if not target then return end
    if session.localLap >= target then
      which, latch = 'checkered', 'checkeredLap'
    elseif target > 1 and session.localLap == target - 1 then
      -- The lap BEFORE the last one, so the white flag is waved on the approach
      -- that starts the final lap. In a timed race this is how a driver behind
      -- the leader is told: lastLapNum landed while they were mid-lap, and this
      -- is their run down to the line that begins it.
      which, latch = 'white', 'whiteLap'
    else
      return
    end
  end
  if flags[latch] == session.localLap then return end

  local _, pos = sampledVehicle()
  if not pos then return end
  local wp = track.route[#track.route]
  if not wp then return end
  local dx, dy, dz = pos.x - wp.x, pos.y - wp.y, pos.z - wp.z
  -- Squared, so the per-frame path never takes a square root.
  local limit = TUNE.WHITE_FLAG_AT * TUNE.WHITE_FLAG_AT
  if (dx * dx + dy * dy + dz * dz) > limit then return end

  flags[latch] = session.localLap
  if which == 'checkered' then
    -- The APPROACH flash. Taking the flag pushes one of its own off the
    -- spectator lock a moment later, carrying the placing; this one is the
    -- marshal leaning out as the driver comes down the straight, and it is
    -- latched separately so the two cannot collapse into one.
    flags.checkeredSeen = true
    pushNotice('flag', 'CHECKERED FLAG', { sub = 'Finish line', color = 'checkered' })
  else
    pushNotice('flag', 'WHITE FLAG', { sub = 'Last lap', color = 'white' })
  end
end

local function reportProgress(dt)
  if not sessionRunning() or session.spectatorLock then return end
  if #track.route == 0 then return end

  progressLeft = progressLeft - dt
  if progressLeft > 0 then return end

  local veh, pos = sampledVehicle()
  if not veh or not pos then return end
  progressLeft = TUNE.PROGRESS_EVERY

  -- The gate THIS car is driving towards. A checkpoint with a branch gate has
  -- more than one, and which of them is nearest is the only honest answer to
  -- that: it needs the car's position, so it is resolved here rather than above.
  local wp = onOutLap() and track.route[#track.route] or branch.nearestAt(session.armedWp, pos)
  if not wp then return end

  -- Distance from the car to the center of the next checkpoint, in meters.
  local dx, dy, dz = pos.x - wp.x, pos.y - wp.y, pos.z - wp.z

  -- armedWp is the gate we are driving TOWARDS, so the count already cleared on
  -- this lap is one less (and 0 right after crossing the start/finish line).
  local payload = {
    lap  = session.localLap,
    cp   = session.armedWp - 1,
    dist = math.sqrt(dx * dx + dy * dy + dz * dz),
  }
  if inMultiplayer() then
    TriggerServerEvent('RM_Progress', jsonEncode(payload))
  end
  -- Same cadence to the local UI, so the driver's own header readout ticks
  -- along with what the server is being told.
  guihooks.trigger('RaceManagerProgress', payload)
end

-- ===========================================================================
-- Vehicle & setup capture (Module 4)
-- ===========================================================================
-- The server cannot see what a player is driving beyond the jbeam model name,
-- so the exact configuration is fingerprinted here: model + every part in the
-- part config + every tuning variable, flattened into one deterministic string.
-- The admin's "Whitelist Current Vehicle" sends that signature to build the
-- Garage List; every client sends its own signature whenever its vehicle
-- changes, and the server removes anything that doesn't match.

-- Deterministic flattening: keys sorted, numbers fixed to 4 decimals, so two
-- identical setups always produce byte-identical signatures.
local function stableSerialize(tbl)
  if type(tbl) ~= 'table' then return '' end
  local entries = {}
  for k, v in pairs(tbl) do
    local val
    if type(v) == 'number' then
      val = string.format('%.4f', v)
    elseif type(v) == 'table' then
      val = 'table'
    else
      val = tostring(v)
    end
    entries[#entries + 1] = tostring(k) .. '=' .. val
  end
  table.sort(entries)
  return table.concat(entries, ';')
end

-- Human-readable name of a saved setup. Until BeamNG v0.39 the .pc filename WAS
-- the name the player typed, so reading the filename stem was enough. v0.39
-- changed that ("Changed naming of the custom config files": the name now lives
-- in the vehicle's info.json and the .pc filename is only a sanitised
-- derivative of it), which left the Garage List showing a mangled filename
-- instead of the setup's actual name. The real name is looked for on the config
-- table first - under whichever key the build carries it - and the filename stem
-- is kept as the last resort so older builds behave exactly as before.
local function configDisplayName(cfg)
  if type(cfg) ~= 'table' then return nil end
  for _, key in ipairs({ 'configName', 'name', 'title' }) do
    local v = cfg[key]
    if type(v) == 'string' and v ~= '' then return v end
  end
  if type(cfg.partConfigFilename) == 'string' then
    return cfg.partConfigFilename:match('([^/\\]+)%.pc$')
  end
  return nil
end

-- The BeamNG build this client is running. A game update can rename vehicle
-- parts (v0.39 did: "Renamed a bunch of parts on some vehicles to unify part
-- names with other vehicles"), and a renamed part changes the configuration
-- signature below without the car itself changing at all - so every Garage List
-- entry captured on an older build silently stops matching. Reporting the
-- version lets the server say THAT, instead of leaving drivers rejected with no
-- explanation. nil when the build cannot be identified; the server treats that
-- as "unknown", never as a mismatch.
local function gameVersion()
  for _, name in ipairs({ 'beamng_versionb', 'beamng_version', 'beamng_buildinfo' }) do
    local ok, v = pcall(function () return _G[name] end)
    if ok and type(v) == 'string' and v ~= '' then return v end
  end
  return nil
end

-- Snapshot of the vehicle the local player is currently driving.
--
-- TWO SIGNATURES, NOT ONE, because parts and tuning are different rules. A
-- league locks the PARTS (a spec series is a spec series) while leaving tuning
-- and paint to the driver, and the server picks which of these it matches on -
-- see the enforcement mode in the Garage panel. `partsSig` is a literal PREFIX
-- of `sig`, which is what lets the server derive the parts half of an entry
-- captured before this split existed instead of demanding a re-capture.
--
-- Paint was never in either signature and still is not: `cfg.paints` is simply
-- not read, so a respray has never been able to trip the Garage List.
--
-- Returns nil, reason when there is nothing honest to report. THE CAMERA IS THE
-- CATCH: core_vehicle_partmgmt.getConfig() describes the vehicle this client is
-- ATTACHED to, not the one it owns, and in multiplayer those come apart the
-- moment a driver spectates someone (see ownVehicle above, which exists for
-- exactly this). Reporting then would file a rival's parts under our own name -
-- rejecting us for their car, or whitelisting theirs when an admin presses
-- capture. Saying nothing leaves the last good report standing, which is right:
-- our car has not changed just because we stopped looking at it.
-- ONE TABLE, NOT NINE LOCALS.
--
-- This file sits at Lua's 200-active-locals ceiling, where the next `local`
-- anybody adds ANYWHERE stops the whole chunk compiling and the mod is simply
-- gone -- no error a player would ever see. The Garage List work needed nine
-- names, which is nine more than there were, so they live on one table
-- instead: a field costs nothing against that limit.
--
--   pcCache       the spawn configuration, digested once per car
--   vehParts      the digests the car itself reported
--   vehProbe      what the car last said about itself, for the panel
--   probeLeft     cooldown between questions to the vehicle
--   probesLeft    hard cap, so a silent car is not asked forever
--   settleSig     the signature we have been seeing
--   settleCount   how many polls running it has been the same
--   SETTLE_POLLS  how many it takes to be believed
--   lastDeclared  the previous declaration, for the log only
local garage = {
  pcCache = nil, vehParts = nil, vehProbe = nil,
  probeLeft = 0, probesLeft = 3,
  settleSig = nil, settleCount = 0, SETTLE_POLLS = 3,
  lastDeclared = nil,
  -- The last signature THIS client captured with Whitelist. Kept only so a
  -- rejection can say whether the car's identity moved since it was approved,
  -- which is otherwise two log lines minutes apart that somebody has to notice
  -- and compare by eye.
  lastCaptured = nil,
  -- Parts captured from BeamMP's spawn event, keyed by vehicle id. See
  -- watchMPSpawns: this is the only place a car spawned from a saved config
  -- ever reveals what it is built from.
  spawnParts = {},
  spawnHooked = false,
  -- Vehicles BeamMP announced an EDIT for. Doubles as "the spawn parts have
  -- been refreshed since this car was built", which is what stops them being
  -- dropped as stale below.
  editPc = {},
  -- Vehicles whose spawn-event parts were dropped as older than the car. Such
  -- a car must not fall through to the spawn configuration: the two sources
  -- key on different things, so the identity would jump on a car that may only
  -- have been resprayed. See readSpawnConfig.
  mpDropped = {},
}

-- THE CAR'S OWN ANSWER, sent up from the vehicle's Lua VM.
--
-- Measured, not guessed: on a BeamMP client both GE-side sources report a
-- config object with ZERO parts (the panel prints '[partmgmt=0, vehData=0]').
-- They are caches the VEHICLE fills by pushing its state up, and for a car
-- spawned through BeamMP nothing ever triggers that push, so they stay empty
-- for the whole session however long you wait.
--
-- The vehicle VM always knows its own parts. So it is asked directly and sends
-- the answer back here. Asynchronous by nature -- queueLuaCommand is a message,
-- not a call -- which is why the button primes on the first press and succeeds
-- on the second rather than blocking.
--
-- Keyed on the vehicle id so a driver who swaps cars cannot whitelist the one
-- they were in before.
-- THE SPAWN CONFIG'S DIGEST, COMPUTED ONCE PER CAR.
--
-- Measured on a live client, and it is the whole of the "changing a part makes
-- the game freeze" report: for a car spawned from a saved config `partConfig`
-- is a short path, and for one EDITED in the session it is the entire
-- configuration inline -- 73,258 bytes in the log that found this.
--
-- That string was being read and hashed inside localVehicleConfig, which the
-- config poll calls every two seconds. Seventy-three thousand iterations of an
-- interpreted hash loop, on the main thread, on a timer, for a value that only
-- changes when the car does. Untouched car: thirty bytes, unnoticeable. Edited
-- car: a hitch every two seconds, which is exactly what was reported and
-- exactly why changing back to the approved car stopped it.
--
-- Cleared by armVehicleConfigReport, so a rebuild re-reads it once.

-- Ask the car what it is built from, AND make it report on itself.
--
-- The first version of this asked for the parts and said nothing when it did not
-- get them, which put us back where we started: the panel read 'car=none' and
-- that one word covered every possible failure between here and the vehicle VM.
-- With no error in the log either, there was nothing to act on.
--
-- So the chunk below reports at three points, and each answer rules something
-- out. 'alive' means the vehicle ran our code and can talk back, which clears
-- the whole channel in one go. 'parts:N' is what the CAR itself thinks it is
-- built from, which separates "we cannot read it" from "there is nothing to
-- read". 'err:...' is a fault inside the chunk, carried out rather than left in
-- a log nobody is looking at.
--
-- Everything inside the long bracket runs in the VEHICLE's Lua state. Each step
-- is separately pcall'd there, so a missing name costs that step and not the
-- report about it.
-- A HARD CAP FOR A SILENT CAR, refreshed every time one answers. A car that
-- talks keeps its budget topped up and is re-asked every few seconds, which is
-- what makes a part change show up; a car that never answers is asked three
-- times and then left alone rather than all evening.

-- THE DIGEST: what a car is built from, in forty characters.
--
-- `count:length:hashA:hashB` over the canonical "key=value;" form of a table,
-- keys sorted so the same build always produces the same string. Two different
-- hashes plus the count and the length, because one 32-bit hash alone is a
-- collision risk on something that decides whether a car is allowed to race.
--
-- Computed IDENTICALLY here and in the vehicle (see requestVehicleParts), so a
-- parts table read on this side and one read by the car itself produce the same
-- signature. That is what keeps a car's identity stable no matter which source
-- answered, and stops it flipping in and out of the offender list.
-- WHICH SLOTS ARE NOT PART OF THE BUILD.
--
-- The Parts tab is not all parts. Alongside Body -- where everything really is
-- a part, and changing one changes the car -- it carries Paint Design and
-- License Plate Design, which are livery and must be free to change at all
-- times, on every mode. Digesting the parts table wholesale made choosing a
-- police livery read exactly like fitting a different engine.
--
-- Matched on the SLOT NAME, because that is the only signal there is. Kept
-- narrow on purpose: `skidplate` is a real part and must not be caught by a
-- loose match on "plate", so the plate rule spells out `licenseplate` in full.
local function isCosmeticSlot(name)
  name = tostring(name):lower()
  return name:find('paint', 1, true) ~= nil
      or name:find('licenseplate', 1, true) ~= nil
      or name:find('license_plate', 1, true) ~= nil
      or name:find('livery', 1, true) ~= nil
      or name:find('decal', 1, true) ~= nil
      or name:find('skin', 1, true) ~= nil
end

-- `skipCosmetic` is passed for the PARTS half and never for the tuning half:
-- tuning has no livery in it, and filtering a table by a parts rule it was
-- never subject to would be a quiet way to lose a tuning change.
local function digestOf(t, skipCosmetic)
  if type(t) ~= 'table' then return '0:0:0:0' end
  local keys, n = {}, 0
  for k in pairs(t) do
    if not (skipCosmetic and isCosmeticSlot(k)) then
      keys[#keys + 1] = tostring(k); n = n + 1
    end
  end
  table.sort(keys)
  local out = {}
  for i = 1, #keys do
    local v = t[keys[i]]
    -- QUANTIZED, and this is the difference between a value and an identity.
    --
    -- Measured across three spawns of one untouched car: fifteen tuning values
    -- every time, and a canonical string of 241, 247 and 247 bytes with three
    -- different hashes. The tuning was not changing -- its FLOATS were, in the
    -- last digits, and %.6g faithfully wrote every one of them down. So the
    -- signature moved on its own between spawns and could never match the
    -- entry the car had been whitelisted under.
    --
    -- Fixed three decimals: a width that does not depend on the value, and a
    -- precision far finer than any tuning control a driver can actually set.
    if type(v) == 'number' then v = string.format('%.3f', v) else v = tostring(v) end
    out[#out + 1] = keys[i] .. '=' .. v
  end
  local str = table.concat(out, ';')
  local h1, h2 = 5381, 0
  for i = 1, #str do
    local c = str:byte(i)
    h1 = (h1 * 33 + c) % 4294967296
    h2 = (h2 * 65599 + c) % 4294967296
  end
  return n .. ':' .. #str .. ':' .. h1 .. ':' .. h2
end

-- The same treatment for a plain string.
--
-- `partConfig` is usually a short path like "vehicles/bx/ESRA BX.pc" -- and for
-- a car that has been edited in the session it is the CONFIGURATION ITSELF,
-- inline, which runs to thousands of bytes. Put in a signature verbatim that
-- sails past the server's 4000-byte limit and the capture is refused with
-- "that configuration is too long to store", which is what a second press of
-- Whitelist reported on an edited car.
--
-- So it is reduced like everything else: same two hashes, same length guard,
-- and a signature that is a fixed size whatever the engine hands over.
local function digestText(str)
  if type(str) ~= 'string' or str == '' then return '-' end
  local h1, h2 = 5381, 0
  for i = 1, #str do
    local c = str:byte(i)
    h1 = (h1 * 33 + c) % 4294967296
    h2 = (h2 * 65599 + c) % 4294967296
  end
  return #str .. ':' .. h1 .. ':' .. h2
end

-- THE PARTS, DUG OUT OF THE SPAWN CONFIG.
--
-- Measured, and it is the last gap in the Garage List: this client reports
--
--     pd=0:0:0:0   vd=15:241:...   pc=73363:...
--
-- The car knows its TUNING (fifteen values) and reports NO PARTS AT ALL, from
-- every source including its own Lua VM. So the parts lock had nothing to
-- compare and a body part could be swapped freely under Parts mode.
--
-- The parts are not missing, though. They are inside that 73 KB `partConfig`
-- string, which for an edited car is the whole configuration written out. So it
-- is parsed, once per car, and its parts are digested like any other parts
-- table -- livery filtered out on the same rule.
--
-- Guarded at every step and never fatal: a car spawned from a saved config has
-- a PATH here rather than a configuration, which parses to nothing and simply
-- leaves the digest where it was.
-- THE PARTS, DUG OUT OF THE SPAWN CONFIG.
--
-- Measured on a live client, and this is what the string actually is:
--
--   {["partsTree"]={["chosenPartName"]="legran",["suitablePartNames"]=...,
--     ["partPath"]="/legran/",["children"]={["paint_design"]={...}}}}
--
-- Three things follow from that, and the first two were wrong here before.
--
-- IT IS A LUA TABLE LITERAL, not JSON. Calling jsonDecode on it fails once per
-- read and prints a stack trace each time, which is a wall of red in the
-- console for a value that was never going to parse. It is only offered to
-- jsonDecode when it actually looks like JSON.
--
-- IT MUST BE LOADED WITH loadstring, NOT load. BeamNG runs LuaJIT, where `load`
-- takes a FUNCTION and rejects a string outright; `loadstring` is the one that
-- takes source. Written as `load or loadstring` this worked in the test harness
-- (5.3, where `load` accepts a string) and could never work in the game -- the
-- exact shape of bug the harness is least able to catch.
--
-- AND THERE IS NO FLAT `parts` TABLE. It is a TREE: every node carries its
-- chosen part and a `children` map whose KEYS are the slot names -- which is
-- also what the Parts tab shows, and what the livery filter reads. So the tree
-- is walked and flattened into slot -> part.
-- KEYED BY SLOT NAME, NOT BY PATH.
--
-- Every source has to produce the same table for the same car or the digest
-- moves when the source does. BeamMP's spawn record is a flat slot -> part map,
-- so the tree is flattened the same way. Keying by path ('/legran/engine')
-- against BeamMP's 'engine' made one car digest two ways depending on which
-- source answered, which is a car deleted for a change nobody made.
--
-- This is also exactly what BeamJoy does (convertPartsTree in its
-- VehicleManager), against the same engine data, and it works in production.
local function collectPartsTree(node, path, out, depth)
  if type(node) ~= 'table' or depth > 24 then return end
  local kids = node.children
  if type(kids) ~= 'table' then return end
  for slot, child in pairs(kids) do
    if type(child) == 'table' then
      local chosen = child.chosenPartName
      -- An empty slot is a fact about the build too: "no roof rack" differs
      -- from "roof rack", so it is recorded rather than skipped.
      out[tostring(slot)] = (type(chosen) == 'string' and chosen ~= '') and chosen or '-'
      collectPartsTree(child, path, out, depth + 1)
    end
  end
end

-- THE PARTS, WHERE BEAMNG ACTUALLY PUTS THEM.
--
-- core_vehicle_manager.getVehicleData(id).config carries `partsTree`, and
-- `parts` on that table is empty. Reading only `parts` is why every source
-- reported zero on a live client for the whole life of this feature: the panel
-- printed [partmgmt=0, vehData=0, car=0] while the tree sat there full.
--
-- Returns nil when there is no tree, so callers can keep their own "not loaded
-- yet" handling rather than getting an empty table that reads as a real answer.
function garage.partsFromTree(cfg)
  if type(cfg) ~= 'table' or type(cfg.partsTree) ~= 'table' then return nil end
  local out = {}
  collectPartsTree(cfg.partsTree, '', out, 0)
  if next(out) == nil then return nil end
  return out
end

-- THE PARTS, FROM BEAMMP'S SPAWN RECORD.
--
-- This is the source that should have been used from the start, and the console
-- printed it in full when a car spawned:
--
--   Received a vehicle spawn for player ... {
--     vcf = { model = "legran", partConfigFilename = "vehicles/legran/derby_wagon.pc",
--             parts = {...}, vars = {...}, paints = {...} }, vid = 52703 }
--
-- A flat `parts` table, and it is there whether the car was spawned from a
-- saved config or edited in the session. That matters more than convenience:
-- `partConfig` is a 30-byte PATH for a car spawned from a .pc and a 73 KB
-- DOCUMENT once anything is edited, so a digest taken from it changes the
-- moment a driver touches the paint -- which is precisely the "blocks
-- everything, including paint design" that was reported. One source that
-- answers the same way in both states is what makes the lock stable.
--
-- It TRIES a handful of places and REPORTS the keys it actually found when
-- none of them hold a parts table, because guessing an accessor and guessing
-- again is what made this take as long as it did.
-- CATCH THE PARTS AS THEY GO PAST.
--
-- A car spawned from a saved config exposes NOTHING to ask afterwards: its
-- `partConfig` is the forty-byte path "vehicles/racetruck/Pro 4 (Sequential).pc",
-- the part manager reports nothing, the per-vehicle store reports nothing, and
-- the car's own Lua state reports nothing. The panel says it plainly:
--
--     [partmgmt=0, vehData=0, car=0, pc=40]
--
-- Only once a driver edits something does a real configuration appear -- which
-- is backwards, because the stock car is the one a league wants to approve.
--
-- The parts are not secret, though. BeamMP is handed them in the spawn event
-- and prints them:
--
--     Received a vehicle spawn ... vcf = { partConfigFilename = "...pc",
--                                          parts = {...}, vars = {...} }, vid = 18320
--
-- and then keeps only the summary. So the event is wrapped and the parts are
-- taken as they pass. The original is always called, whatever happens here: a
-- fault in this must never cost a player their car spawning.
--
-- The payload's shape is not assumed. Every argument is examined for a config
-- in either form, and what was found is logged the first time, so a BeamMP that
-- passes something different says so instead of silently going quiet.
local function watchMPSpawns()
  if garage.spawnHooked then return end
  if not (MPVehicleGE and type(MPVehicleGE.onServerVehicleSpawned) == 'function') then
    return
  end

  -- Shared by both wrappers. `what` is 'spawn' or 'edit'; only the spawn route
  -- feeds garage.spawnParts, because that is the source the matcher reads and
  -- this change must not alter what it sees.
  local function catch(args, argc, what)
    pcall(function ()
      for i = 1, argc do
        local a = args[i]
        -- The payload arrives either decoded or as JSON, depending on build.
        if type(a) == 'string' and a:sub(1, 1) == '{' and type(jsonDecode) == 'function' then
          local okD, decoded = pcall(jsonDecode, a)
          if okD and type(decoded) == 'table' then a = decoded end
        end
        if type(a) == 'table' then
          local cfg = type(a.vcf) == 'table' and a.vcf or a
          if type(cfg.parts) == 'table' and next(cfg.parts) ~= nil then
            local id = a.vid or a.gameVehicleID or cfg.vid
            if id ~= nil then
              local n = 0
              for _ in pairs(cfg.parts) do n = n + 1 end
              local pc = cfg.partConfigFilename
              if what == 'spawn' then
                garage.spawnParts[tostring(id)] = cfg.parts
              else
                -- AN EDIT REFILLS THE PARTS. This is the staleness fix: the
                -- spawn event fires once, so without this the parts caught at
                -- spawn answer for the car forever and a part swap is invisible.
                garage.spawnParts[tostring(id)] = cfg.parts
                -- Always truthy: this doubles as "an edit was announced for
                -- this vehicle", and an edit payload need not name a config.
                -- Testing the NAME for that is what dropped fresh parts as
                -- stale on any build that announces edits without one.
                garage.editPc[tostring(id)] = pc or '(unnamed)'
              end
              -- A fresh answer for this vehicle, so it is no longer the case
              -- that the only source that ever spoke for it has gone quiet.
              garage.mpDropped[tostring(id)] = nil
              log('I', 'raceManager', 'Caught ' .. n .. ' parts from the BeamMP '
                .. what .. ' event for vehicle ' .. tostring(id)
                .. ' (' .. tostring(pc or '?') .. ')')
            end
          end
        end
      end
    end)
  end

  local original = MPVehicleGE.onServerVehicleSpawned
  MPVehicleGE.onServerVehicleSpawned = function (...)
    -- The count is taken out here: `...` does not reach inside the pcall's own
    -- function, which is not itself vararg.
    local args, argc = { ... }, select('#', ...)
    catch(args, argc, 'spawn')
    return original(...)
  end

  -- An edit is the only thing that refreshes the parts caught at spawn. Without
  -- it those are all this client ever has for the vehicle, which is how a part
  -- swap goes unnoticed. Absent on a build without the event, and that is
  -- logged, because silence otherwise reads as "no edit happened".
  if type(MPVehicleGE.onServerVehicleEdited) == 'function' then
    local originalEdit = MPVehicleGE.onServerVehicleEdited
    MPVehicleGE.onServerVehicleEdited = function (...)
      local args, argc = { ... }, select('#', ...)
      catch(args, argc, 'edit')
      return originalEdit(...)
    end
  else
    log('W', 'raceManager', 'MPVehicleGE.onServerVehicleEdited is ABSENT on '
      .. 'this build, so no edit can ever be announced')
  end

  garage.spawnHooked = true
  log('I', 'raceManager', 'Watching BeamMP spawn events for vehicle parts')
end

local function partsFromMP(vid)
  -- The spawn event first: it is the ONLY source that answers for a car
  -- spawned from a saved config, which is the car a league actually approves.
  local caught = garage.spawnParts[tostring(vid)]
  if type(caught) == 'table' and next(caught) ~= nil then
    return caught, 'spawn event'
  end

  if not (MPVehicleGE and type(MPVehicleGE.getVehicles) == 'function') then
    return nil, 'no MPVehicleGE'
  end
  local list = nil
  pcall(function () list = MPVehicleGE.getVehicles() end)
  if type(list) ~= 'table' then return nil, 'no vehicle list' end
  for _, v in pairs(list) do
    if type(v) == 'table' and tostring(v.gameVehicleID) == tostring(vid) then
      for _, key in ipairs({ 'vcf', 'vehicleConfig', 'config', 'spawnData', 'data' }) do
        local c = v[key]
        if type(c) == 'table' then
          if type(c.parts) == 'table' and next(c.parts) ~= nil then
            return c.parts, key
          end
          if type(c.vcf) == 'table' and type(c.vcf.parts) == 'table'
              and next(c.vcf.parts) ~= nil then
            return c.vcf.parts, key .. '.vcf'
          end
        end
      end
      local keys = {}
      for k in pairs(v) do keys[#keys + 1] = tostring(k) end
      table.sort(keys)
      return nil, 'no parts on the MP record; it has: ' .. table.concat(keys, ' ')
    end
  end
  return nil, 'vehicle ' .. tostring(vid) .. ' is not in the MP list'
end

local function partsFromConfigString(str)
  if type(str) ~= 'string' or #str < 2 then return nil end
  -- A saved config is a PATH, and there is nothing in it to read.
  if str:match('%.pc$') then return nil end

  local cfg = nil
  -- Only offered to jsonDecode when it looks like JSON. BeamNG writes
  -- {["key"]=...}, which is Lua, and handing that to a JSON parser buys a
  -- stack trace per attempt and nothing else.
  if str:sub(1, 2) == '{"' and type(jsonDecode) == 'function' then
    pcall(function () cfg = jsonDecode(str) end)
  end
  if type(cfg) ~= 'table' and type(deserialize) == 'function' then
    cfg = nil
    pcall(function () cfg = deserialize(str) end)
  end
  if type(cfg) ~= 'table' then
    cfg = nil
    -- loadstring FIRST: on LuaJIT that is the only one that takes source.
    local mk = loadstring or load
    pcall(function ()
      local fn = mk('return ' .. str, 'partConfig')
      if fn then
        -- No environment: this is engine data, and it only needs to build a
        -- table. Nothing in it should be able to reach a global.
        if setfenv then setfenv(fn, {}) end
        cfg = fn()
      end
    end)
  end
  if type(cfg) ~= 'table' then return nil end

  -- The tree is the real shape. A flat `parts` table is accepted too, because
  -- some builds hand one over and it costs a line to keep working with both.
  if type(cfg.partsTree) == 'table' then
    local out = {}
    collectPartsTree(cfg.partsTree, '', out, 0)
    if next(out) ~= nil then return out end
  end
  if type(cfg.parts) ~= 'table' and type(cfg.config) == 'table' then
    cfg = cfg.config
  end
  if type(cfg.parts) ~= 'table' or next(cfg.parts) == nil then return nil end
  return cfg.parts
end

-- Ask the car what it is built from, and take back only the digest.
--
-- NEVER THE CONFIGURATION ITSELF. The version that did that turned a whole
-- vehicle config into Lua source and made the engine compile it every few
-- seconds; with an untouched car the config was empty and it looked fine, and
-- the moment a part was changed the game froze on a timer. What comes back now
-- is two short strings of digits.
--
-- The arithmetic is written to survive any Lua: no bitwise operators, because
-- the vehicle VM's Lua version is not something this file gets to choose.
-- `userAsked` is a human pressing Whitelist, and it is a different thing from
-- the timer coming round.
--
-- The budget below exists to stop the POLL talking to a silent car forever. It
-- must not also silence the button: the poll had already spent all three
-- questions by the time an admin pressed anything, so the one ask that a person
-- actually wanted was the one that never happened. An explicit press bypasses
-- the budget and waits only long enough not to hammer the physics thread.
local function requestVehicleParts(veh, userAsked)
  if not veh then return end
  if userAsked then
    if garage.probeLeft > 13.0 then return end        -- asked less than 2s ago
  elseif garage.probeLeft > 0 or garage.probesLeft <= 0 then
    return
  end
  -- FIFTEEN SECONDS, not three.
  --
  -- This chunk runs in the VEHICLE's Lua state, and that state lives on the
  -- PHYSICS THREAD. Anything done here is done in the middle of the simulation
  -- step, so the cost is not "a little CPU somewhere", it is a stall the driver
  -- feels. Part changes do not need a fast poll anyway: changing a part rebuilds
  -- the vehicle, which fires onVehicleSpawned and re-arms this immediately. The
  -- timer is only here to notice a re-TUNE, which nothing else announces.
  garage.probeLeft = 15.0
  if not userAsked then garage.probesLeft = garage.probesLeft - 1 end
  if not garage.vehProbe then garage.vehProbe = 'asked' end
  pcall(function ()
    veh:queueLuaCommand([==[
      pcall(function ()
        -- `rmDigest`, not `D`: this chunk is a STRING in a file that a scope
        -- check scans for calls into the extracted modules, and a bare one
        -- letter collides with one of them.
        --
        -- HASHED INCREMENTALLY, on purpose. The readable way to do this is to
        -- build "k=v;k=v" with table.concat and then walk it -- and that
        -- allocates a string the size of the whole configuration, on the physics
        -- thread, which is what made the game hitch every few seconds once a
        -- part change filled the config in. The bytes fed here are exactly the
        -- bytes that string would have contained, so the result is identical to
        -- digestOf() on the other side; only the allocation is gone.
        -- The same cosmetic rule as isCosmeticSlot on the other side. Both
        -- copies have to agree exactly: livery skipped here and counted there
        -- means a car digests differently depending on who answered, stops
        -- matching its own whitelist entry, and is deleted for nothing.
        local function rmCosmetic(name)
          name = tostring(name):lower()
          return name:find('paint', 1, true) ~= nil
              or name:find('licenseplate', 1, true) ~= nil
              or name:find('license_plate', 1, true) ~= nil
              or name:find('livery', 1, true) ~= nil
              or name:find('decal', 1, true) ~= nil
              or name:find('skin', 1, true) ~= nil
        end
        local function rmDigest(t, skipCosmetic)
          if type(t) ~= 'table' then return '0:0:0:0' end
          local k, n = {}, 0
          for a in pairs(t) do
            if not (skipCosmetic and rmCosmetic(a)) then
              k[#k+1] = tostring(a); n = n + 1
            end
          end
          table.sort(k)
          local h1, h2, len = 5381, 0, 0
          local function feed(str)
            for i = 1, #str do
              local c = str:byte(i)
              h1 = (h1 * 33 + c) % 4294967296
              h2 = (h2 * 65599 + c) % 4294967296
            end
            len = len + #str
          end
          for i = 1, #k do
            if i > 1 then feed(';') end
            local val = t[k[i]]
            -- Quantized identically to digestOf on the other side. Three
            -- decimals, fixed width: %.6g wrote out float noise that changed
            -- between spawns of a car nobody had touched.
            if type(val) == 'number' then val = string.format('%.3f', val)
            else val = tostring(val) end
            feed(k[i]); feed('='); feed(val)
          end
          return n .. ':' .. len .. ':' .. h1 .. ':' .. h2
        end
        -- `v.config` FIRST, and partmgmt only if it has nothing.
        --
        -- getConfig() is not a field read: it assembles the configuration, and
        -- on a car that actually has parts on it that is real work -- again, on
        -- the physics thread, every poll. `v.config` is a plain reference to a
        -- table that is already there.
        local cfg
        if type(v) == 'table' and type(v.config) == 'table'
            and type(v.config.parts) == 'table' and next(v.config.parts) ~= nil then
          cfg = v.config
        elseif partmgmt and partmgmt.getConfig then
          local c = partmgmt.getConfig()
          if type(c) == 'table' then cfg = c end
        end
        cfg = cfg or (type(v) == 'table' and v.config) or {}
        obj:queueGameEngineLua('raceManager.onVehicleDigest("'
          .. rmDigest(cfg.parts, true) .. '","' .. rmDigest(cfg.vars) .. '")')
      end)
    ]==])
  end)
end

local function localVehicleConfig(userAsked)
  local veh = ownVehicle()
  if not veh then return nil, 'Get in a vehicle first' end
  local attached = playerVehicle()
  if attached and vehicleId(attached) ~= vehicleId(veh) then
    return nil, 'Switch back to your own car first'
  end
  local model = '?'
  pcall(function () model = tostring(veh:getJBeamFilename()) end)
  local vid = vehicleId(veh)

  -- WHERE THE PART LIST COMES FROM, and why there is more than one answer.
  --
  -- core_vehicle_partmgmt.getConfig() reads the vehicle the PART MANAGER
  -- considers current, which is a different question from "the car this player
  -- is driving". In single player they are the same car and it answers. It is
  -- the only source this ever had, and when it answers with nothing there is
  -- no way to tell "not loaded yet" from "not the vehicle you meant" -- both
  -- come back as an empty table, and both were reported as "still loading".
  --
  -- So it is asked FIRST, because where it works it is right, and a second
  -- source keyed on the vehicle ITSELF is asked when it comes back empty.
  -- Every source is guarded on its own existence: a build without one loses
  -- that source, not the button.
  -- configPc is the SAVED CONFIG'S PATH, which is what makes an entry spawnable
  -- by a driver: core_vehicles.replaceVehicle takes it as opts.config verbatim.
  -- nil for a car edited in the session, because there is no file to spawn.
  local parts, vars, configName, source, configPc = {}, {}, nil, nil, nil
  local offered, notes = 0, {}

  -- First non-empty answer wins. An empty parts table is never an answer: no
  -- BeamNG vehicle has zero parts, so it means the source could not see this
  -- car rather than that the car has nothing on it.
  local function take(cfg, from)
    if next(parts) ~= nil or type(cfg) ~= 'table' then return end
    -- partsTree FIRST. That is where BeamNG keeps them; `parts` on this table
    -- is empty on a live client, which is what made every source read zero.
    -- `parts` is still accepted, for a build that populates it.
    local got = garage.partsFromTree(cfg)
    if not got and type(cfg.parts) == 'table' and next(cfg.parts) ~= nil then
      got = cfg.parts
    end
    if not got then return end
    parts      = got
    vars       = type(cfg.vars) == 'table' and cfg.vars or {}
    configName = configDisplayName(cfg)
    -- Same table the parts came out of. BeamJoy reads it from here too.
    if type(cfg.partConfigFilename) == 'string' and cfg.partConfigFilename ~= '' then
      configPc = cfg.partConfigFilename
    end
    source     = from
  end

  -- WHAT A SOURCE ANSWERED, in a few characters, for the refusal message.
  --
  -- The refusal is read off the panel and nowhere else -- an admin setting up a
  -- league night is not going to open the game console -- so the message has to
  -- carry enough to tell the causes apart. 'absent' is a build without that API
  -- at all; a number is an API that answered about SOME car and found nothing on
  -- it, which is the interesting case and means it is not looking at this one.
  local function note(from, ok, cfg)
    if not ok then notes[#notes + 1] = from .. '=error'; return end
    if type(cfg) ~= 'table' then
      notes[#notes + 1] = from .. '=' .. type(cfg)
      return
    end
    -- Counted off the same resolution `take` uses, or the panel reports zero
    -- for a source that answered perfectly well.
    local n, seen = 0, garage.partsFromTree(cfg)
    if not seen and type(cfg.parts) == 'table' then seen = cfg.parts end
    if type(seen) == 'table' then for _ in pairs(seen) do n = n + 1 end end
    notes[#notes + 1] = from .. '=' .. n
  end

  -- THE PER-VEHICLE STORE FIRST, asked about THIS vehicle BY ID. Order is the
  -- whole fix here, and getting it wrong made the Garage List unusable in a way
  -- that looked like everything else.
  --
  -- core_vehicle_partmgmt.getConfig answers about whichever car is CURRENT, and
  -- it is the parts UI's view of it rather than the spawned car's. It used to be
  -- asked first and, since this file learned to read partsTree, it always
  -- answered -- so `take` short circuited and this source was never reached at
  -- all. Twenty four declarations in one session, every one of them from
  -- partmgmt.
  --
  -- What that costs: the identity WANDERS. One untouched wendover declared
  -- pd=116:3577:3532314344:715134229 and pd=116:3577:3265219531:1357188818
  -- alternately -- same 116 parts, same 3577 bytes, two different hashes, back
  -- and forth. digestOf sorts its keys, so this was never iteration order; it
  -- was partmgmt giving two different answers about one car. A car whitelisted
  -- on one answer is refused on the other, and re-capturing cannot help,
  -- which is exactly what "THE SIGNATURE MOVED" has been reporting.
  --
  -- getVehicleData(vid) is pinned to the vehicle being declared, so it cannot
  -- drift onto another car or onto the menu's pending state.
  if core_vehicle_manager and core_vehicle_manager.getVehicleData and vid then
    offered = offered + 1
    local ok, data = pcall(core_vehicle_manager.getVehicleData, vid)
    if ok and type(data) == 'table' then take(data.config, 'vehicleData') end
    note('vehData', ok, type(data) == 'table' and data.config or data)
  else
    notes[#notes + 1] = 'vehData=absent'
  end

  -- KEPT AS THE FALLBACK, not deleted. On a build where the per-vehicle store is
  -- empty this is the only source that answers, and a wandering identity still
  -- beats no Garage List at all. It is named in the log as the source, so a
  -- signature that will not hold still can be recognised for what it is.
  if core_vehicle_partmgmt and core_vehicle_partmgmt.getConfig then
    offered = offered + 1
    local ok, cfg = pcall(core_vehicle_partmgmt.getConfig)
    if ok then take(cfg, 'partmgmt') end
    note('partmgmt', ok, cfg)
  else
    notes[#notes + 1] = 'partmgmt=absent'
  end

  -- The car's own answer, if it has sent one for THIS vehicle. Last, so a live
  -- source still wins whenever it can actually see the car.
  -- EACH SOURCE FOR WHAT IT IS ACTUALLY GOOD AT.
  --
  -- The car knows its TUNING and reports it live, which is what lets Strict
  -- notice a re-tune with no rebuild behind it. It reports no parts at all.
  --
  -- The spawn configuration knows the PARTS, and changing a part rebuilds the
  -- car, so a fresh one is read at exactly the moment they change.
  --
  -- Neither is preferred "when available", because that is a choice that can go
  -- both ways on different frames and it is how a signature ends up changing
  -- shape under a stored entry. Parts always come from the config when it could
  -- be read; tuning always comes from the car.
  local pd, vd = nil, nil
  if garage.vehParts and garage.vehParts.vid == vid and garage.vehParts.pd then
    pd, vd = garage.vehParts.pd, garage.vehParts.vd
    notes[#notes + 1] = 'car=' .. (pd:match('^(%d+)') or '?')
  else
    notes[#notes + 1] = 'car=' .. (garage.vehProbe or 'none')
  end

  -- THE CAR NEVER SUPPLIES THE PARTS, ONLY THE TUNING.
  --
  -- '0:0:0:0' is the digest of nothing and no real car has no parts: the
  -- vehicle VM sees its tuning and none of its build. Nil'd HERE, before the
  -- parts table below can fill it, because leaving it set meant the car's
  -- nothing outranked a perfectly good parts list and the whole read was
  -- refused as "press again in a moment" with the answer already in hand.
  if pd == '0:0:0:0' then pd = nil end

  -- THE BUILD'S IDENTITY, when the part LIST cannot be had.
  --
  -- Measured on a live BeamMP client: partmgmt, the per-vehicle store and the
  -- car's own VM all report zero parts, while BeamMP's spawn record for the same
  -- car carries `partConfigFilename = "vehicles/bx/200bx_base_A.pc"` with a full
  -- parts table beside it. The parts exist; they just never reach the vehicle's
  -- own config table when BeamMP is the thing that spawned it.
  --
  -- `partConfig` on the vehicle OBJECT is the one place this side can still see
  -- it: either the .pc path the car was built from, or, for a car tuned in the
  -- session, the configuration itself. Both identify the build, which is what a
  -- garage entry is for.
  -- A parts table read on THIS side is digested with the same function the car
  -- uses, so both routes produce one identical signature shape. Without that a
  -- car could be whitelisted under one shape and declare the other a moment
  -- later, and flip into the offender list for no visible reason.
  if not pd and next(parts) ~= nil then
    pd, vd = digestOf(parts, true), digestOf(vars)
  end

  -- The spawn config, digested ONCE per car rather than on every poll. It
  -- belongs in the strict signature below, and it can be tens of kilobytes.
  -- Wrapped so the sources can return early rather than nest: this runs once
  -- per car and each source either answers or stands aside.
  local function readSpawnConfig()
    -- Read once per car, and used three ways below. On an edited car this is
    -- tens of kilobytes, so it is never touched on a poll.
    local raw = nil
    pcall(function () raw = veh:getField('partConfig', 0) end)

    -- THE PARTS CAUGHT AT SPAWN CAN BE OLDER THAN THE CAR.
    --
    -- garage.spawnParts is filled from BeamMP's spawn event, which fires once.
    -- If BeamMP does not announce an edit, those parts answer for the vehicle
    -- for the rest of the session and a part swap is invisible: Parts mode
    -- blocks nothing. An inline partConfig (anything that is not a .pc path) is
    -- the evidence that the driver rebuilt the car, so the caught parts are
    -- stale and must not answer for it.
    --
    -- An announced edit refills them (see watchMPSpawns), so a build where
    -- BeamMP does announce edits never reaches this.
    local key = tostring(vid)
    if type(raw) == 'string' and raw ~= '' and not raw:match('%.pc$')
        and garage.spawnParts[key] and not garage.editPc[key] then
      garage.spawnParts[key] = nil
      garage.mpDropped[key] = true
      log('W', 'raceManager', 'The parts caught at spawn are older than this '
        .. 'car (its configuration is now inline, ' .. #raw .. ' bytes) and '
        .. 'BeamMP announced no edit, so they are dropped rather than left to '
        .. 'answer for a build they no longer describe')
    end

    -- BeamMP's record first: it is the only source that answers for a car
    -- spawned from a saved config, which is the car a league approves.
    local mpParts, mpWhy = partsFromMP(vid)
    if mpParts then
      local c = 0
      for _ in pairs(mpParts) do c = c + 1 end
      local freed, n = {}, 0
      for slot in pairs(mpParts) do
        if isCosmeticSlot(slot) then
          n = n + 1
          if n <= 12 then freed[#freed + 1] = slot end
        end
      end
      garage.pcCache = {
        vid = vid, digest = '-', len = 0,
        parts = digestOf(mpParts, true), count = c, from = 'mp',
      }
      log('I', 'raceManager', 'Read ' .. c .. ' parts from the BeamMP spawn '
        .. 'record (' .. tostring(mpWhy) .. '); ' .. n .. ' left free as '
        .. 'livery: ' .. (n > 0 and table.concat(freed, ' ') or 'NONE'))
      return
    end

    -- Say why, even though the fallback below may well succeed. BeamMP's record
    -- is the only source that answers the same way for a stock car and an
    -- edited one, so when it is NOT the source that is worth knowing rather
    -- than inferring from which message appeared.
    -- MEASURED AND SETTLED: BeamMP's vehicle record carries gameVehicleID,
    -- jbeam, owner, position, rotation and the rest -- and no configuration at
    -- all. The full `vcf` with its parts exists only in the spawn EVENT, which
    -- is gone by the time anything here can ask.
    --
    -- The lookup stays, guarded, because it costs nothing and a future BeamMP
    -- may keep it; it is logged at debug level rather than as a warning,
    -- because it is now the expected answer rather than a surprise.
    log('D', 'raceManager', 'BeamMP spawn record has no configuration ('
      .. tostring(mpWhy) .. '); using the spawn configuration instead')

    -- NO FALLING BACK ACROSS SOURCES, and this is what stops the drop above
    -- turning into a deleted car.
    --
    -- Both sources key on slot names now, but they do not enumerate the same
    -- slots: the spawn record carries what the config set, the parts tree
    -- carries every slot including the empty ones. So a vehicle whose spawn
    -- parts were just dropped would still move its digest here, on a change
    -- that may only have been a respray, and be removed for it.
    --
    -- Declaring nothing is the safe half of that choice: the server reads no
    -- declaration as "no verdict yet", which is never an offender. Cached as a
    -- refusal rather than left nil, because a nil cache is re-read every poll
    -- and re-reading an inline configuration on a timer is what froze the game.
    if garage.mpDropped[key] then
      garage.pcCache = { vid = vid, digest = '-', len = 0, parts = nil,
                         count = 0, from = 'dropped' }
      log('W', 'raceManager', 'This car was known through the BeamMP spawn '
        .. 'event and that answer is now stale, so it is UNJUDGED until it '
        .. 'respawns rather than being re-identified from a source that '
        .. 'enumerates different slots')
      return
    end

    if type(raw) ~= 'string' or raw == '' then
      -- NOT CACHED. A car one frame old has not been given its configuration
      -- yet, and the poll runs a second after the spawn -- so this is "ask
      -- again", not "this car has none".
      --
      -- Caching it made the failure PERMANENT for that vehicle: the parts
      -- digest fell back to the car's own answer (zero parts) and stayed there,
      -- so the signature no longer matched the entry the car had been
      -- whitelisted under and every mode refused it. That is the difference
      -- between a lock and a car that is blocked whatever you do to it.
      garage.pcCache = nil
    else
      -- Parsed HERE, in the once-per-car block, for the reason the digest is:
      -- this is tens of kilobytes and must never be touched on a poll.
      local fromCfg = partsFromConfigString(raw)
      garage.pcCache = {
        vid = vid, digest = digestText(raw), len = #raw,
        parts = fromCfg and digestOf(fromCfg, true) or nil,
        count = fromCfg and (function ()
          local c = 0
          for _ in pairs(fromCfg) do c = c + 1 end
          return c
        end)() or 0,
        from = 'tree',
      }
      if fromCfg then
        -- WHICH SLOTS THE LIVERY FILTER TOOK OUT, by name.
        --
        -- "Read 125 parts" says the tree parsed; it does not say whether the
        -- paint design was among the ones left free, and that is the whole
        -- question when a paint change gets a car deleted. The filter matches
        -- on slot NAME, so the names it matched are the evidence -- and if the
        -- paint slot is not in this list, it is not called what this code
        -- thinks it is called.
        local freed, n = {}, 0
        for slot in pairs(fromCfg) do
          if isCosmeticSlot(slot) then
            n = n + 1
            if n <= 12 then freed[#freed + 1] = slot end
          end
        end
        log('I', 'raceManager', 'Read ' .. garage.pcCache.count
          .. ' parts out of the spawn configuration; ' .. n
          .. ' left free as livery: ' .. (n > 0 and table.concat(freed, ' ')
            or 'NONE -- a paint or plate change will be treated as a part'))
      else
        -- NOT SILENT. An unreadable configuration means the parts digest stays
        -- empty, and an empty parts digest is a lock that matches every car --
        -- which is "Parts doesn't seem to block anything". If that happens, the
        -- first characters are the only thing that says why.
        log('W', 'raceManager', 'Could not read parts out of the spawn '
          .. 'configuration (' .. #raw .. ' bytes), and BeamMP had none either ('
          .. tostring(mpWhy) .. ') -- the Parts lock has nothing to compare. '
          .. 'It begins: ' .. raw:sub(1, 120))
      end
    end
  end
  if not (garage.pcCache and garage.pcCache.vid == vid) then readSpawnConfig() end
  notes[#notes + 1] = 'pc=' .. (garage.pcCache and garage.pcCache.len > 0 and garage.pcCache.len or 'none')
    .. ((garage.pcCache and garage.pcCache.parts) and ('/' .. garage.pcCache.count .. 'p') or '')

  local detail = ' [' .. table.concat(notes, ', ') .. ']'

  -- NO SOURCE AT ALL is not the same failure as every source coming back empty,
  -- and telling a driver to "try again" when nothing here can EVER answer is
  -- advice that wastes their evening. Separated so the message matches.
  if offered == 0 then
    log('E', 'raceManager', 'No vehicle configuration source on this build')
    return nil, 'This game build exposes no vehicle configuration to read' .. detail
  end

  -- AN EMPTY PART LIST IS "NOT LOADED YET", NEVER A REAL CONFIGURATION.
  --
  -- This is the bug that made the Garage List reject the very car it had just
  -- been given. onVehicleSpawned fires the moment the vehicle object appears,
  -- and at that instant the vehicle's own Lua VM has not finished loading its
  -- parts -- so getConfig() answers with nothing, the signature comes out as
  -- 'model=X|parts=', and that matches no entry on any list. The report went out
  -- one frame before the truth was knowable.
  --
  -- It was invisible until the deletion started working. A refused car used to
  -- produce a message and nothing else (MP.RemoveVehicle was being handed the
  -- wrong kind of id), so a spurious rejection at spawn cost nothing and was
  -- never noticed. The moment the client began honoring the order, the same
  -- spurious rejection deleted the car.
  --
  -- No BeamNG vehicle has zero parts, so there is no legitimate reading of this
  -- other than "ask again in a moment". Saying nothing leaves the last good
  -- declaration standing and the poll re-asks two seconds later.
  -- The detail rides on the refusal because this is the ONLY place most people
  -- will ever see it: it turns "the vehicle is still loading" (which was the
  -- same sentence for four unrelated causes) into something that names which
  -- source answered what.
  -- ONE SHAPE, ALWAYS: WAIT FOR THE DIGEST RATHER THAN DECLARING SOMETHING ELSE.
  --
  -- This is the bug that deleted a car for being re-tuned. There used to be a
  -- second shape here -- 'model=bx|pc=...' while no digest had arrived -- so an
  -- untouched car declared one thing, and the moment a tune filled the config in
  -- and the digest landed, the SAME car declared a different shape. It stopped
  -- matching the entry it had been whitelisted under and was removed, in Parts
  -- mode, for a change Parts mode exists to allow.
  --
  -- So there is no second shape. Until the car has answered this declares
  -- NOTHING, and silence already means "no verdict yet" to the server: a car
  -- with no declaration is never an offender and is never removed. A car that
  -- will not answer at all costs the button, not the driver.
  -- THE SPAWN CONFIG IS A FALLBACK, NOT THE ANSWER.
  --
  -- It is a snapshot taken when the car spawned; partsTree is what the car is
  -- built from right now. Applied unconditionally, a spawn-time snapshot
  -- outranked the live tree and a part swapped afterwards was invisible, which
  -- is Parts mode blocking nothing.
  --
  -- Kept, guarded, because it is the only source when the tree cannot be read:
  -- drop the guard and it takes over again.
  if not pd and garage.pcCache and garage.pcCache.parts then
    pd = garage.pcCache.parts
  end

  -- BOTH HALVES, OR NEITHER. Waiting for the parts alone is not enough.
  --
  -- The parts now arrive synchronously, out of the spawn configuration, while
  -- the tuning still comes from the car and takes a moment. So a guard that
  -- only waited for the parts let a car declare
  --
  --     pd=121:6778:...|vd=0:0:0:0      (tuning not in yet)
  --
  -- and then declare again with the real tuning a second later. Two signatures
  -- for one unchanged car: whitelist either and the other is refused, which is
  -- a car deleted for nothing it did. The log said it plainly -- `changed:
  -- PARTS+TUNING` on a car nobody had touched.
  --
  -- Silence until both are known. The server reads no declaration as "no
  -- verdict yet", which is the state where a driver is never an offender.
  -- '0:0:0:0' IS NOT A PARTS DIGEST. It is the digest of nothing, and no real
  -- car has no parts.
  --
  -- The car itself always answers that -- it can see its tuning and none of its
  -- parts -- so the real parts come from the spawn configuration. When that
  -- read does not yield any, `pd` was falling back to the car's nothing, and a
  -- car that had been approved as `pd=84:6921:...` started declaring
  -- `pd=0:0:0:0`. In Parts mode that IS the parts half, so an approved car was
  -- removed for a change Parts mode allows -- reported as a re-tune deleting
  -- the car six seconds later, which is this settling and then declaring the
  -- degenerate value.
  --
  -- Treated as "not known yet" rather than as an answer, so nothing is declared
  -- until the parts can genuinely be read. Silence is a car with no verdict,
  -- which is never an offender.
  if pd == '0:0:0:0' then pd = nil end

  if not pd or not vd then
    -- ASK THE CAR TO PUSH ITS PARTS, so the next press has something to read.
    --
    -- core_vehicle_partmgmt.getConfig() does not interrogate the vehicle: it
    -- returns GE-side state that the VEHICLE populates by sending it up. In
    -- single player something else has usually already triggered that (opening
    -- the parts UI does it), which is why this only ever failed on a server.
    -- Nothing in this mod was asking, so on a BeamMP client the state could stay
    -- empty for the whole session and every press got the same refusal.
    --
    -- Fired into the vehicle's own VM, where `partmgmt` lives. Guarded twice
    -- over: a build without that function raises inside the VEHICLE Lua state,
    -- which is logged there and cannot take the extension down.
    requestVehicleParts(veh, userAsked)
    -- DELIBERATELY SILENT. This runs from the two-second config poll as well as
    -- from the button, so logging here is a line every two seconds for the whole
    -- session -- which is what it did, and it buried the vehicle-side answers
    -- this is trying to collect. The admin who pressed something is told by the
    -- caller; the poll says nothing, exactly as it did before.
    return nil, 'Reading the vehicle, press again in a moment' .. detail
  end

  -- The byte layout of `sig` is unchanged from before the split, deliberately:
  -- every entry already on disk was written in this exact form, so strict
  -- matching keeps working across the upgrade with no re-capture at all.
  -- TWO SHAPES OF SIGNATURE, and the difference is worth being honest about.
  --
  -- With a real parts list the two halves mean what the panel says: `partsSig`
  -- is the build, `sig` adds the tuning on top, so Parts and Strict are
  -- genuinely different locks.
  --
  -- From `partConfig` alone they cannot be separated -- it is one string naming
  -- the whole build -- so both halves are the same value and Parts and Strict
  -- behave identically. That is a real limitation and not a silent one: it is
  -- reported as the source, and it is still an exact per-build identity rather
  -- than the model-name-only matching this fell back to before.
  -- TWO SHAPES, AND NOW THE FIRST ONE MAKES THE LOCKS REAL.
  --
  -- With a digest, `partsSig` covers the BUILD and `sig` adds the TUNING on top,
  -- so Parts and Strict are genuinely different rules -- and both move the
  -- instant a part is changed, which is what lets the server re-rule a car that
  -- was edited after it was approved.
  --
  -- From `partConfig` alone the two cannot be separated: it is one string naming
  -- the whole build, so both halves carry it and the two locks behave the same.
  -- That is a real limitation, reported as the source rather than hidden, and
  -- still an exact per-build identity.
  -- WHAT EACH HALF MAY CONTAIN, and the rule is the mode's own promise.
  --
  -- `partsSig` is what Parts mode matches on, and Parts mode says the tuning is
  -- free. So it carries the parts digest and NOTHING ELSE a re-tune can move.
  -- The spawn config's name is deliberately kept out of it: whether BeamNG
  -- rewrites `partConfig` when a car is tuned is not something this side can
  -- promise, and a maybe in the parts half is a car deleted for tuning.
  --
  -- `sig` is Strict, which promises the exact tune, so it adds the tuning digest
  -- and the spawn config on top.
  local partsSig = 'model=' .. model .. '|pd=' .. pd
  -- STRICT IS PARTS PLUS TUNING. NOTHING ELSE.
  --
  -- It used to carry a hash of the whole `partConfig` string as well, and that
  -- string is the entire configuration -- parts, tuning, AND livery. So every
  -- change moved it and Strict blocked everything, including the paint design
  -- and the license plate that both modes are supposed to leave alone. Reported
  -- exactly that way: "strict seems to block everything, including liveries".
  --
  -- The two halves already say precisely what the modes promise, each built
  -- from a filtered digest, so the raw string had nothing to add but noise. It
  -- is still read -- the PARTS are dug out of it -- but the blob itself never
  -- reaches a signature again.
  local sig = partsSig .. '|vd=' .. (vd or '0:0:0:0')
  source = source or 'digest'
  -- The label used to be dug out of the .pc path. It is not worth keeping the
  -- 73 KB string alive for, and an edited car has no path in it anyway, so the
  -- name now comes from a real config table when one was read and from the
  -- model otherwise.
  configName = configName or nil
  return {
    model    = model,
    label    = configName and (model .. ' - ' .. configName) or model,
    partsSig = partsSig,
    sig      = sig,
    vid      = vid,
    -- Which source answered. Carried so the log can name it: "the button does
    -- nothing" and "the button reads the wrong car" look identical from the
    -- panel and are not the same bug.
    source   = source,
    -- The saved config this car was built from, when it was built from one.
    -- Carried so the Garage List can hand it back to a driver to spawn.
    pc       = configPc,
  }
end

-- Last signature this client told the server about, so the periodic check only
-- talks when something actually changed (spawn, swap, or a re-tune).
-- A SIGNATURE HAS TO HOLD STILL BEFORE ANYBODY IS JUDGED ON IT.
--
-- This exists because chasing the sources one at a time did not work, and the
-- reason it did not work is structural rather than a series of separate bugs.
--
-- The identity is assembled from several things that arrive at different times:
-- the parts out of the spawn configuration, the tuning from the car's own Lua
-- state, and BeamMP's record of what it spawned. EVERY ONE of them reads empty
-- for a moment after a car appears and real a second later. Any one of those
-- empty-to-real transitions is a second, different signature for a car nobody
-- has touched -- and the server, quite correctly, refuses a car whose signature
-- is not the one it was whitelisted under, and deletes it.
--
-- Fixing them individually meant knowing which source was slow this time, and
-- there was always another. So nothing is judged on a signature until it has
-- come out the same several polls running. A settled value cannot be a
-- half-loaded one, whichever half was late.
--
-- The cost is a few seconds at spawn, during which nothing is declared at all,
-- and the server reads no declaration as "no verdict yet" -- the state where a
-- driver is never an offender and never removed. That is the right thing to be
-- during those seconds.

-- Three polls at two seconds each: long enough to outlast the sources coming
-- up, short enough that an admin pressing the button is not left waiting.

-- The current signature, but only once it has stopped moving. Returns nil while
-- it is still settling, which every caller treats as "ask again in a moment".
local function settledConfig(userAsked)
  local cfg, why = localVehicleConfig(userAsked)
  if not cfg then
    garage.settleSig, garage.settleCount = nil, 0
    return nil, why
  end
  if cfg.sig == garage.settleSig then
    garage.settleCount = garage.settleCount + 1
  else
    garage.settleSig, garage.settleCount = cfg.sig, 1
  end
  if garage.settleCount < garage.SETTLE_POLLS then
    return nil, 'Reading the vehicle, press again in a moment [settling '
      .. garage.settleCount .. '/' .. garage.SETTLE_POLLS .. ']'
  end
  return cfg
end

-- The previous declaration, kept only so the log can say what MOVED between
-- two of them. Never used for a decision.
local lastReportedSig = nil
local configCheckLeft = 0

-- The car's answer, arriving from its own VM. Called by name from the vehicle
-- state, so it has to be on M.
-- What the car said about itself. Three answers, each ruling something out:
--   alive    the vehicle ran our code and can talk back: channel is fine
--   saw:N    what the CAR believes it is built from, N parts
--   err ...  the chunk faulted over there, carried back rather than buried
-- THE CAR'S ANSWER: two digests, and nothing else crosses the boundary.
--
-- Validated hard before it is believed. This arrives as a Lua string literal
-- built inside the vehicle VM, so the only shape ever accepted is four numbers
-- separated by colons -- anything else is discarded rather than reaching a
-- signature the server will be asked to match on.
-- Exposed for tests/garage_test.lua. The digest decides whether a car is
-- allowed to race, so its determinism is worth pinning directly rather than
-- only through the signature it ends up inside.
function M.digestForTest(t, skipCosmetic) return digestOf(t, skipCosmetic) end

function M.onVehicleDigest(partsDigest, varsDigest)
  local function clean(d)
    d = tostring(d or '')
    return d:match('^%d+:%d+:%d+:%d+$') and d or nil
  end
  local pd, vd = clean(partsDigest), clean(varsDigest)
  if not pd then return end
  local veh = ownVehicle()
  local before = garage.vehParts and garage.vehParts.pd
  garage.vehParts = {
    vid = veh and vehicleId(veh),
    pd  = pd,
    vd  = vd or '0:0:0:0',
  }
  garage.vehProbe = 'digest'
  -- A CAR THAT TALKS KEEPS ITS BUDGET. This is what makes a part change show
  -- up: the poll re-asks every few seconds, and the digest moves the moment the
  -- build does.
  garage.probesLeft = 3
  if before ~= pd then
    log('I', 'raceManager', 'Vehicle build digest: ' .. pd
      .. (before and (' (was ' .. before .. ')') or ''))
    -- The declaration the server is holding describes the OLD build. Re-declare
    -- rather than waiting for the throttle to notice, which is the whole point
    -- of detecting a part change at all.
    lastReportedSig = nil
  end
end

function M.onVehicleProbe(status)
  garage.vehProbe = tostring(status or '?')
  log('I', 'raceManager', 'Vehicle probe: ' .. garage.vehProbe)
end

-- A PARTS TABLE ARRIVING FROM ANYWHERE, reduced to the same digest.
--
-- Nothing in this file sends a config across any more -- that is what froze the
-- game on a timer once a part change filled it in, and the car reports a DIGEST
-- now instead. This is kept, and kept working, for two reasons: a queued call
-- from an older client build must not land on a nil, and if a cheap way to
-- carry a real parts list over is ever found, this is where it lands.
--
-- It stores exactly what onVehicleDigest stores, through the same digestOf, so
-- a car's identity never depends on which route the answer took. Writing a
-- different shape here is what made localVehicleConfig index a nil digest.
function M.onVehicleParts(cfg)
  if type(cfg) ~= 'table' or type(cfg.parts) ~= 'table' then return end
  if next(cfg.parts) == nil then return end      -- still nothing: keep waiting
  M.onVehicleDigest(digestOf(cfg.parts, true), digestOf(cfg.vars))
end

local function reportVehicleConfig(force)
  if not inMultiplayer() then return end
  local cfg = settledConfig()
  if not cfg then return end
  -- Keyed on the FULL signature even though the server may only be matching the
  -- parts half. The client is not told which mode is in force, and it must not
  -- have to be: a tune that goes unreported here is a tune the server cannot
  -- rule on if the admin switches to strict mid-evening.
  if not force and cfg.sig == lastReportedSig then return end
  lastReportedSig = cfg.sig
  -- WHAT THIS CLIENT IS CLAIMING TO BE DRIVING, logged on every CHANGE.
  --
  -- Not on every poll: the guard above means this line only appears when the
  -- declaration actually moves, so it is a history of what the car said about
  -- itself rather than a heartbeat. It is the other half of the Garage List
  -- comparison -- the stored entry is on disk in garage.json and this is what is
  -- being matched against it, and until both were visible a mismatch could only
  -- be guessed at.
  -- WHAT MOVED, not just what is. A rejection after a change is only readable
  -- if the two declarations either side of it can be told apart at a glance:
  -- parts moving on a paint change is a filter that missed the slot, and
  -- NOTHING moving while the car is still refused is a stale Garage List entry
  -- captured under an older signature. Those are different bugs with the same
  -- symptom, and this line is what separates them.
  local moved = 'first'
  if garage.lastDeclared then
    local wasP, nowP = garage.lastDeclared:match('|pd=([^|]*)'), cfg.sig:match('|pd=([^|]*)')
    local wasV, nowV = garage.lastDeclared:match('|vd=([^|]*)'), cfg.sig:match('|vd=([^|]*)')
    local bits = {}
    if wasP ~= nowP then bits[#bits + 1] = 'PARTS' end
    if wasV ~= nowV then bits[#bits + 1] = 'TUNING' end
    moved = #bits > 0 and table.concat(bits, '+') or 'nothing'
  end
  garage.lastDeclared = cfg.sig
  log('I', 'raceManager', 'Declared to the server [' .. tostring(cfg.source)
    .. ', changed: ' .. moved .. ']: ' .. tostring(cfg.sig))
  TriggerServerEvent('RM_VehicleConfig', jsonEncode({
    vid = cfg.vid, model = cfg.model, label = cfg.label,
    sig = cfg.sig, partsSig = cfg.partsSig,
    game = gameVersion(),
  }))
end

-- A car has just appeared: re-declare it, but not on this frame.
--
-- The forced report used to go out from onVehicleSpawned directly, which is one
-- frame too early to know anything (see the part-list guard above). Arming the
-- poll instead asks the same question shortly afterwards, when getConfig() can
-- actually answer it. lastReportedSig is cleared so the answer counts as a
-- change even if the driver respawned the identical car.
local function armVehicleConfigReport()
  lastReportedSig = nil
  configCheckLeft = 1.0
  -- The cached answer belongs to the car that just went away. Dropped rather
  -- than left to be matched by id: ids get reused, and whitelisting the
  -- previous car's build under this one's name is worse than another wait.
  garage.vehParts = nil
  -- The spawn config belongs to the car that just went away, and re-reading it
  -- is the one expensive thing here, so it is dropped exactly here and nowhere
  -- else.
  garage.pcCache = nil
  -- A different car is a different signature, and it starts settling again
  -- from nothing rather than inheriting the last one's count.
  garage.settleSig, garage.settleCount = nil, 0
  -- A FRESH BUDGET PER CAR, not per session. The probe is diagnostic now, so a
  -- car that will not answer should cost three questions and then stop asking
  -- rather than talking to a silent vehicle for the rest of the evening.
  garage.probesLeft = 3
  -- NOT ASKED HERE, and that is the point of the delay.
  --
  -- Changing a part REBUILDS the vehicle, and this fires in the middle of that.
  -- Queueing Lua into a vehicle state that is still coming up is the worst
  -- moment to pick, and a parts change can raise this event more than once, so
  -- an immediate ask becomes a burst of them into a car that is busy being
  -- born. The poll below picks it up a second later, when there is something
  -- there to answer.
  garage.probeLeft = 1.0
end

-- Polls the local vehicle configuration. Applying a tune does not raise a
-- single reliable GE event across BeamNG versions, so the signature is
-- re-derived on a slow timer and reported the moment it differs - that covers
-- spawns, vehicle switches and setup changes with one code path.
local function vehicleConfigUpdate(dt)
  if not inMultiplayer() then return end
  -- Installed from the poll rather than at load: MPVehicleGE may not exist yet
  -- when this extension comes up, and it is a no-op once hooked. Cheap enough
  -- to attempt on a two-second timer and self-healing if BeamMP reloads.
  watchMPSpawns()
  if garage.probeLeft > 0 then garage.probeLeft = garage.probeLeft - dt end
  configCheckLeft = configCheckLeft - dt
  if configCheckLeft > 0 then return end
  configCheckLeft = 2.0
  reportVehicleConfig(false)
end

-- Admin action: capture the car being driven right now and add it to the
-- server's Garage List.
function M.whitelistCurrentVehicle()
  if not inMultiplayer() then
    guihooks.trigger('RaceManagerEditorMsg', { msg = 'The Garage List needs a BeamMP server' })
    return
  end
  -- A PERSON IS ASKING. Say so, so the read is allowed to question the car even
  -- when the background poll has used its budget up.
  -- The BUTTON takes the settled value too. Capturing an unsettled one puts an
  -- entry on the Garage List that the car itself will stop matching a second
  -- later, which is the same deletion seen from the other end.
  local cfg, why = settledConfig(true)
  if not cfg then
    guihooks.trigger('RaceManagerEditorMsg', { msg = why or 'Get in a vehicle first' })
    -- Logged HERE rather than inside the read: once per press, because someone
    -- asked, instead of once per poll forever.
    log('W', 'raceManager', 'Whitelist refused: ' .. tostring(why))
    return
  end
  TriggerServerEvent('RM_WhitelistVehicle', jsonEncode({
    model = cfg.model, label = cfg.label,
    sig = cfg.sig, partsSig = cfg.partsSig, game = gameVersion(),
    pc = cfg.pc,
  }))
  -- THE CAPTURED SIGNATURE, in full.
  --
  -- The server files the car under this exact string and compares later
  -- declarations against it. Printing it here puts it beside the "Declared to
  -- the server" lines in the same log, so a rejection can be read rather than
  -- guessed at: same string means the Garage List is at fault, a different one
  -- means the car's identity moved and the difference says which half.
  log('I', 'raceManager', 'Whitelisting current vehicle: ' .. cfg.label
    .. ' (read from ' .. tostring(cfg.source) .. ')')
  garage.lastCaptured = cfg.sig
  log('I', 'raceManager', 'Captured signature: ' .. tostring(cfg.sig))
end

-- WHAT EVERY CONFIGURATION SOURCE ACTUALLY ANSWERS, printed to the console.
--
-- Run this when Whitelist Current Vehicle refuses:
--   raceManager.diagnoseVehicleConfig()
--
-- It exists because the refusal has exactly one visible form -- "the vehicle is
-- still loading" -- for several unrelated causes: no car, somebody else's car,
-- a source that cannot see this vehicle, or a genuinely half-loaded one. From
-- the panel they are indistinguishable, and the panel is the only place most of
-- this is ever seen. This prints the difference.
function M.diagnoseVehicleConfig()
  local function line(s) log('I', 'raceManager', s); print('[RaceManager] ' .. s) end
  local function describe(cfg)
    if type(cfg) ~= 'table' then return 'not a table (' .. type(cfg) .. ')' end
    local np, nv = 0, 0
    if type(cfg.parts) == 'table' then for _ in pairs(cfg.parts) do np = np + 1 end end
    if type(cfg.vars)  == 'table' then for _ in pairs(cfg.vars)  do nv = nv + 1 end end
    return np .. ' parts, ' .. nv .. ' vars, name=' .. tostring(configDisplayName(cfg))
  end

  line('--- vehicle configuration diagnosis ---')
  line('multiplayer: ' .. tostring(inMultiplayer()))
  local veh = ownVehicle()
  line('ownVehicle: ' .. (veh and 'yes' or 'NO -- nothing to read'))
  local attached = playerVehicle()
  line('attached vehicle id: ' .. tostring(attached and vehicleId(attached))
    .. ', own vehicle id: ' .. tostring(veh and vehicleId(veh)))

  if core_vehicle_partmgmt and core_vehicle_partmgmt.getConfig then
    local ok, cfg = pcall(core_vehicle_partmgmt.getConfig)
    line('core_vehicle_partmgmt.getConfig: ' .. (ok and describe(cfg)
      or ('RAISED: ' .. tostring(cfg))))
  else
    line('core_vehicle_partmgmt.getConfig: ABSENT on this build')
  end

  local vid = veh and vehicleId(veh)
  if core_vehicle_manager and core_vehicle_manager.getVehicleData then
    if vid then
      local ok, data = pcall(core_vehicle_manager.getVehicleData, vid)
      line('core_vehicle_manager.getVehicleData(' .. tostring(vid) .. '): '
        .. (ok and (type(data) == 'table' and describe(data.config)
                    or 'not a table (' .. type(data) .. ')')
            or ('RAISED: ' .. tostring(data))))
    else
      line('core_vehicle_manager.getVehicleData: no vehicle id to ask about')
    end
  else
    line('core_vehicle_manager.getVehicleData: ABSENT on this build')
  end

  local cfg, why = localVehicleConfig()
  if cfg then
    line('RESOLVED via ' .. tostring(cfg.source) .. ': ' .. cfg.label)
    line('signature: ' .. cfg.sig:sub(1, 200))
  else
    line('REFUSED: ' .. tostring(why))
  end

  -- Which source actually answered for the parts. The whole failure mode of
  -- this feature was every source reporting zero, so the resolved one is worth
  -- naming when somebody is looking at a refusal.
  local pcc = garage.pcCache
  line('spawn config: ' .. tostring(pcc and pcc.from or 'none')
    .. ', ' .. tostring(pcc and pcc.count or 0) .. ' parts')
  line('--- end ---')
end

-- WHERE THIS CLIENT KEEPS ITS OWN COPIES. A path inside BeamNG's user folder,
-- which is the whole reason it can be opened at all: exploreFolder resolves
-- through the virtual filesystem and refuses anything outside it.
-- On M, not a local: this chunk is a handful of names from Lua's 200-local
-- ceiling, where the next one stops the file compiling and the mod is simply
-- absent in game. A field costs nothing against that.
M.RESULTS_LOCAL_DIR = 'settings/raceManager/results'

-- A COPY OF THE RESULTS, FOR AN ADMIN WHO IS NOT THE SERVER OWNER.
--
-- A league's race admins are often not the people with the box: no console, no
-- filesystem, no way to read the one file the night produced. The server still
-- writes its own copy and that stays the record; this is the same text, landed
-- somewhere the person who ran the race can reach.
--
-- Written under BeamNG's user folder deliberately. Anywhere else and it would
-- be as unreachable as the server's copy, because the only folder this game
-- will open is one of its own.
function M.onResultsFile(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then return end
  local text = tostring(data.text or '')
  if text == '' then return end
  -- Sanitised: this arrives over the wire and becomes a filename. Anything that
  -- is not plainly a name is replaced rather than trusted.
  local name = tostring(data.name or 'results.txt'):gsub('[^%w%-_%.]', '_')
  if name == '' then name = 'results.txt' end

  if FS and FS.directoryCreate then pcall(function () FS:directoryCreate(M.RESULTS_LOCAL_DIR, true) end) end
  local path = M.RESULTS_LOCAL_DIR .. '/' .. name
  local wrote = false
  if type(writeFile) == 'function' then
    wrote = pcall(writeFile, path, text) and true or false
  else
    local f = io.open(path, 'w')
    if f then f:write(text); f:close(); wrote = true end
  end
  if not wrote then
    log('W', 'raceManager', 'Could not write a local results copy to ' .. path)
    return
  end
  log('I', 'raceManager', 'Results saved locally: ' .. path .. ' (' .. #text .. ' bytes)')
  pushNotice('session', 'Results saved to your own copy: ' .. name)
end

-- Open THIS CLIENT'S results folder. Works where the server's does not, because
-- it is inside BeamNG's own files.
function M.openLocalResults()
  if FS and FS.directoryCreate then pcall(function () FS:directoryCreate(M.RESULTS_LOCAL_DIR, true) end) end
  local real = nil
  if FS and FS.getFileRealPath then
    local okR, r = pcall(function () return FS:getFileRealPath(M.RESULTS_LOCAL_DIR) end)
    if okR then real = r end
  end
  if Engine and Engine.Platform and Engine.Platform.exploreFolder then
    pcall(Engine.Platform.exploreFolder, '/' .. M.RESULTS_LOCAL_DIR .. '/')
  end
  log('I', 'raceManager', 'Local results folder: ' .. tostring(real or M.RESULTS_LOCAL_DIR))
  pushNotice('session', 'Your results copies: ' .. tostring(real or M.RESULTS_LOCAL_DIR))
end

-- WHERE THE SERVER KEEPS ITS RESULTS. Shown, not opened, and that is measured
-- rather than a limitation I am guessing at.
--
-- Engine.Platform.exploreFolder resolves through BeamNG's virtual filesystem
-- and refuses anything outside it. The results are on the server's disk, so the
-- engine answered:
--
--   E  engine::Platform::openFolder  Failed to get real path for:
--                                    C:/BeamNG Server/.../Data/results
--
-- It fails INTERNALLY rather than raising, so the pcall around it returned true
-- and this function cheerfully logged "opened" for something that had not
-- happened. Calling it now only buys a red engine error on every press, so the
-- call is gone and the path is what this offers.
--
-- Clear Results Cache has no such limit because it is the opposite shape: it
-- asks the server to delete its own files and never touches a path on this side.
function M.openResultsFolder(path)
  path = tostring(path or '')
  if path == '' then
    pushNotice('session', 'The server did not report where its results are kept')
    return
  end
  log('I', 'raceManager', 'Results folder: ' .. path)
  pushNotice('session', 'Results are on the server at: ' .. path)
end

function M.clearGarage()
  if inMultiplayer() then TriggerServerEvent('RM_ClearGarage', '') end
end

function M.removeGarageEntry(index)
  index = math.floor(tonumber(index) or 0)
  if index < 1 then return end
  if inMultiplayer() then
    TriggerServerEvent('RM_RemoveGarageEntry', jsonEncode({ index = index }))
  end
end

function M.setGarageEnforce(enabled)
  if inMultiplayer() then
    TriggerServerEvent('RM_SetGarageEnforce', jsonEncode({ enabled = enabled and true or false }))
  end
end

-- Which half of the signature the server matches on: 'parts' (model + parts,
-- tuning and paint free) or 'strict' (model + parts + tuning). Anything else is
-- refused server-side, so a stale UI cannot invent a third rule.
function M.setGarageMode(mode)
  if inMultiplayer() then
    TriggerServerEvent('RM_SetGarageMode', jsonEncode({ mode = tostring(mode or '') }))
  end
end

-- Which class a Garage List entry runs in. An empty string clears it, which is
-- how a league drops back to one class without deleting the entry.
function M.setGarageClass(index, class)
  if inMultiplayer() then
    TriggerServerEvent('RM_SetGarageClass', jsonEncode({
      index = math.floor(tonumber(index) or 0),
      class = tostring(class or ''),
    }))
  end
end

-- TAKE A CAR OFF THE GARAGE LIST. Open to everyone, not just admins.
--
-- The entry carries the saved config's PATH, and BeamNG takes that verbatim:
-- prepareConfigData in core/vehicles.lua reads opts.config as "a basename or a
-- full path" and loads the .pc itself. So there is nothing to rebuild here and
-- no parts table to ship: the path IS the car.
--
-- THE FILE HAS TO EXIST ON THIS CLIENT. prepareConfigData calls
-- FS:fileExists, and a config that ships inside a server mod is present on
-- everyone who joined; one an admin saved locally is not. A missing file spawns
-- the model's default rather than erroring, which is worth saying out loud
-- because it looks like the wrong car rather than a failure.
--
-- `replace` swaps the car under the driver, which is the common case and has no
-- vehicle-count limit. Spawning a new one goes through canSpawnAnotherVehicle
-- and can simply be refused when the server is at its cap.
function M.takeGarageCar(model, pc, replace)
  model = tostring(model or '')
  pc = tostring(pc or '')
  if model == '' or pc == '' then
    guihooks.trigger('RaceManagerEditorMsg', { msg = 'That garage entry has no saved config to spawn' })
    return
  end
  if not (core_vehicles and core_vehicles.replaceVehicle and core_vehicles.spawnNewVehicle) then
    guihooks.trigger('RaceManagerEditorMsg', { msg = 'This game build cannot spawn a vehicle' })
    return
  end
  local ok, err = pcall(function ()
    if replace then
      core_vehicles.replaceVehicle(model, { config = pc })
    else
      core_vehicles.spawnNewVehicle(model, { config = pc })
    end
  end)
  if not ok then
    log('E', 'raceManager', 'Could not take garage car ' .. model .. ' (' .. pc
      .. '): ' .. tostring(err))
    guihooks.trigger('RaceManagerEditorMsg', { msg = 'The game refused that spawn' })
    return
  end
  log('I', 'raceManager', (replace and 'Replaced with ' or 'Spawned ') .. model
    .. ' from ' .. pc)
  -- The new car re-declares itself on its own: onVehicleSpawned arms the report
  -- and the poll picks it up, so the Garage List rules on it like any other.
end

-- NAMED GARAGE SETS. A race night runs several series and re-whitelisting each
-- field between them is the evening; these put one back in a click. The server
-- owns the naming rules, so nothing is validated here beyond having a string.
function M.saveGarageSet(name)
  if inMultiplayer() then
    TriggerServerEvent('RM_SaveGarageSet', jsonEncode({ name = tostring(name or '') }))
  end
end

function M.loadGarageSet(name)
  if inMultiplayer() then
    TriggerServerEvent('RM_LoadGarageSet', jsonEncode({ name = tostring(name or '') }))
  end
end

function M.deleteGarageSet(name)
  if inMultiplayer() then
    TriggerServerEvent('RM_DeleteGarageSet', jsonEncode({ name = tostring(name or '') }))
  end
end

-- The server ordered this client to drop the car it just refused.
--
-- WHY THE SERVER CANNOT DO THIS ITSELF: MP.RemoveVehicle wants BeamMP's own
-- per-player vehicle id, the one handed to onVehicleSpawn. The id traveling on
-- RM_VehicleConfig is veh:getID(), a BeamNG game object id from a different
-- numbering space entirely, so the call matched nothing and failed silently
-- inside its pcall. That is why a refused setup used to produce a red banner
-- and no consequence whatsoever. The client knows which car is its own without
-- any id at all, so the order is what crosses the wire and the deletion happens
-- here.
--
-- Deliberately NOT removeLocalVehicle(): that one arms `removedVehicle` so the
-- session end can put the car back, which is exactly wrong for a car that was
-- refused. Nothing respawns an illegal setup.
local function deleteOwnVehicleNow()
  local veh = ownVehicle()
  if not veh then return false end
  local attached = playerVehicle()
  -- core_vehicles.removeCurrent deletes whatever this client is ATTACHED to, so
  -- it is only safe once that is known to be ours. Same guard as
  -- removeLocalVehicle, same reason: otherwise a refused driver takes a rival's
  -- car with them.
  if core_vehicles and core_vehicles.removeCurrent
      and attached and vehicleId(attached) == vehicleId(veh) then
    if pcall(core_vehicles.removeCurrent) then return true end
  end
  return pcall(function () veh:delete() end)
end

-- ===========================================================================
-- Vehicle reset control & forced spectating (Module 1)
-- ===========================================================================
-- The reset allowance is a league regulation the server owns but only the
-- client can police: BeamNG fires the reset locally and the BeamMP server never
-- sees it. Every local reset is counted here. Once the allowance is spent the
-- reset is BLOCKED rather than punished: BeamNG has already teleported the car
-- by the time we hear about it, so "blocking" means putting the car straight
-- back on its last known good position and orientation. The driver keeps
-- racing, they simply cannot use the reset button any more.
--
-- The forced-spectator machinery below is still used, but only where a driver
-- genuinely leaves the session: a derby elimination, or crossing the finish
-- line (a finished car is taken off track so it can't interfere with the
-- drivers still racing). Both are lifted - and the car respawned - when the
-- session ends.

-- Snapshot of the vehicle removed by enterSpectator, so the same car can be put
-- back when the session releases the lock.
local removedVehicle = nil   -- { model, config, pos, rot }

-- Everything BeamNG needs to put this exact car back: jbeam model, the part
-- config, and where it was standing.
local function captureVehicleSnapshot()
  local veh = ownVehicle()
  if not veh then return nil end
  local snap = {}
  pcall(function () snap.model = tostring(veh:getJBeamFilename()) end)
  pcall(function ()
    local pos = veh:getPosition()
    snap.pos = vec3(pos.x, pos.y, pos.z)
  end)
  pcall(function ()
    local rot = veh:getRotation()
    snap.rot = quat(rot.x, rot.y, rot.z, rot.w)
  end)
  if core_vehicle_partmgmt and core_vehicle_partmgmt.getConfig then
    local ok, cfg = pcall(core_vehicle_partmgmt.getConfig)
    if ok and type(cfg) == 'table' then snap.config = cfg end
  end
  -- THE GRID SLOT THIS DRIVER OWNS, recorded here because here is the last
  -- moment it exists. The phase change to 'finished' clears gridSlot, and that
  -- lands BEFORE the release that puts the car back -- so a respawn asking for
  -- the slot at release time always found nothing and fell back to respawning
  -- on the finish line, which is where the whole field had just been removed
  -- from, on top of each other. A snapshot records where to put a car back, and
  -- the slot is part of that.
  snap.slot = session.gridSlot
  if not snap.model then return nil end
  return snap
end

-- Delete the local player's OWN vehicle. BeamNG exposes several ways to do this
-- depending on version, so try them in order and never let a failure escape.
--
-- core_vehicles.removeCurrent deletes whatever the client is attached to, which
-- is only safe once we know that is ours -- otherwise a driver taking the flag
-- deletes a rival's car out from under them.
--
-- WHO THIS IS FOR IS THE WHOLE POINT, and getting that wrong was a live bug in
-- both directions. A RACE finisher is taken off the track: they have nothing
-- left to gain and a parked car on the racing line is an obstacle for everyone
-- still running. A DERBY elimination is NOT -- the wreck is the arena's
-- furniture and the other drivers are still fighting around it, and deleting it
-- in BeamMP deletes it for every client in the server, which is how eliminated
-- drivers vanished from everybody's screen.
-- DELIBERATELY UNREACHABLE, AND DELIBERATELY KEPT.
--
-- Nothing calls this any more. Finishing a race ghosts the car in place instead
-- of deleting it, which is the whole point of that change, so the only thing
-- that ever set `removedVehicle` is gone -- and with it, in practice,
-- respawnRemovedVehicle, captureVehicleSnapshot and the `respawn` branch of the
-- placement scheduler. releaseSpectator guards that branch on `removedVehicle`
-- being set, so the entire subsystem is inert rather than merely unused.
--
-- It stays as the way back if ghosting ever has to be abandoned: the engine call
-- underneath it (obj:setGhostEnabled) is BeamNG's own, so the risk is not that
-- the approach is wrong but that a future build moves the call. Deleting the
-- fallback would mean rebuilding it under time pressure on a race night.
--
-- Do not "tidy" this away. It is not an oversight.
local function removeLocalVehicle()
  local veh = ownVehicle()
  if not veh then return end
  removedVehicle = captureVehicleSnapshot() or removedVehicle
  local attached = playerVehicle()
  if core_vehicles and core_vehicles.removeCurrent
      and attached and vehicleId(attached) == vehicleId(veh) then
    if pcall(core_vehicles.removeCurrent) then return end
  end
  pcall(function () veh:delete() end)
end

-- Put this client back on its OWN car.
--
-- Doing it explicitly is the point: after a placement the game picks a vehicle
-- for the camera on its own, and with five cars moving at once its pick is
-- arbitrary -- which is how every client in the session ended up watching the
-- same driver.
--
-- It switches the VEHICLE and not the camera MODE. It used to force the game
-- camera (orbit) as well, which threw away whatever view the driver had chosen
-- -- a cockpit driver was put in orbit every time the mod handed their car back.
-- Which car you are attached to is the mod's business; how you are looking at it
-- is the driver's.
local function bindCameraToOwnVehicle()
  local veh = ownVehicle()
  if not veh then return false end
  local bound = false
  if be and be.enterVehicle then
    bound = pcall(function () be:enterVehicle(0, veh) end)
  end
  log('I', 'raceManager', 'Attached to own vehicle ' .. tostring(vehicleId(veh))
    .. (bound and '' or ' (enterVehicle unavailable)'))
  return true
end

-- Put back the car removed when this client was pushed into spectator mode.
-- Called when the session that imposed the penalty ends, so a driver who
-- finished (or was knocked out of a derby) is back in their car for the next
-- one instead of stranded in freecam with nothing to drive.
-- Forward-declared: respawnRemovedVehicle below needs both to stand a respawned
-- car on its grid slot, and both are defined further down beside the placement
-- code they were written for. Declared rather than moved, so the placement
-- section keeps reading in the order it was built.
local headingRot
local placeOnStartPosition

local function respawnRemovedVehicle()
  local snap = removedVehicle
  if not snap or not snap.model then return false end
  -- OWN car, not "a car". Asking playerVehicle() here is what stopped a
  -- finisher's respawn: the camera had already been handed to a rival's vehicle,
  -- so the answer was "you have one" and the driver stayed on foot for good.
  if ownVehicle() then
    removedVehicle = nil
    return false
  end
  removedVehicle = nil
  local opts = { config = snap.config }
  if snap.pos then opts.pos = snap.pos end
  if snap.rot then opts.rot = snap.rot end
  -- SPAWN ON THE GRID SLOT, not where the car was taken away.
  --
  -- This is what welded the field together. A race removes cars AS THEY TAKE THE
  -- FLAG, all within a few meters of the line, so respawning each at its own
  -- snapshot put the whole field down interpenetrated and BeamNG welds what it
  -- finds inside itself. The grid is spaced by construction. Falls back to the
  -- snapshot only when the track has no grid placed, covered by the ghosting
  -- around this call.
  -- Spawn on the slot's POSITION only, then turn it with placeOnStartPosition.
  -- headingRot bakes in a half-turn for BeamNG's -Y vehicle forward, which is
  -- what setPositionRotation wants and spawnNewVehicle does NOT: handing it the
  -- same quaternion put every respawned car on its slot facing backwards. One
  -- place knows about the two conventions, and this is not it.
  -- ANY start position beats the finish line.
  --
  -- gridSlot is cleared by the phase change to 'finished', a mid-session joiner
  -- never had one, and a slot can outlive the grid it indexed. Falling straight
  -- back to the snapshot puts a finisher back on the start/finish line facing
  -- however they crossed it: the reported "near the start/finish, sideways". So
  -- their slot, then any placed slot, then the snapshot. Sharing someone else's
  -- slot for a moment is harmless while the ghosting holds.
  local slot = snap.slot or session.gridSlot
  local sp = slot and track.startPositions[slot]
  if not (type(sp) == 'table' and sp.x) then sp = track.startPositions[1] end
  if type(sp) == 'table' and sp.x and sp.y and sp.z then
    opts.pos = vec3(sp.x, sp.y, sp.z)
    opts.rot = nil          -- set below, by the call that knows the convention
    log('I', 'raceManager', 'Respawning on grid slot ' .. tostring(slot or 1)
      .. ' rather than where the car was removed')
  else
    -- Say so. A car that comes back in the wrong place with nothing in the log
    -- is the position this took two rounds to get out of.
    log('W', 'raceManager', 'Respawning where the car was removed: no start '
      .. 'position to use (slot=' .. tostring(slot) .. ', grid has '
      .. tostring(#track.startPositions) .. ' placed)')
  end
  local spawned = false
  if core_vehicles and core_vehicles.spawnNewVehicle then
    spawned = pcall(core_vehicles.spawnNewVehicle, snap.model, opts)
  end
  if not spawned and core_vehicles and core_vehicles.replaceVehicle then
    spawned = pcall(core_vehicles.replaceVehicle, snap.model, opts)
  end
  if spawned then
    -- NOT placed or turned here. BeamNG spawns asynchronously and the vehicle
    -- does not exist on this frame, so a placement call made now finds nothing
    -- and silently does nothing -- which is why cars kept coming back facing
    -- whichever way they finished. The placement scheduler already has a step
    -- for this: it waits out a spawn grace and THEN calls placeOnAssignedSlot,
    -- which is the same call the grid itself uses. releaseSpectator hands it the
    -- slot so that step has something to place onto.
    log('I', 'raceManager', 'Respawned ' .. tostring(snap.model) .. ' after the session ended')
  else
    -- Keep the snapshot: a failed spawn is worth another attempt when the
    -- placement scheduler comes back round, and losing it means losing the only
    -- record of what this driver was in.
    removedVehicle = snap
    log('W', 'raceManager', 'Could not respawn ' .. tostring(snap.model)
      .. ' automatically: spawn a vehicle manually')
  end
  return spawned
end

-- Free camera is the DRIVER'S control now, not the mod's. It is still there --
-- BeamNG's own key still works, and a spectator is welcome in it -- but nothing
-- here puts them in it or keeps them there. Forcing it was Bug 3.


-- ---------------------------------------------------------------------------
-- Being out of a session: freeze the INPUT, never the existence
-- ---------------------------------------------------------------------------
-- This used to delete the car and force freecam, which was three live bugs:
--
--   * in BeamMP a deleted vehicle is deleted FOR EVERY CLIENT, so an eliminated
--     driver went missing from everyone's screen rather than quiet.
--   * freecam was re-asserted once a second, so tabbing to watch somebody was
--     undone within the second, over and over.
--   * letting anyone back in then meant RESPAWNING a whole field at once, which
--     is how cars came back interpenetrated and welded.
--
-- The car now stays where it is as a physical object and only the ability to
-- DRIVE it is taken away, which removes the weld problem at its cause. The
-- camera is not touched: tabbing between cars is BeamNG's own control.
local spectate = {
  -- Every input that drives a car. Deliberately NOT the vehicle-switch actions:
  -- tabbing between cars is the whole point of spectating and must keep working.
  DRIVE = {
    'accelerate', 'brake', 'throttle', 'steering', 'steer_left', 'steer_right',
    'parkingbrake', 'parkingbrake_toggle', 'clutch',
    'shiftUp', 'shiftDown', 'shiftToggle', 'toggleGearboxMode',
    'nitrousOxideActive', 'toggleWalkingMode',
  },
  blocked = false,
  -- WHAT A WRECK IS SET TO when a derby eliminates its driver. Every one of
  -- these is an input the DRIVE filter above covers, and therefore one that can
  -- be left latched at whatever it was when the filter armed -- see
  -- spectate.releaseControls.
  --
  -- Zero across the board, parking brake included: the car is meant to be an
  -- obstacle the survivors can shove around, not one bolted to the arena floor.
  -- `steering` is here for the same reason as the pedals; a wreck left on full
  -- lock is a wreck that will not push straight.
  NEUTRAL = {
    'throttle', 'brake', 'steering', 'clutch', 'parkingbrake',
    'nitrousOxideActive',
  },
  -- WHAT MAKES A CAR GO, and nothing else. Armed only while a derby is standing
  -- its cars down at the end of a heat.
  --
  -- Steering and the brakes are deliberately absent. The stand-down already
  -- applies full brake and handbrake before the freeze goes on, and blocking an
  -- input LATCHES it at the value it had when the filter armed -- so leaving
  -- them out is what keeps the car stopped rather than a car that could be
  -- released. Steering stays live because taking somebody's wheel away as a
  -- prize for having been in a derby is worse than pointless.
  --
  -- WHY THIS EXISTS AT ALL. The stand-down zeroes the throttle with a single
  -- input.event, which works perfectly for a driver who has lifted. A derby ends
  -- with somebody's foot flat to the floor, and the input system re-reads that
  -- held pedal on the very next frame: the throttle comes straight back and the
  -- engine screams against the frozen car until the cool-down lifts. Setting a
  -- value once cannot beat a key that is still down; only the filter can.
  PROPULSION = {
    'accelerate', 'throttle', 'nitrousOxideActive',
  },
  propulsionBlocked = false,
  -- Guarded on the function existing, which is how the BeamMP mods that do this
  -- in production write it: a vehicle with no main controller -- a trailer,
  -- anything unpowered -- has no such call, and an unguarded one would throw
  -- inside the vehicle's own Lua where nothing here can see it.
  IGNITION_OFF = 'if controller.mainController.setEngineIgnition then '
    .. 'controller.mainController.setEngineIgnition(false) end',
  IGNITION_ON  = 'if controller.mainController.setEngineIgnition then '
    .. 'controller.mainController.setEngineIgnition(true) end',
  -- Did WE cut it? Only then is it ours to put back.
  engineCut = false,
  -- BeamNG's node grabber: click a car and drag its physics nodes around. In a
  -- demolition derby that is not a debug tool, it is a winning move -- drag your
  -- own wreck back onto its wheels, or drag somebody else's into the wall
  -- without touching them. Off for the length of a derby.
  --
  -- THESE ARE THE GAME'S OWN NAMES, read out of its actionFilter's
  -- `actionTemplates.nodegrabber` rather than guessed. The first version of this
  -- list guessed, in snake_case, and every name was wrong -- so the filter armed
  -- a group of actions that do not exist and the grabber went on working. A
  -- filter group made of names nothing answers to fails completely silently:
  -- there is no error and no log line, it simply blocks nothing.
  --
  -- funStuff goes with it for the same reason. Fire, explosions, the tyre
  -- poppers and the flings are one keypress each and every one of them decides a
  -- derby; they are exactly as much a cheat as dragging a node, and the game
  -- groups them for exactly this purpose.
  GRAB = {
    -- actionTemplates.nodegrabber
    'nodegrabberAction', 'nodegrabberGrab', 'nodegrabberRender',
    'nodegrabberStrength', 'nodegrabberPadGrab', 'nodegrabberPadMode',
    -- actionTemplates.funStuff
    'forceField', 'funBoom', 'funBreak', 'funExtinguish', 'funFire',
    'funHinges', 'funTires', 'funRandomTire', 'latchesOpen', 'latchesClose',
    'funBoost', 'funBoostBackwards', 'funFling', 'funFlingDownward',
  },
  grabBlocked = false,
}

-- Same shape as the two blocks either side of it. Kept separate from the driving
-- block because they answer to different things: driving is filtered while a
-- driver is OUT of a session, the grabber while a derby is ON, and an eliminated
-- driver in a running derby is both at once.
-- ARM OR DISARM ONE INPUT-FILTER GROUP.
--
-- Three callers wanted this and each carried its own copy: the same
-- availability check, the same pcall, the same setGroup/addAction pair. Only
-- the group name and the action list ever differed.
--
-- Worth having as one function for a reason beyond the line count: the
-- availability check is the interesting part. core_input_actionFilter is a
-- BeamNG extension that a build can rename or not load, and every caller has to
-- survive that by doing nothing rather than by throwing. Three copies of a
-- guard is three chances to write the fourth one without it.
--
-- Returns whether the filter was actually reached, so a caller only records the
-- new state when the engine really took it.
local function setActionGroupBlocked(group, actions, blocked)
  if not (core_input_actionFilter and core_input_actionFilter.setGroup
      and core_input_actionFilter.addAction) then
    return false
  end
  return (pcall(function ()
    core_input_actionFilter.setGroup(group, actions)
    core_input_actionFilter.addAction(0, group, blocked)
  end))
end

function spectate.setGrabberBlocked(blocked)
  blocked = blocked and true or false
  if blocked == spectate.grabBlocked then return end
  if setActionGroupBlocked('raceManagerGrabber', spectate.GRAB, blocked) then
    spectate.grabBlocked = blocked
    log('I', 'raceManager', 'Node grabber ' .. (blocked and 'BLOCKED' or 'released'))
  end
end

-- Same shape as setResetInputsBlocked, and for the same reason: with the filter
-- armed the keys are dead at the source, so an eliminated driver cannot drive
-- their wreck no matter what the physics would otherwise allow.
function spectate.setInputsBlocked(blocked)
  blocked = blocked and true or false
  if blocked == spectate.blocked then return end
  if setActionGroupBlocked('raceManagerSpectate', spectate.DRIVE, blocked) then
    spectate.blocked = blocked
    log('I', 'raceManager', 'Driving inputs ' .. (blocked and 'BLOCKED' or 'released'))
  end
end

-- HAND THE CAR BACK AS A ROLLING CHASSIS.
--
-- Filtering the inputs stops new ones arriving and does nothing at all about the
-- ones already there: BeamNG's action filter suppresses an action's onChange, so
-- the value standing at the instant the filter armed is the value it keeps.
-- Eliminate a driver mid-corner and the throttle stays where their foot left it,
-- the engine screams, and neither they nor anybody else can do a thing about it.
--
-- So every input the filter covers is set to zero, ONCE, after it arms. Once is
-- enough: with the action filtered nothing can move it again.
--
-- THE PARKING BRAKE IS RELEASED, NOT APPLIED, and that is a deliberate
-- difference from the end-of-derby stand-down above it. A car eliminated from a
-- derby is meant to be an obstacle -- something the survivors can shove, pile
-- into and use -- and a wreck bolted to the floor by its handbrake is a wall
-- instead. It is left free to roll, and it is left SOLID: no ghost, no freeze.
-- The only thing taken away is the driver's ability to move it themselves.
--
-- THE IGNITION GOES WITH THEM, and the reason is the out-of-bounds case rather
-- than the stopped one. A car eliminated by the stopped timer is by definition
-- sitting still; one disqualified for leaving the arena was driving a second
-- ago, and zeroing its pedals leaves an engine that still idles, still drives an
-- automatic forward, and still lets the car be nudged along under its own power.
-- Cutting it makes the thing genuinely a chassis: it coasts to a stop and stays
-- where it stops.
--
-- Coasting, note, not stopping dead -- the brakes are deliberately off, so a car
-- disqualified at speed rolls to a halt rather than anchoring in the middle of
-- the arena. That is the same obstacle argument as the parking brake.
--
-- `controller.mainController.setEngineIgnition` guarded on existing: it is the
-- call the BeamMP mods that do this in production use, and a vehicle without a
-- main controller (a trailer, anything unpowered) simply has no such function.
function spectate.releaseControls()
  -- ownVehicle(), not playerVehicle(): the camera may already have been tabbed
  -- onto somebody else's car, and this is about the eliminated driver's own.
  local veh = ownVehicle()
  if not veh then return false end
  local ok = pcall(function ()
    for _, input in ipairs(spectate.NEUTRAL) do
      veh:queueLuaCommand(('input.event("%s", 0, 1)'):format(input))
    end
    veh:queueLuaCommand(spectate.IGNITION_OFF)
  end)
  -- Remembered so the release can undo it, and ONLY then: a driver handed back a
  -- car that will not start is worse off than one handed back a running wreck.
  spectate.engineCut = ok or spectate.engineCut
  log('I', 'raceManager', ok
    and 'Derby elimination: controls neutralised, ignition off, free to roll'
    or  'Derby elimination: could not neutralise controls')
  return ok
end

-- The other half. Called from the release, which is the moment a derby ends and
-- every eliminated driver gets their car back for whatever comes next.
--
-- Only if we cut it. Turning the ignition on under a driver who never lost it
-- would be a surprise, and this runs on the race release path too -- where
-- nothing was ever cut, because a race finisher keeps their car and drives it.
function spectate.restoreEngine()
  if not spectate.engineCut then return end
  spectate.engineCut = false
  local veh = ownVehicle()
  if not veh then return end
  pcall(function () veh:queueLuaCommand(spectate.IGNITION_ON) end)
  log('I', 'raceManager', 'Spectator released: ignition restored')
end

-- Put the camera on somebody still racing.
--
-- A driver who has just taken the flag is parked, and leaving them looking at
-- their own stationary car is the least interesting view on the track. Pick a
-- car that is MOVING and is not ours, and hand the camera to it the same way
-- bindCameraToOwnVehicle does -- by switching vehicle, not by changing camera
-- MODE, so the driver keeps whatever view they had and tab keeps working from
-- there.
--
-- Once. There is no loop re-asserting this: after the first attach the target is
-- the driver's to change.
function spectate.attachToRunner()
  if type(getAllVehicles) ~= 'function' or not (be and be.enterVehicle) then return false end
  local ok, list = pcall(getAllVehicles)
  if not ok or type(list) ~= 'table' then return false end
  local best, bestSpeed = nil, 0.5      -- m/s; below this a car is parked
  for _, v in ipairs(list) do
    if v and not isOwnVehicle(vehicleId(v)) then
      local moving = 0
      pcall(function ()
        local vel = v:getVelocity()
        if vel then moving = math.sqrt(vel.x * vel.x + vel.y * vel.y + vel.z * vel.z) end
      end)
      if moving > bestSpeed then best, bestSpeed = v, moving end
    end
  end
  -- Nothing moving (everybody finished, or a one-car session): stay where we
  -- are rather than flicking through parked cars looking for one that is not
  -- there. A sane still view beats a search that never settles.
  if not best then return false end
  local switched = pcall(function () be:enterVehicle(0, best) end)
  log('I', 'raceManager', switched
    and ('Spectating a moving car (%.0f m/s)'):format(bestSpeed)
    or 'Could not switch to a moving car')
  return switched
end

local function enterSpectator(reason, source)
  session.spectatorLock   = source or 'race'
  spectatorReason = reason or 'You are out of this session'
  -- DRIVING IS BLOCKED FOR A DERBY AND KEPT FOR A RACE, and that split is the
  -- point of the two branches below.
  --
  -- A derby elimination is a wreck: the car is meant to sit there. A race
  -- finisher is a spectator in their own ghosted car, and driving it is how they
  -- watch the rest of the race. There is nothing left to police -- the moment
  -- they took the flag they stopped being scored (checkGates and reportProgress
  -- both return on spectatorLock) and stopped being able to touch anyone
  -- (ghost.setFinished), so a free car cannot affect the race it is watching.
  --
  -- It CAN be driven back onto the racing line and seen there. That is a
  -- deliberate trade: the physics are provably unaffected and the alternative is
  -- taking a driver's car away for the last two laps.
  spectate.setInputsBlocked(session.spectatorLock == 'derby')
  if session.spectatorLock == 'derby' then
    -- ELIMINATED IN A DERBY: the car stays exactly where it is, as a visible,
    -- physical wreck, and the driver stays in it. The arena is the show and they
    -- are sitting in it; being moved somewhere else the instant you are knocked
    -- out reads as the bug this replaced. Tab takes them anywhere they like.
    --
    -- AFTER the filter above, never before. Zeroing first would leave a window
    -- -- however short -- in which a pedal still being held could put the value
    -- straight back; once the action is filtered, nothing can move it again.
    spectate.releaseControls()
    log('I', 'raceManager', 'Derby elimination: the wreck stays in the arena')
  else
    -- FINISHED OR OUT OF A RACE: the car STAYS, and is ghosted.
    --
    -- It used to be deleted here and respawned when the race ended. That is an
    -- entity destroy and an entity create per driver, at the one moment a field
    -- is finishing together -- a burst of deletion, spawn and network-sync
    -- events, worst on the machines least able to absorb it. Nothing is created
    -- or destroyed now; the car changes state and stays where it is.
    --
    -- A parked car on the racing line was the reason for deleting it, and the
    -- ghost is what answers that: collision is off in both directions, so a
    -- finished car cannot be hit, blocked, pushed, rammed or drafted off, and
    -- cannot touch a racer's physics at all. See ghost.setFinished.
    --
    -- The camera stays where it is too, because there is still a car to be in.
    -- attachToRunner existed because deleting the car left BeamNG to hand the
    -- view to whatever vehicle was nearest, which with a field finishing
    -- together put every client on the same arbitrary driver.
    ghost.setFinished(true)
  end
  guihooks.trigger('RaceManagerSpectator', {
    spectating = true, reason = spectatorReason, source = session.spectatorLock,
  })
  pushNotice('spectate', spectatorReason)
  pushRouteState()
  log('I', 'raceManager', 'Spectator mode (' .. tostring(session.spectatorLock)
    .. '): ' .. tostring(spectatorReason))
end

-- Only the source that imposed the lock can lift it, so a derby finishing can
-- never hand a race DNF their car back (and vice versa). Releasing puts the
-- removed vehicle back and hands the camera to it, so the driver is ready for
-- the next session instead of stuck in freecam.
--
-- The respawn is QUEUED rather than done here. Every driver in the field is
-- released by the same broadcast, so doing it on the spot means the whole grid
-- spawning on one tick - refused spawns and interpenetrated cars. `order` and
-- `count` come from the server's snapshot of the participant list and put this
-- client in the queue; a release without them (a lone spectator, a derby
-- elimination) is simply order 1 of 1.
--
-- Forward-declared: the placement scheduler lives further down, beside the grid
-- placement it shares its ghosting and its stagger with.
local queueFieldPlacement

local function releaseSpectator(source, order, count)
  if not session.spectatorLock then return end
  if source and source ~= session.spectatorLock then return end
  session.spectatorLock   = nil
  spectatorReason = nil
  -- Driving comes back first, so a driver is never released into a car they
  -- cannot move -- and the ignition with it, or "cannot move" outlives the
  -- session that meant it.
  spectate.setInputsBlocked(false)
  spectate.restoreEngine()
  -- The finished ghost comes off: collision back, alpha back, on our own car
  -- here and on everyone else's as the authoritative list empties.
  ghost.setFinished(false)
  -- NOTHING IS RESPAWNED AND NOTHING IS PLACED.
  --
  -- The car was never removed, so there is nothing to put back -- and a driver
  -- who spent the last two laps spectating from wherever they drove to should be
  -- released exactly there. Teleporting the field onto the old grid at the flag
  -- would be the entity churn this change exists to remove, wearing a different
  -- hat.
  --
  -- respawnRemovedVehicle stays as a safety net for a snapshot left by an older
  -- build (or by anything else that removed the car out from under us). With
  -- nothing removed, `removedVehicle` is nil and this whole branch is skipped.
  if removedVehicle then
    local slot = nil
    if source ~= 'derby' then
      slot = removedVehicle.slot or session.gridSlot or (track.startPositions[1] and 1 or nil)
    end
    if queueFieldPlacement then
      queueFieldPlacement({ respawn = true, slot = slot, order = order, count = count })
    else
      respawnRemovedVehicle()
      bindCameraToOwnVehicle()
    end
  end
  guihooks.trigger('RaceManagerSpectator', { spectating = false })
  pushRouteState()
  log('I', 'raceManager', 'Spectator mode released (' .. tostring(source or 'any')
    .. ', order ' .. tostring(order or 1) .. '/' .. tostring(count or 1) .. ')')
end

-- NOTHING RE-ASSERTS THE CAMERA, and that is the fix. Forcing freecam back on
-- once a second meant spectating did not work at all: pick something to watch
-- and the next tick took it away. Being in a car is no longer a way back into a
-- race anyway, because the inputs are filtered.
--
-- The one exception is an EVENT, not a timer: the car being watched can stop
-- existing. Finishers are removed back to back, so a spectator attached to the
-- car in front loses it seconds later and BeamNG hands the view wherever it
-- likes. So the target is followed rather than enforced, recorded every tick
-- including a car the driver tabbed to themselves, and only its ceasing to exist
-- triggers a re-acquire. Gone, not stopped: a parked car is still a car.
local function spectatorUpdate(dt)
  if not session.spectatorLock then
    spectate.target = nil
    return
  end
  spectate.recheck = (spectate.recheck or 0) - dt
  if spectate.recheck > 0 then return end
  spectate.recheck = 0.25

  local now = playerVehicle()
  local id  = now and vehicleId(now) or nil
  -- Still on something, and it is whatever the driver last chose. Record it and
  -- do nothing -- this is the branch that runs almost every tick.
  if id and getObjectByID and getObjectByID(id) then
    spectate.target = id
    return
  end
  -- The car being watched is gone. Advance ONCE to the next moving one; if the
  -- field has all finished there is nothing to advance to, and the view is left
  -- alone rather than flicked between cars that are not there.
  --
  -- No guard on having recorded a target first. An earlier version only
  -- re-acquired when `spectate.target` was already set, which reads as caution
  -- and is exactly backwards: in a bunched finish the car in front is removed
  -- within a frame or two of being attached to, often before a single tick has
  -- run to record it -- so the one case this exists for was the one case it
  -- refused to act on. Reaching here already means the lock is held and the car
  -- being watched is not there, and that is the whole of the question.
  if spectate.attachToRunner() then
    local v = playerVehicle()
    spectate.target = v and vehicleId(v) or nil
    log('I', 'raceManager', 'Spectate target gone: moved to the next moving car')
  end
end

-- The reset allowance applies for the whole of a live session - qualifying as
-- well as a race, now that qualifying is one - and the countdown that starts it.
-- The setup phases stay free.
local function resetsEnforced()
  return session.maxResets >= 0 and (sessionRunning() or session.phase == 'countdown')
end

-- Derby reset allowance, mirrored from the derby broadcast.
--
-- ONE TABLE, not three variables, because the derby lives in its own module now
-- and both halves have to see the same object. Three scalars would be copied
-- across the boundary at init and drift the moment either side wrote one: the
-- module counts a reset, this file goes on reading the number from before it.
--
-- `active` is filled in by the module, so the reset code here can ask "is a
-- derby policing resets right now?" without reaching into derby state.
local derbyResets = { max = -1, used = 0, active = function () return false end }
-- "Is a derby standing its cars down right now?" Assigned by the derby module,
-- which is scoped further down this file, and read by the reset-input block up
-- here -- without it resetInputBlockUpdate would recompute the block from the
-- reset ALLOWANCE every tick and undo the derby's one a frame after it was
-- applied.
--
-- Hung off the spectate table, which already carries this file's other
-- input-filter state, rather than taking a register of its own (see
-- docs/ARCHITECTURE.md on the 200-local ceiling).
spectate.derbyStoodDown = function () return false end

-- NO RESETS AT ALL WHILE A DERBY IS RUNNING, whatever the allowance says.
--
-- A reset REPAIRS the car. In a race that is a penalty-carrying recovery; in a
-- demolition derby it undoes the entire object of the exercise -- get wrecked,
-- press the button, come back whole. With it available the stopped timer can
-- almost never decide anything, because a driver about to be counted out just
-- resets instead, so the derby is settled by who remembers the keybind.
--
-- This used to be an ALLOWANCE, defaulting to unlimited, which is to say
-- defaulting to off. The allowance is gone: being wrecked is final, and that is
-- what makes a last man standing mean anything.
local function derbyResetsEnforced()
  return derbyResets.active()
end

-- Switch the reset/recover input actions off (or back on) via BeamNG's input
-- action filter. With the filter armed the keys are dead at the source: the
-- vehicle never resets at all. Older builds without the filter fall back to
-- the restore in onVehicleResetted.
local function setResetInputsBlocked(blocked)
  blocked = blocked and true or false
  if blocked == block.resetInputs then return end
  if setActionGroupBlocked('raceManagerResets', block.RESET_ACTIONS, blocked) then
    block.resetInputs = blocked
    log('I', 'raceManager', 'Reset inputs ' .. (blocked and 'BLOCKED' or 'released'))
  end
end

-- Kill propulsion while a derby stands its cars down.
--
-- Read the note below before widening this: throttle blocking during a GRID
-- HOLD was removed on purpose, because revving against the hold and picking a
-- gear before the lights is how a standing start works. A derby that has
-- already been decided is the opposite case -- there is nothing left to rev
-- for, and the noise is the complaint.
function spectate.setPropulsionBlocked(blocked)
  blocked = blocked and true or false
  if blocked == spectate.propulsionBlocked then return end
  if setActionGroupBlocked('raceManagerPropulsion', spectate.PROPULSION, blocked) then
    spectate.propulsionBlocked = blocked
    log('I', 'raceManager', 'Propulsion ' .. (blocked and 'BLOCKED' or 'released'))
  end
end

-- NOTE: driving inputs are deliberately NOT filtered while a car is held.
-- controller.setFreeze pins the car in place but leaves the drivetrain live, and
-- that is the point: revving against the hold and pre-selecting a gear before
-- the lights is how a standing start is supposed to work. A previous build
-- blocked throttle/clutch/shift here as a "second mechanism" and took that away
-- from every driver; the freeze alone is the correct primitive.

-- Recomputed every frame (cheap: only acts on a change): the reset keys go
-- dead the moment the allowance is spent and come back the moment the session
-- lets go of the rule.
-- Same shape as setResetInputsBlocked, and deliberately a SEPARATE filter group:
-- the two answer to different things. Resets are blocked when an allowance runs
-- out; the teleports are blocked for the whole session regardless, so a driver
-- with resets to spare still cannot put themselves on their spawn point.
local function setTeleportInputsBlocked(blocked)
  blocked = blocked and true or false
  if blocked == block.teleportInputs then return end
  if setActionGroupBlocked('raceManagerTeleport', block.TELEPORT_ACTIONS, blocked) then
    block.teleportInputs = blocked
    log('I', 'raceManager', 'Teleport inputs ' .. (blocked and 'BLOCKED' or 'released'))
  end
end

local function resetInputBlockUpdate()
  -- THE TELEPORTS GO OFF FOR THE WHOLE SESSION, and come back the moment it
  -- ends. Not gated on the reset allowance: this is not a reset being rationed,
  -- it is a move that has no place in a race at all.
  --
  -- A driver who is OUT of the session keeps them. Being able to put a spectated
  -- car back on the road is the same courtesy the reset rules already extend
  -- them, and they are not being scored for where it ends up.
  setTeleportInputsBlocked(sessionRunning() and not session.spectatorLock)
  local wantBlocked = not session.spectatorLock
    and ((resetsEnforced() and session.resetsUsed >= session.maxResets)
      or (derbyResetsEnforced() and derbyResets.used >= derbyResets.max))
  -- ...and while a derby is standing its cars down. A reset there would reload
  -- the vehicle out from under the freeze and hand somebody a driveable car in
  -- the middle of a settled result.
  setResetInputsBlocked(wantBlocked or spectate.derbyStoodDown())
  -- Same tick, same source of truth. Recomputed rather than applied once by the
  -- derby module, so it cannot be left armed by a broadcast that never arrives.
  spectate.setPropulsionBlocked(spectate.derbyStoodDown())
end

-- Rolling "last good position" sample. Taken a few times a second while the
-- driver is out on track and NOT frozen on the grid, so a blocked reset always
-- has somewhere sane to put the car back.
-- Sampled for the whole of a live session, not only when resets are LIMITED.
--
-- It used to run only while an allowance was being enforced, which is the one
-- case it was written for -- putting a car back after a reset it was not
-- entitled to. Undoing a recovery teleport needs the same sample and has nothing
-- to do with allowances: a server running unlimited resets had no snapshot at
-- all, so there was nowhere to put a driver back to.
local function snapshotUpdate(dt)
  local wanted = resetsEnforced() or derbyResetsEnforced() or sessionRunning()
  if not wanted or session.spectatorLock or session.gridFrozen then return end
  snapshot.left = snapshot.left - dt
  if snapshot.left > 0 then return end
  snapshot.left = snapshot.EVERY
  local veh = playerVehicle()
  if not veh then return end
  local ok = pcall(function ()
    local pos = veh:getPosition()
    local rot = veh:getRotation()
    snapshot.pos = vec3(pos.x, pos.y, pos.z)
    snapshot.rot = quat(rot.x, rot.y, rot.z, rot.w)
  end)
  if not ok then snapshot.pos, snapshot.rot = nil, nil end
end

-- Remember a teleport this mod just performed, so the vehicle-reset hook it
-- provokes can be recognized as our own doing rather than a driver reset.
local function noteSelfTeleport(x, y, z)
  block.selfTeleport.left = block.TELEPORT_WINDOW
  block.selfTeleport.x, block.selfTeleport.y, block.selfTeleport.z = x, y, z
  -- REMEMBERED HERE, because here is the last moment it is still true.
  --
  -- A teleport breaks the coupling: the trailer arrives with the car (BeamNG
  -- brings it, which is why one turns up on the grid at all) but arrives
  -- UNCOUPLED, and the driver has been re-attaching it by hand every race. By
  -- the time the reset echo lands there is nothing left to ask -- the couplers
  -- are already detached -- so whether there was a trailer has to be recorded
  -- before the car moves rather than discovered afterwards.
  --
  -- INLINE rather than a named helper, and that is the file talking: this is
  -- the 200th local and there is no 201st. It is called from exactly one place
  -- anyway.
  --
  -- core_vehicles.attachedCouplers is the live list of coupled pairs, each
  -- { vehA, vehB, nodeA, nodeB }; a trailer shows up as a pair naming our id on
  -- one side or the other. Read behind pcall and a type test, because that is a
  -- GE extension that may not be loaded and a build that renames it should cost
  -- the trailer rather than every teleport the mod performs.
  block.selfTeleport.hadRig = false
  local veh = ownVehicle()
  if veh then
    local id = vehicleId(veh)
    pcall(function ()
      if not (core_vehicles and type(core_vehicles.attachedCouplers) == 'table') then return end
      for _, pair in ipairs(core_vehicles.attachedCouplers) do
        if pair[1] == id or pair[2] == id then
          block.selfTeleport.hadRig = true; return
        end
      end
    end)
  end
end

-- True when the reset just reported is the echo of our own teleport: it arrived
-- inside the window AND the car is sitting where we put it. Both halves matter -
-- the window alone would swallow a driver reset pressed immediately after a
-- block, and a driver reset always moves the car somewhere else.
--
-- "Where we put it" cannot be a fixed radius, though. BeamNG v0.39 reworked the
-- teleport detector (objectTeleported(): "improved detection to reduce false
-- positives/negatives in extreme cases (such as ... really fast vehicles)"), so
-- an echo we used to hear on the same frame can now arrive a frame or two later
-- - and a car doing 250 km/h covers 2 meters in a frame and a half. Judged
-- against a fixed 2 m the car would already be "somewhere else", the echo would
-- be read as a driver reset, and a legitimately gridded or restored driver would
-- be charged an allowance (or dragged back again). So the tolerance grows with
-- how far the car could actually have travelled since we moved it: its own
-- speed times the time elapsed. At the instant of the teleport that is exactly
-- the old 2 m test, which is why a reset pressed right after a block is still
-- caught as a real attempt.
local function isSelfTeleportEcho()
  if block.selfTeleport.left <= 0 then return false end
  local veh = playerVehicle()
  if not veh then return false end
  local elapsed = block.TELEPORT_WINDOW - block.selfTeleport.left
  if elapsed < 0 then elapsed = 0 end
  local ok, near = pcall(function ()
    local p = veh:getPosition()
    local st = block.selfTeleport
    local dx, dy, dz = p.x - st.x, p.y - st.y, p.z - st.z
    local v = veh:getVelocity()
    local speed = math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z)
    local allowed = block.TELEPORT_RADIUS + speed * elapsed
    return (dx * dx + dy * dy + dz * dz) <= allowed * allowed
  end)
  return ok and near == true
end

-- Is this car standing in that pit stall?
--
-- A box, not a plane. A checkpoint is crossed; a pit stall is DRIVEN INTO and
-- occupied, so the test is "am I in it", measured on the stall's own axes so a
-- stall angled to the lane still reads correctly. Using the crossing test here
-- would let a car trigger a pit stop by clipping the box at racing speed, which
-- is the opposite of what a pit stop is.
function pit.inside(wp, pos)
  local w, h, d = gateDims(wp)
  local dx, dy, dz = pos.x - wp.x, pos.y - wp.y, pos.z - wp.z
  local fx, fy = wp.hx or 0, wp.hy or 1
  local lat = dx * fy - dy * fx          -- across the stall
  local fwd = dx * fx + dy * fy          -- along it
  return math.abs(lat) <= w * 0.5
     and math.abs(fwd) <= TUNE.PIT_DEPTH
     and dz <= h and dz >= -d
end

-- Ghosting for the duration of a stop.
--
-- A stopped car in a stall is a hazard placed in the one part of the track
-- everybody else arrives at slowly and off-line, and it cannot move out of the
-- way -- it is frozen by the stop. So it stops being something to hit.
--
-- Rides the SERVER's reset-ghost switch rather than a rule of its own. Ghosting
-- is per vehicle and applied by each client separately (see COMPATIBILITY.md),
-- so every client has to agree about the same car: ghosting locally while the
-- server refuses to relay it produces a car that is a ghost to its driver and
-- solid to everyone else, which is worse than not ghosting at all. Gating both
-- halves on the same switch keeps them in step, and the broadcast duration is
-- the stop's own length so the ghost ends everywhere at the same moment.
function pit.setGhost(on)
  if on then
    if pit.ghostVeh then return end
    if not ghost.rules.onReset then return end   -- server has ghosting off
    local veh = ownVehicle()
    local vehId = veh and vehicleId(veh) or nil
    if not vehId then return end
    pit.ghostVeh = vehId
    ghost.reason(vehId, 'pit', true, veh)
    -- Only tell the server if a RESET ghost is not already running on this car.
    -- The two share one per-player ghost on the server, so announcing a 5 s pit
    -- ghost over a 15 s reset ghost would cut the longer one short for everyone
    -- else -- and the car is already ghosted on every client anyway, which is
    -- the only thing the broadcast is for. Locally the two are separate reasons,
    -- so whichever ends last is what actually restores collision.
    pit.ghostSent = inMultiplayer() and ghost.own.vehId == nil
    if pit.ghostSent then
      TriggerServerEvent('RM_GhostStart', jsonEncode({ duration = TUNE.PIT_HOLD_SEC }))
    end
    log('I', 'raceManager', string.format('Pit ghost on for vehicle %s (%.1fs)%s',
      tostring(vehId), TUNE.PIT_HOLD_SEC,
      pit.ghostSent and '' or ' (local only: a reset ghost already owns the broadcast)'))
  else
    local vehId = pit.ghostVeh
    if not vehId then return end
    pit.ghostVeh = nil
    ghost.reason(vehId, 'pit', false)
    -- Symmetrically: only end what we started. Ending a broadcast we did not
    -- send would drop a reset ghost that is still running.
    if pit.ghostSent and inMultiplayer() and ghost.own.vehId == nil then
      TriggerServerEvent('RM_GhostEnd', '')
    end
    pit.ghostSent = false
  end
end

-- Let a car go again, and forget the stop.
-- OUT OF THE LANE. One function, because there are two ways out and they must
-- do the same thing: the exit gate, and clearing any route checkpoint.
--
-- The checkpoint route is the fallback, and it is not a nicety. A driver who
-- misses the exit gate is plainly back on the racing line the moment they clear
-- a checkpoint, and without this they would carry a lane full of stall markers
-- to the flag with no way to get rid of them.
function pit.leaveLane(reason)
  if not pit.inLane then return end
  pit.inLane = false
  log('I', 'raceManager', 'Left the pit lane (' .. tostring(reason or 'exit') .. ')')
  pushRouteState()
end

function pit.release(reason)
  if not pit.active then return end
  pit.active   = false
  pit.left     = 0
  pit.settleLeft = 0
  pit.cooldown = TUNE.PIT_COOLDOWN
  -- The car is standing in the box it just used. It does not get another stop
  -- out of that box until it has driven out of it.
  pit.mustLeave = true
  pit.setGhost(false)
  setLocalVehicleFrozen(false)
  pushRouteState()
  log('I', 'raceManager', 'Pit stop ended (' .. tostring(reason or 'complete') .. ')')
end

-- The pit stop itself: hold the car, repair it, hand it back.
--
-- Deliberately NOT a respawn anchor. A stall repairs the car where it stands
-- and nothing more -- it does not become the place a later reset returns to,
-- which keeps it clear of the reset ruleset entirely.
function pit.update(dt)
  if pit.cooldown > 0 then pit.cooldown = pit.cooldown - dt end

  -- A stop cannot outlive the session it started in, or a driver is handed a
  -- frozen car in the lobby.
  if pit.active and not (sessionRunning() and not session.spectatorLock) then
    pit.release('session ended')
    return
  end

  if pit.active then
    pit.left = pit.left - dt
    -- THE HOLD IS JUST A HOLD. Everything the stop DOES to the car happened the
    -- moment it stopped: repaired, stood straight, frozen, ghosted, in that
    -- order and in one place.
    --
    -- What is left here is settling. recoverInPlace is queued into the vehicle's
    -- own Lua VM and that VM RELOADS to service it, silently taking the freeze
    -- and the ghost with it -- both are vehicle-side calls. So they are
    -- re-asserted for a short window afterwards rather than once at a moment
    -- picked in advance: a fixed re-apply is a guess about how long a reload
    -- takes, and this simply keeps saying it until the car has settled.
    if pit.settleLeft > 0 then
      pit.settleLeft = pit.settleLeft - dt
      local veh = ownVehicle()
      if veh then
        setLocalVehicleFrozen(true, 'pit')
        if pit.ghostVeh then ghost.apply(pit.ghostVeh, veh, true, TUNE.GHOST_ALPHA) end
        -- AND THE ECHO WINDOW WITH THEM. recoverInPlace is queued into the
        -- vehicle VM, so the vehicle-reset hook it provokes lands whenever that
        -- VM gets to it -- a frame later on a quiet map, several under load.
        -- Arming the window once at entry means a slow reload comes back after
        -- it has closed and is read as a DRIVER reset: reported to the server
        -- and charged against the allowance, for a repair the mod asked for.
        local ok, p2 = pcall(function () return veh:getPosition() end)
        if ok and p2 then noteSelfTeleport(p2.x, p2.y, p2.z) end
      end
    end
    if pit.left <= 0 then
      pit.release('complete')
      pushNotice('pit', 'GO!')
    end
    return
  end

  if pit.promptLeft > 0 then pit.promptLeft = pit.promptLeft - dt end

  if #track.pitRoute == 0 then return end
  if not sessionRunning() or session.spectatorLock or session.gridFrozen then return end
  local veh, pos = sampledVehicle()
  if not veh or not pos then return end

  -- THE LANE'S MOUTH AND ITS EXIT.
  --
  -- Crossing an entry gate is what puts the stalls on screen; before that a
  -- driver sees one gate at the lane's mouth and nothing else, which is the
  -- whole saving. Either direction counts, because a lane can be entered from
  -- either end on some layouts and a driver who backs in has still arrived.
  --
  -- ITS OWN PREVIOUS POSITION, not session.prevPos.
  --
  -- checkGates runs earlier in the same frame and sets session.prevPos to the
  -- CURRENT sample on its way out, so by the time this runs the two are the
  -- same point and every gate test is a zero-length segment that can never
  -- cross anything. Caught by the test below, which sat at "in the lane: false"
  -- however far the car was driven through the gate.
  local prev = pit.prevPos
  pit.prevPos = { x = pos.x, y = pos.y, z = pos.z }
  if prev then
    for _, wp in ipairs(track.pitEntry) do
      if segmentCrossesGate(wp, prev, pos) then
        if not pit.inLane then
          pit.inLane = true
          log('I', 'raceManager', 'Entered the pit lane')
          pushRouteState()
        end
        break
      end
    end
    if pit.inLane then
      for _, wp in ipairs(track.pitExit) do
        if segmentCrossesGate(wp, prev, pos) then
          pit.leaveLane('exit gate')
          break
        end
      end
    end
  end

  -- Which stall the car is standing in, if any. Worked out BEFORE the cooldown
  -- is consulted, so driving out during it still re-arms the stall: leaving is
  -- what makes the next entry a fresh visit, and a driver who has left and come
  -- back has done the thing a stop asks for.
  local inStall = nil
  for i, wp in ipairs(track.pitRoute) do
    if pit.inside(wp, pos) then inStall = i; break end
  end
  if not inStall then
    pit.mustLeave = false
    return
  end
  if pit.mustLeave or pit.cooldown > 0 then return end

  -- Being in the box is no longer enough to be serving a stop.
  --
  -- A pit stop is something a driver PERFORMS. The trigger used to be the box
  -- alone, so a car that clipped a corner of a stall at racing speed was seized
  -- and frozen where it stood -- the stop happened TO them, in the middle of the
  -- lane, at whatever angle they were traveling. Now the car has to actually be
  -- stopped in the stall, which is the thing a pit stop is, and which puts the
  -- decision back with the driver: come in slowly enough to stop in the box, or
  -- run through it and go round again. Missing it costs nothing but the lap --
  -- no stop is started, so no cooldown is spent and the stall is live on the
  -- next visit.
  local ok, speed = pcall(function ()
    local v = veh:getVelocity()
    return math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z)
  end)
  if not ok or not speed then return end

  if speed > TUNE.PIT_STOP_SPEED then
    -- In the box and still rolling. Say so, throttled -- unthrottled this is a
    -- UI push every frame for as long as a car creeps across the stall.
    if pit.promptLeft <= 0 then
      pit.promptLeft = TUNE.PIT_PROMPT_EVERY
      pushNotice('pit', 'PIT STALL: come to a stop inside the box')
    end
    return
  end
  pit.active   = true
  pit.left     = TUNE.PIT_HOLD_SEC
  pit.stops    = pit.stops + 1
  pit.promptLeft = 0
  pit.settleLeft = TUNE.PIT_SETTLE_SEC
  -- SERVICE THE CAR, ONCE, HERE.
  --
  -- Stopped in the box is the whole entry condition; what follows is the stop
  -- itself and it is four things in a fixed order: stand it straight on the
  -- stall, repair it, freeze it, ghost it. The hold that follows is only a
  -- clock.
  --
  -- The repair used to happen part way through the hold, which meant the car
  -- was mutated twice at two different moments and each one needed the freeze
  -- and the ghost putting back separately. One service is easier to reason
  -- about and easier to watch.
  --
  -- STRAIGHT BEFORE REPAIRED, deliberately: recoverInPlace recovers where the
  -- car IS, so placing it first is what makes "in place" mean the stall.
  --
  -- A stall is driven into, and cars arrive in it sideways, backwards, or half
  -- off the side of it -- a spin into the pit lane is exactly when somebody
  -- needs a stop. Freezing them in whatever attitude they landed in meant the
  -- release handed back a car pointing at the wall, which costs more time than
  -- the stop did.
  --
  -- Done on ENTRY rather than at the release: the driver watches the hold count
  -- down, so the car being straightened is visible and reads as being serviced,
  -- where a snap at the moment of release reads as the mod grabbing the car.
  -- The position comes from the stall rather than from where they stopped, so a
  -- car half out of the box is pulled into it.
  --
  -- Noted as our own teleport first. Without that the reset hook this provokes
  -- is read as a driver reset and spends an allowance nobody used, which is the
  -- bug the grid placement already had once.
  local stallWp = track.pitRoute[inStall]
  if stallWp then
    local wp = stallWp
    -- The car's OWN height, not a ground probe. It is stopped in the stall, so
    -- it is already standing on whatever surface the stall is on -- and groundAt
    -- is declared below this point anyway, so naming it here would resolve to a
    -- nil global and throw on the first pit stop of the session.
    local okPlace = pcall(function ()
      noteSelfTeleport(wp.x, wp.y, pos.z)
      local r = headingRot(wp.hx or 0, wp.hy or 1)
      veh:setPositionRotation(wp.x, wp.y, pos.z, r.x, r.y, r.z, r.w)
    end)
    if not okPlace then
      log('W', 'raceManager', 'Pit stall: could not straighten the car, leaving it as it landed')
    end
  end
  -- The repair is a vehicle reset as far as BeamNG is concerned, and the reset
  -- hook must recognize it as ours: a pit stop is not a driver reset and must
  -- never spend a reset allowance or be reported as one. noteSelfTeleport above
  -- is what covers it.
  pcall(function () veh:queueLuaCommand('recovery.recoverInPlace()') end)
  setLocalVehicleFrozen(true, 'pit')
  -- Ghost before the notice, so a car that is about to sit frozen in the lane
  -- stops being solid on the same frame it stops being able to move.
  pit.setGhost(true)
  pushNotice('pit', string.format('PIT STOP: %.0fs', TUNE.PIT_HOLD_SEC))
  pushRouteState()
  log('I', 'raceManager', string.format(
    'Pit stop %d started in stall %d', pit.stops, inStall))
  if inMultiplayer() then
    TriggerServerEvent('RM_PitStop', jsonEncode({ stall = inStall }))
  end
end

-- Age out both reset-side timers.
local function resetGuardUpdate(dt)
  local st = block.selfTeleport
  if st.left           > 0 then st.left           = st.left           - dt end
  if block.noticeLeft  > 0 then block.noticeLeft  = block.noticeLeft  - dt end
end

-- Heading (hx, hy) -> yaw about Z, expressed as a quaternion that stands a
-- VEHICLE facing down that heading. BeamNG vehicle models point down -Y at
-- identity, so a half-turn is baked in on top of the heading yaw - without it
-- every placement came out exactly 180° backwards.
headingRot = function (hx, hy)
  local yaw  = math.atan2(hx, hy) + math.pi
  local half = yaw * 0.5
  return quat(0, 0, math.sin(half), math.cos(half))
end

-- THE GROUND UNDER A POINT, or nil when nothing is there to stand on.
--
-- One probe, shared by everything that needs to know where the map is: grid
-- generation, click placement, the drag path and the reset relocation all used
-- to answer this differently or not at all, which is how a grid generated on a
-- slope ended up with its back rows inside the hill.
--
-- Starts ABOVE the point rather than at it, so a gate already buried still finds
-- the surface above itself and can be dug out. Returns nil rather than a guess
-- when the ray finds nothing: a caller that cannot locate the ground should
-- leave the height alone, not slam it to zero.
local function groundAt(x, y, z)
  if type(castRayStatic) ~= 'function' then return nil end
  z = tonumber(z) or 0
  -- STRAIGHT DOWN FROM THE POINT ITSELF, first. Whatever this finds is the
  -- ground UNDER the gate, which is the only surface that has any claim to be
  -- called its ground.
  --
  -- The first version of this started fifty meters ABOVE the gate and took the
  -- first thing it hit on the way down, which is not the ground: it is whatever
  -- is HIGHEST in that column. A gate under a bridge got the bridge deck, a gate
  -- beside a building got the roof, a gate under trees got the canopy -- and
  -- liftAboveGround duly teleported it up onto them. Worse, because that
  -- function only ever raises, the bogus surface then became the floor that
  -- shift+scroll clamped against, so the gate could not be brought back down.
  -- That is the "my checkpoints fly into the sky and I cannot retrieve them"
  -- report, and it was entirely this.
  --
  -- The small epsilon starts the ray just clear of the point so a gate resting
  -- exactly on the surface still registers a hit rather than starting inside it.
  local ok, dist = pcall(castRayStatic, vec3(x, y, z + 0.05), vec3(0, 0, -1),
    TUNE.GROUND_PROBE_DOWN)
  if ok and type(dist) == 'number' and dist < TUNE.GROUND_PROBE_DOWN then
    return z + 0.05 - dist
  end
  -- Nothing below it at all: the point is inside the terrain, or under it. NOW
  -- the probe from above is the right question, because the surface it finds is
  -- the one this gate is buried in and needs rescuing to. This is the only case
  -- that branch was ever meant to serve.
  --
  -- AND IT LOOKS FOR THE LOWEST SURFACE ABOVE THE POINT, not the first one a
  -- long ray happens to meet. A single probe from high up has exactly the same
  -- weakness as the version this replaced: it returns whatever is highest in the
  -- column, so a gate buried in a hillside under a bridge gets the bridge.
  --
  -- So the probe walks UP in steps, and each ray is only long enough to reach
  -- back down to the point. The first step that hits anything has found the
  -- lowest surface the gate is under, which is the one it is buried in. A roof
  -- forty meters overhead is never even reached, because the ray that could see
  -- it is not cast until the shorter ones have already answered.
  for _, up in ipairs(TUNE.GROUND_RESCUE_STEPS) do
    local from = z + up
    ok, dist = pcall(castRayStatic, vec3(x, y, from), vec3(0, 0, -1), up + 0.1)
    if ok and type(dist) == 'number' and dist <= up then
      return from - dist
    end
  end
  return nil
end

-- Lift a point so it clears the ground under it by at least `clear` meters.
-- Points already higher than that are left exactly where they are: this rescues
-- a buried thing without flattening a gate deliberately placed up on a bridge.
local function liftAboveGround(x, y, z, clear)
  local g = groundAt(x, y, z)
  if not g then return z end
  local floor = g + (clear or TUNE.GROUND_CLEAR)
  return (z < floor) and floor or z
end

-- Lower a gate by `step`, but never past the ground and never into ground we
-- cannot see.
--
-- liftAboveGround alone is not enough for a DOWNWARD move: when the probe finds
-- nothing it returns the height unchanged, which for a lift is the safe answer
-- (leave it alone) and for a drop is the dangerous one (the requested drop has
-- already been applied to the value handed in, so it sinks with no floor under
-- it). Every press would take it further down with nothing able to stop it.
--
-- So the probe happens BEFORE the move: no ground, no drop.
local function lowerToGround(x, y, z, step, clear)
  clear = clear or TUNE.GROUND_CLEAR
  local g = groundAt(x, y, z)
  if not g then return z end
  local floor = g + clear
  local want = z - math.abs(step)
  return (want < floor) and floor or want
end

-- "Last Checkpoint" reset mode: stand the car on a gate's center, facing the
-- gate's direction of travel. The teleport is flagged as our own so the
-- vehicle-reset echo it provokes is never miscounted, and the gate becomes the
-- new "last good position" so a blocked follow-up reset restores there.
local function relocateToGate(wp)
  local veh = playerVehicle()
  if not veh or not wp then return false end
  -- Facing the way the car was GOING, not the way the gate points.
  --
  -- A gate crossed from both sides carries one heading and is driven both ways.
  -- Standing a counter-clockwise driver on it facing the stored heading turns them
  -- to face the clockwise field -- on a layout built around head-on collisions,
  -- that is a respawn pointing into oncoming traffic. lastGateBack is recorded at
  -- the crossing itself, so it is right for shared gates, branch gates and
  -- ordinary gates without any of them having to declare anything.
  local hx, hy = wp.hx, wp.hy
  if lastGateBack and wp == lastGate then hx, hy = -hx, -hy end
  local rot = headingRot(hx, hy)
  -- CLAMPED ABOVE THE GROUND, defensively.
  --
  -- Placement puts gates clear of the terrain now, but a layout saved before
  -- that still holds gates sitting exactly on the surface -- and a car dropped
  -- at a gate's z has its ORIGIN there, which is half a car underground. Rather
  -- than ask every admin to re-place their tracks, the respawn refuses to put a
  -- car below the ground under it whatever the gate claims.
  local z = liftAboveGround(wp.x, wp.y, wp.z, TUNE.GROUND_CLEAR)
  noteSelfTeleport(wp.x, wp.y, z)
  local ok = pcall(function ()
    veh:setPositionRotation(wp.x, wp.y, z, rot.x, rot.y, rot.z, rot.w)
  end)
  if ok then
    snapshot.pos = vec3(wp.x, wp.y, z)
    snapshot.rot = rot
  else
    block.selfTeleport.left = 0
  end
  return ok
end

-- Undo a reset the driver was not entitled to. BeamNG has already teleported
-- the car by the time onVehicleResetted fires, so the block is applied after
-- the fact: put the car back exactly where it was standing a moment ago.
local function restoreLastGoodPosition()
  local veh = playerVehicle()
  if not veh or not snapshot.pos then return false end
  local rot = snapshot.rot or quat(0, 0, 0, 1)
  -- Armed BEFORE the teleport: the hook it triggers may arrive on this very
  -- frame, and hearing it back as a driver reset is what caused the loop.
  noteSelfTeleport(snapshot.pos.x, snapshot.pos.y, snapshot.pos.z)
  local ok = pcall(function ()
    veh:setPositionRotation(snapshot.pos.x, snapshot.pos.y, snapshot.pos.z,
      rot.x, rot.y, rot.z, rot.w)
  end)
  if not ok then block.selfTeleport.left = 0 end
  return ok
end

-- BeamNG hook: the local player reset/recovered a vehicle. Registered as an
-- extension hook, so it fires for every vehicle - filter to our own first.
function M.onVehicleResetted(vehId)
  -- Ours, or there is nothing here to do. The attached vehicle can be another
  -- player's car - that is precisely the situation a driver who has just been
  -- taken off the track is in - and treating their reset as ours is how a rival
  -- ends up having their vehicle removed.
  if not isOwnVehicle(vehId) then return end
  local veh = ownVehicle()
  if not veh or vehicleId(veh) ~= vehId then return end
  -- Our own teleport coming back at us (a restore, a grid placement, a preview).
  -- Never a driver reset, so it must not be counted, blocked or reported.
  if isSelfTeleportEcho() then
    -- ...but this IS the moment a placement teleport wipes the freeze, because
    -- the reset reloads the vehicle's Lua VM and controller state with it. If a
    -- hold is wanted, put it straight back here rather than polling for it: this
    -- fires exactly when it is needed and nowhere else, so the drivetrain is
    -- left alone afterwards and a driver can still rev and pick a gear against
    -- the hold.
    if holdWanted then
      setLocalVehicleFrozen(true, holdWanted)
      log('I', 'raceManager', 'Hold re-applied after placement reset (' .. tostring(holdWanted) .. ')')
    end
    return
  end
  if session.spectatorLock then
    -- Out of the session. A reset here is a driver recovering a car they are
    -- only spectating in -- flipped, in the water, or dropped off the map -- and
    -- it is allowed. It costs them nothing: the reset allowance is only counted
    -- while a driver is being scored, and they stopped being scored the moment
    -- the lock went on.
    --
    -- THE FINISHED GHOST HAS TO SURVIVE IT. A reset reloads the vehicle's Lua VM,
    -- which is where setGhostEnabled lives, so the collision toggle is undone by
    -- the reset itself and has to be re-applied to the car that came back. The
    -- reason set is per vehicle and independent, so re-asserting here cannot
    -- disturb a reset ghost or a quali ghost sharing the same car.
    --
    -- A derby elimination keeps its input block; a race finisher keeps driving.
    -- Re-applied the same way it is set, because the reset may have re-registered
    -- the action set out from under the filter.
    spectate.setInputsBlocked(false)   -- force the next call to re-apply
    spectate.setInputsBlocked(session.spectatorLock == 'derby')
    if session.spectatorLock ~= 'derby' then ghost.setFinished(true) end
    return
  end

  -- A DRIVER reset while held on the grid. This is not the echo above -- the car
  -- really has been reset -- and the reset has just reloaded the vehicle's Lua
  -- VM, taking the freeze with it. Nothing used to put it back, so pressing
  -- reset on the grid was a way to be the only unfrozen car on it.
  --
  -- Handled here and not left to the drift watch because the driver should not
  -- get even the fraction of a second of movement that noticing drift costs:
  -- the car goes back on its slot and is pinned again on this frame.
  if holdWanted then
    hold.restore('driver reset while held on the grid')
    pushNotice('grid', 'Reset on the grid: you are back on your slot and held')
    return
  end

  -- The car has already been moved by the time this hook runs, so ghosting is
  -- armed HERE -- above the allowance rules and before anything decides what the
  -- reset was worth. Every branch below leaves the car somewhere it was not a
  -- moment ago: an allowed reset in place, a checkpoint-mode relocation, and a
  -- BLOCKED reset too, which teleports the car back to its last good position
  -- and can just as easily put it inside somebody. Ghosting is not a reward for
  -- a legal reset, it is a guard against a car appearing inside another one, so
  -- it does not care which of those happened.
  --
  -- Deliberately armed during qualifying as well as racing: the welding hazard
  -- is physics, not regulations, and cars are on track in both.
  if ghost.rules.onReset and (session.phase == 'racing' or session.phase == 'qualifying') then
    ghost.arm()
  end

  if resetsEnforced() and session.resetsUsed >= session.maxResets then
    -- Over the allowance. The reset INPUTS are already switched off at this
    -- point (resetInputBlockUpdate), so this branch only fires for a reset
    -- path the input filter cannot see; the car goes straight back where it
    -- was, the driver stays in the race, and the server is told so the
    -- attempt shows up in the live table and the results.
    local restored = restoreLastGoodPosition()
    -- Holding the reset key fires this hook over and over. The block above runs
    -- every time; the talking about it does not, or the notice channel, the
    -- console and the server all get flooded by one held key.
    if block.noticeLeft <= 0 then
      block.noticeLeft = block.NOTICE_EVERY
      if inMultiplayer() then TriggerServerEvent('RM_ResetDenied', '') end
      -- THE MOMENT IT MATTERS: the driver reached for a reset and it did not
      -- come. Said here rather than when the last one was spent, because
      -- spending the last one still gave them a reset -- being refused one is
      -- the thing that changes what they can do about the wall they are in.
      --
      -- Every refused attempt says it again, not just the first: a driver who
      -- has forgotten and presses reset three corners later needs the same
      -- answer, and silence reads as the key having broken. Still throttled by
      -- block.noticeLeft above, which is about a HELD key rather than about
      -- repeat attempts.
      --
      -- A session with no resets at all is a different sentence. Those drivers
      -- never had one to run out of.
      if session.maxResets == 0 then
        pushNotice('resetsout', 'No resets in this session',
          { sub = 'You are on your own out there', color = 'amber' })
      else
        pushNotice('resetsout', "Uh oh! You're out of resets",
          { sub = 'All ' .. session.maxResets .. ' used', color = 'amber' })
      end
      log('W', 'raceManager', 'Reset blocked: allowance of ' .. session.maxResets
        .. ' exhausted (position ' .. (restored and 'restored' or 'NOT restored') .. ')')
    end
    -- Nothing in the pushed state changed (a blocked reset spends no allowance),
    -- so there is deliberately no pushRouteState here: it would be one more UI
    -- message per attempt for no new information.
    return
  end

  -- The reset is allowed to happen. "Last Checkpoint" mode: the repair itself
  -- already happened where the car stands (BeamNG did it before this hook
  -- fired), but the driver races on from the last checkpoint they crossed
  -- rather than from the crash site. Applies whether or not resets are
  -- limited; before the first gate of a session it falls back to in-place.
  if session.resetMode == 'checkpoint' and session.phase == 'racing' and lastGate and not session.gridFrozen then
    relocateToGate(lastGate)
  elseif sessionRunning() and not session.gridFrozen and session.prevPos then
    -- BOTH RESET KEYS HAVE TO MEAN THE SAME THING DURING A SESSION.
    --
    -- BeamNG ships two and they are not the same action: one repairs in place,
    -- the other is a RECOVERY that teleports the car to a spawn point. In a race
    -- that second one is a free ride, and drivers find it by pressing the key
    -- they normally press. Blocking it would leave a dead key, so the teleport is
    -- undone instead and both keys do the in-place repair.
    --
    -- Two references, and BOTH have been got wrong once:
    --   * prevPos ONLY, never the rolling snapshot.pos. That one is up to a
    --     quarter of a second old, and a car at racing speed covers more ground
    --     in that time than the threshold allows, so an ordinary reset looks like
    --     a teleport and gets undone. Two tests catch it, and have twice.
    --   * The car is read DIRECTLY, not through sampledVehicle(). That caches for
    --     the frame and a reset arrives mid-frame, so it returns the position
    --     from before the teleport, the distance comes out as nothing, and the
    --     undo stands down. That is why a recovery key still stranded drivers on
    --     their start position.
    local was = session.prevPos
    local veh = playerVehicle()
    local pos = nil
    if veh then pcall(function () pos = veh:getPosition() end) end
    if pos and was then
      local dx, dy, dz = pos.x - was.x, pos.y - was.y, pos.z - was.z
      if (dx * dx + dy * dy + dz * dz) > (TUNE.RECOVER_SNAP_RANGE * TUNE.RECOVER_SNAP_RANGE) then
        noteSelfTeleport(was.x, was.y, was.z)
        pcall(function ()
          local rot = veh:getRotation()
          veh:setPositionRotation(was.x, was.y, was.z, rot.x, rot.y, rot.z, rot.w)
        end)
        pushNotice('reset', 'Recovered in place: a race reset does not move you off the track')
        log('I', 'raceManager', 'Undid a recovery teleport during a session')
      end
    end
  end

  -- EVERY legal reset makes the new position the good one, immediately.
  --
  -- This lived inside the allowance check below, so on a server running unlimited
  -- resets -- the default -- it never ran. The position references then still
  -- described where the car was before the FIRST reset, and the next press
  -- dragged it back there: press one key, drive on, press the other, and land
  -- where you reset a minute ago. It read as the two keys disagreeing, and they
  -- were not: they were both measuring against the same stale sample.
  --
  -- prevPos is RE-SEEDED, not cleared. It is the per-frame sample the crossing
  -- test carries forward, and after a teleport it describes a position on the far
  -- side of one -- but clearing it leaves a hole, and the next reset to land in
  -- that hole has no reference to undo itself with. BeamNG's teleport then simply
  -- stands, which is a recovery key putting a driver back on their start position
  -- in the middle of a lap.
  --
  -- Seeded from where the car actually is now, which is both fresh and true.
  snapshot.left = 0
  do
    local _, nowPos = sampledVehicle()
    if nowPos then
      -- In place, on checkGates' terms: prevPos is a reused plain table, and
      -- `was` above is out of scope by here so nothing is reading the old value.
      local pp = session.prevPos
      if pp then
        pp.x, pp.y, pp.z = nowPos.x, nowPos.y, nowPos.z
      else
        session.prevPos = { x = nowPos.x, y = nowPos.y, z = nowPos.z }
      end
    end
  end
  if resetsEnforced() then
    session.resetsUsed = session.resetsUsed + 1
    if inMultiplayer() then TriggerServerEvent('RM_VehicleReset', '') end
    local left = session.maxResets - session.resetsUsed
    -- Spending the last one is still just the tally reaching zero. The driver is
    -- told they are OUT when they next reach for a reset and it does not come,
    -- which is the moment it actually matters to them -- see the blocked path.
    pushNotice('reset', string.format('Reset %d/%d used: %d left', session.resetsUsed, session.maxResets, left))
    pushRouteState()
    return
  end

  -- Demo derby (isolated ruleset): the same policing against the derby's own
  -- allowance while a derby is running and this driver is still in it.
  if derbyResetsEnforced() then
    -- Always: there is no allowance left to check.
    if true then
      local restored = restoreLastGoodPosition()
      if block.noticeLeft <= 0 then
        block.noticeLeft = block.NOTICE_EVERY
        if inMultiplayer() then TriggerServerEvent('RM_DerbyResetDenied', '') end
        pushNotice('reset', 'RESET BLOCKED: no resets in a derby')
        log('W', 'raceManager', 'Derby reset blocked (position '
          .. (restored and 'restored' or 'NOT restored') .. ')')
      end
      return
    end
  end
end

-- BeamNG hook: a vehicle appeared. A driver serving a spectator penalty must
-- not be able to spawn a replacement until the session ends, so their new car
-- is removed immediately. Other players' vehicles are left alone.
function M.onVehicleSpawned(vehId)
  -- Module 4: a new car means a new configuration to declare to the server -
  -- shortly, not now. Nothing about its parts is knowable on this frame.
  armVehicleConfigReport()
  -- A car that appears while a field-wide ghost is in force is ghosted NOW, not
  -- whenever the two-second sweep next comes round. A mass respawn is precisely
  -- the moment cars appear, and a car that spawns solid in the middle of one --
  -- for up to two seconds, or for good if the operation finishes first -- is the
  -- thing the ghost exists to prevent.
  if next(ghost.field) ~= nil and not isOwnVehicle(vehId) then
    local got, veh = pcall(getObjectByID, vehId)
    for reason in pairs(ghost.field) do
      ghost.reason(vehId, reason, true, got and veh or nil)
    end
  end
  -- A car reloaded or respawned while the grid is held arrives with no freeze on
  -- it - it is a new vehicle, and the old one's freeze died with it. Put the
  -- driver back on their slot, held, rather than leaving them the only car on
  -- the grid that can move.
  if holdWanted and isOwnVehicle(vehId) then
    hold.restore('vehicle respawned while held on the grid')
    pushNotice('grid', 'Back on your grid slot, held for the countdown')
  end
  if not session.spectatorLock then return end
  if not isOwnVehicle(vehId) then return end
  -- A spectator spawned themselves a fresh car. For a derby elimination the
  -- block is an INPUT filter rather than a property of the old vehicle, so the
  -- new one is just as undriveable -- but the spawn may have re-registered the
  -- action set, so it is re-applied here.
  --
  -- Deleting the car was the old answer, and it is what made an eliminated
  -- driver vanish from everybody's screen.
  --
  -- A RACE FINISHER GETS THE GHOST PUT BACK ON THE NEW CAR. It is a different
  -- vehicle with a different id and a fresh Lua VM, so it starts solid: without
  -- this, a finished driver could spawn themselves a car and drive it into the
  -- race with full collision.
  spectate.setInputsBlocked(false)
  spectate.setInputsBlocked(session.spectatorLock == 'derby')
  if session.spectatorLock ~= 'derby' then
    ghost.setFinished(true)
    pushNotice('spectate', 'Your car is a ghost: nobody still racing can touch it')
  else
    pushNotice('spectate', 'You are spectating until the session ends')
  end
  log('W', 'raceManager', 'Vehicle spawned in spectator mode ('
    .. tostring(session.spectatorLock) .. ')')
end

-- BeamNG hook: a vehicle is being removed. Ghost bookkeeping is keyed by vehicle
-- id and vehicle ids are REUSED, so an entry left behind for a deleted car is not
-- merely stale -- the next car to be handed that id inherits a ghost nobody
-- armed, and (worse) inherits the belief that it is already ghosted, so the next
-- real ghost on it does nothing at all. Dropped here rather than aged out.
function M.onVehicleDestroyed(vehId)
  if vehId == nil then return end
  ghost.veh[vehId]     = nil
  ghost.applied[vehId] = nil
  ghost.left[vehId]    = nil
  ghost.alpha[vehId]   = nil
  -- The pid -> vehicle cache points at this id too. Left behind, the next car to
  -- be handed the id would be treated as belonging to whoever owned the old one.
  for pid, id in pairs(ghost.remoteVeh) do
    if id == vehId then ghost.remoteVeh[pid] = nil end
  end
  -- Our own car going away ends our ghost outright: there is nothing left to
  -- restore collision to, and holding the timer open would leave the next car
  -- this driver spawns waiting on a countdown that belonged to a deleted one.
  if ghost.own.vehId == vehId then
    ghost.own.vehId    = nil
    ghost.own.settling = false
    ghost.own.left     = 0
    ghost.own.total    = 0
    ghost.own.blocked  = 0
    ghost.own.warned   = false
    if inMultiplayer() then TriggerServerEvent('RM_GhostEnd', '') end
  end
end

-- ===========================================================================
-- Starting grid: placement, assignment and the hold until GO
-- ===========================================================================
-- The race creator drives to each grid slot and presses "Place Start Position
-- Here"; slot 1 is pole. The list travels with the track layout. When a race is
-- formed the server hands every driver a slot number (from qualifying, at
-- random, or hand-picked by the admin) and this client puts its own car on that
-- slot and holds it there - the server has no physics access, so only the
-- client can do either half.

-- Freeze/unfreeze the local car. BeamNG's vehicle-side controller exposes
-- setFreeze; queueLuaCommand is the GE-side way in, and it is pcall'd because
-- a vehicle without that controller must not break the start procedure.
-- Who imposed the current hold: 'race' (the grid, before the lights) or 'derby'
-- (form-up, before the derby countdown). Scoped for exactly the reason the
-- spectator lock is: the two modes run their start procedures independently, and
-- a racing phase change must never let go of a car being held for a derby, or
-- the other way round. Without this a race ending would turn every held derby
-- car loose in the middle of its countdown.
local freezeSource = nil

-- Freezing a car in place.
--
-- Through core_vehicleBridge, which is how BeamNG's own career code does it
-- (cargoScreen.lua, general.lua, progress.lua all call
-- executeAction(veh, 'setFreeze', ...)). The bridge routes the call through
-- gameplayInterface inside the vehicle VM instead of poking `controller`
-- directly, and that difference matters: queueLuaCommand only QUEUES a string,
-- so `controller.setFreeze(1)` was accepted, reported success, and then quietly
-- did nothing -- which is exactly what the logs showed, a hold requested
-- successfully and a car that drove away regardless.
--
-- The direct call is kept as a fallback for builds without the bridge; it is
-- still what the game's older exploration.lua uses.
setLocalVehicleFrozen = function (frozen, source)
  local veh = playerVehicle()
  if not veh then return false end
  local want = frozen and true or false
  local ok = false
  if core_vehicleBridge and core_vehicleBridge.executeAction then
    ok = pcall(core_vehicleBridge.executeAction, veh, 'setFreeze', want)
  end
  if not ok then
    ok = pcall(function ()
      veh:queueLuaCommand('controller.setFreeze(' .. (want and '1' or '0') .. ')')
    end)
  end
  if ok then
    session.gridFrozen = want
    freezeSource = want and (source or 'race') or nil
  end
  return ok
end

-- Put the local car on a placed start position, facing down the track.
-- Rotation comes from headingRot (Module 1), which bakes in the half-turn for
-- BeamNG's -Y vehicle forward - placements used to come out 180° backwards.
placeOnStartPosition = function (sp)
  local veh = playerVehicle()
  if not veh or not sp then return false end
  local rot = headingRot(sp.hx, sp.hy)
  -- Same story as the blocked-reset restore: this teleport comes back as a
  -- vehicle reset, and being gridded must never cost a driver an allowance.
  noteSelfTeleport(sp.x, sp.y, sp.z)
  local ok = pcall(function ()
    veh:setPositionRotation(sp.x, sp.y, sp.z, rot.x, rot.y, rot.z, rot.w)
  end)
  if not ok then block.selfTeleport.left = 0 end
  return ok
end

-- Holding a car for a standing start.
--
-- ONE path, shared by both modes: place the car, freeze it once, leave it alone.
-- The race hold has always behaved correctly doing exactly this, so the derby
-- does the same rather than anything of its own -- every derby-specific variant
-- tried here (re-asserting on a timer, deferring the first application, adding a
-- second one as a backstop) made it worse, and all of them were really working
-- around a freeze call that did nothing.
--
-- Applying it more than once is not harmless: each call re-pins the car at
-- whatever state it is in and resets the drivetrain, so revs bleed away and a
-- pre-selected gear will not stick. Revving and shifting against the hold is the
-- point of a standing start, so the freeze is issued once and never repeated.
local function requestHold(source)
  holdWanted = source
  local ok = setLocalVehicleFrozen(true, source)
  if ok then
    pushRouteState()
    log('I', 'raceManager', 'Hold requested (' .. tostring(source) .. ')')
  else
    -- Never fail quietly: a car that should be held and is not looks exactly
    -- like a start procedure that has not begun.
    log('W', 'raceManager', 'Hold (' .. tostring(source) .. ') could not be applied')
  end
  return ok
end

-- Put a held car back exactly where it was placed and pin it again.
--
-- Used by every path that can lose the hold: the local drift watch, a driver
-- reset on the grid, a vehicle reloaded on the grid, and the server's
-- correction. All four want the same thing -- the car back on its slot, facing
-- down the track, frozen -- so they share one implementation and one log line.
--
-- The teleport is flagged as our own so the vehicle-reset report it provokes is
-- not read as a driver reset and does not cost anyone a reset allowance.
--
-- A field of the hold table rather than a local function, for the same two
-- reasons the ghost module is: this file is close to Lua's 200-local ceiling,
-- and onVehicleResetted -- several hundred lines above here -- has to be able to
-- call it. A table field is resolved when it is called, not when it is compiled.
function hold.restore(reason)
  if not holdWanted then return false end
  local veh = ownVehicle()
  if not veh then return false end
  -- Back to where it settled if it ever did, and to the slot itself if it has
  -- not (a reset during the settle window).
  local to = hold.anchor or hold.slot
  if to then
    local rot = hold.rot or quat(0, 0, 0, 1)
    noteSelfTeleport(to.x, to.y, to.z)
    local ok = pcall(function ()
      veh:setPositionRotation(to.x, to.y, to.z, rot.x, rot.y, rot.z, rot.w)
    end)
    if not ok then block.selfTeleport.left = 0 end
    -- The car has just been dropped again, so it has to settle again -- and
    -- until it has, nothing may measure it. Without this a restore is followed
    -- immediately by the drift it caused, which is the loop this guard is for.
    hold.anchor = nil
    hold.settleLeft = TUNE.HOLD_SETTLE_GRACE
  end
  -- After the teleport, never before: the reset that a teleport reports back
  -- would otherwise reload the vehicle VM and take this freeze with it.
  setLocalVehicleFrozen(true, holdWanted)
  hold.corrections = hold.corrections + 1
  -- One line per correction would be one line per frame for a car whose freeze
  -- cannot be applied at all, which is exactly the case worth being able to read
  -- the log for. The count keeps the total honest.
  if hold.correctLeft <= 0 then
    log('W', 'raceManager', string.format(
      'Grid hold restored (%s): correction #%d', tostring(reason), hold.corrections))
  end
  hold.correctLeft = TUNE.HOLD_CORRECT_COOLDOWN
  return true
end

-- Watch a held car and report where it is.
--
-- Locally: a car that has moved off its slot is put back, correcting the
-- SYMPTOM rather than enumerating every cause of a lost freeze. Upward: the
-- server owns the hold and is told where the car is on a steady cadence, so a
-- client modified to skip the local guard still has the server behind it.
--
-- Nothing happens until the car has SETTLED, and the resting position becomes
-- the anchor. A car dropped on a slot falls onto its suspension, which is both
-- movement and displacement: enforcing against that teleported it back up to
-- spawn height, the teleport was reported as a reset, and it hovered there being
-- reset every frame instead of settling.
--
-- Graded response: a car merely MOVING is re-frozen where it stands, which
-- provokes no reset. Only one that has LEFT its slot is teleported back.
local function holdUpdate(dt)
  if hold.correctLeft > 0 then hold.correctLeft = hold.correctLeft - dt end
  if not holdWanted then
    hold.reportLeft = 0
    return
  end
  local veh = ownVehicle()
  if not veh then return end
  local ok, pos, vel = pcall(function ()
    return veh:getPosition(), veh:getVelocity()
  end)
  if not ok or not pos then return end

  local speed = 0
  if vel then speed = math.sqrt(vel.x * vel.x + vel.y * vel.y + vel.z * vel.z) end

  -- Position reporting, and it happens whatever the enforcement below decides.
  -- Telemetry is not enforcement: a car that is still settling is exactly the
  -- car the server most wants to be able to see, and going quiet during the
  -- grace would be a window in which it was flying blind. A quarter-second
  -- cadence, because a full grid reporting every frame would be eleven messages
  -- a frame about cars that are meant not to be moving.
  if inMultiplayer() then
    hold.reportLeft = hold.reportLeft - dt
    if hold.reportLeft <= 0 then
      hold.reportLeft = TUNE.HOLD_REPORT_EVERY
      TriggerServerEvent('RM_HoldPos', jsonEncode({
        x = pos.x, y = pos.y, z = pos.z, slot = session.gridSlot,
      }))
    end
  end

  -- Settling. The car is left completely alone until it stops moving, or until
  -- the grace runs out for a car that never quite stops (resting on a kerb, an
  -- idle shake). Whatever it is doing then is the baseline.
  if hold.settleLeft > 0 then
    hold.settleLeft = hold.settleLeft - dt
    -- Settling is a car dropping onto its suspension: vertical, and going
    -- nowhere. A car that has moved ACROSS the ground is not settling, it is
    -- leaving -- so the grace is not a window in which the hold is off. It is
    -- measured from the slot here because there is no resting position yet.
    local away = 0
    if hold.slot then
      local ax, ay = pos.x - hold.slot.x, pos.y - hold.slot.y
      away = math.sqrt(ax * ax + ay * ay)
    end
    if away > TUNE.HOLD_DRIFT then
      -- THROTTLED, on the same cooldown the other two correction paths use.
      --
      -- This one had no throttle at all, and it is the branch a car being
      -- shoved on the grid actually sits in: hold.restore re-arms the settle
      -- window every time it runs, so the car never leaves this window and the
      -- notice fired on EVERY FRAME. Measured at 120 UI pushes a second -- one
      -- notice is two crossings now (the app's strip and BeamNG's Messages
      -- app), each waking a digest over the whole template, at the one moment
      -- a panel most needs to be responsive.
      --
      -- The correction itself stays per frame, deliberately: landing on the
      -- same slot is idempotent, and a car whose freeze will not take must not
      -- ratchet forward between corrections. Only the talking is rationed.
      local announce = hold.correctLeft <= 0
      if announce then
        hold.correctLeft = TUNE.HOLD_CORRECT_COOLDOWN
        hold.corrections = hold.corrections + 1
      end
      hold.restore(string.format('left the slot (%.2fm) before settling', away))
      if announce then
        pushNotice('grid', 'Hold the car, the countdown has not finished')
      end
      return
    end
    local waited = TUNE.HOLD_SETTLE_GRACE - hold.settleLeft
    if hold.settleLeft > 0
       and (waited < TUNE.HOLD_SETTLE_MIN or speed > TUNE.HOLD_SETTLED_SPEED) then
      return
    end
    hold.settleLeft = 0
    hold.anchor = vec3(pos.x, pos.y, pos.z)
    log('I', 'raceManager', string.format(
      'Grid hold settled at (%.2f, %.2f, %.2f)', pos.x, pos.y, pos.z))
    return
  end

  if hold.anchor then
    -- HORIZONTAL distance only. Creeping off the line is a move across the
    -- ground; a car dropping onto its suspension, sagging as it cools, or
    -- resting on a kerb moves vertically and is not creeping. Measuring in
    -- three dimensions makes ordinary settling indistinguishable from jumping
    -- the start, and the car gets dragged back for standing still.
    local dx = pos.x - hold.anchor.x
    local dy = pos.y - hold.anchor.y
    local drift = math.sqrt(dx * dx + dy * dy)
    if drift > TUNE.HOLD_DRIFT then
      -- Off the slot: put it back. Not rate-limited, because landing on the same
      -- anchor every time is idempotent and a car whose freeze cannot be applied
      -- at all must not be allowed to ratchet forward between corrections. Only
      -- the talking about it is throttled.
      --
      -- AND THE THROTTLE HAS TO BE ARMED HERE, which it was not. This branch
      -- read correctLeft and never set it, so `announce` was true on every
      -- frame a car sat off its slot -- a driver being shoved on the grid cost
      -- a notice at 60 Hz, and a notice is TWO pushes across the boundary now
      -- (the app's own strip and BeamNG's Messages app), each waking a digest
      -- over the whole template. Measured at 120 pushes a second before this,
      -- at the one moment a panel most needs to be responsive. The other
      -- correction branch below has always armed it; this one is the odd path.
      local announce = hold.correctLeft <= 0
      if announce then
        hold.correctLeft = TUNE.HOLD_CORRECT_COOLDOWN
        -- Counted here too. Drift corrections were missing from the tally the
        -- server is told about, so a car being pushed around on the grid
        -- reported none of it.
        hold.corrections = hold.corrections + 1
      end
      hold.restore(string.format('%.2fm off the slot at %.1f m/s', drift, speed))
      if announce then
        pushNotice('grid', 'Hold the car, the countdown has not finished')
      end
      return
    end
    if speed > TUNE.HOLD_CREEP_SPEED then
      -- Moving but still on its slot: the freeze has been lost and the car is
      -- about to leave. Re-pin it where it stands. No teleport, so no vehicle
      -- reset and none of the loop that came with one.
      setLocalVehicleFrozen(true, holdWanted)
      if hold.correctLeft <= 0 then
        hold.correctLeft = TUNE.HOLD_CORRECT_COOLDOWN
        hold.corrections = hold.corrections + 1
        log('W', 'raceManager', string.format(
          'Grid hold re-pinned a car moving at %.2f m/s on its slot', speed))
      end
      return
    end
  end

end

-- GO (or any exit from the start procedure): release the car.
-- `source` names the mode letting go. A hold imposed by the other mode is left
-- alone. Passing nil forces the release, which is what a session ending or the
-- extension unloading wants: with no server left to lift it, a held car would
-- stay held forever.
local function releaseGridHold(source)
  -- Intent goes first. A reset echo that has yet to arrive checks holdWanted
  -- before re-applying, so clearing it here is what stops a car being frozen a
  -- moment after it was deliberately let go.
  if not source or not holdWanted or holdWanted == source then
    holdWanted = nil
  end
  -- The anchor goes with the intent. A stale one would have the drift watch
  -- pulling a racing car back onto a grid slot it left at the lights.
  if not holdWanted then
    hold.anchor = nil
    hold.slot = nil
    hold.rot = nil
    hold.settleLeft = 0
    hold.reportLeft = 0
  end
  if not session.gridFrozen then return end
  if source and freezeSource and freezeSource ~= source then return end
  setLocalVehicleFrozen(false)
  session.gridFrozen = false
  freezeSource = nil
  pushRouteState()
end

-- ===========================================================================
-- Field placement: one ghosted, staggered queue
-- ===========================================================================
-- Everything that moves this client's car as part of a FIELD goes through here:
-- forming a grid, and putting every car back when a session ends. Both are the
-- same physical problem -- several vehicles arriving at nearly the same place at
-- nearly the same instant -- and both used to be done immediately, on the tick
-- the server event arrived. That is how a spawn gets refused for an occupied
-- location, and how two cars land inside each other and are thrown apart by the
-- solver the moment they exist.
--
-- Three things fix it, and all three are needed:
--   * Ghosting. Collisions with other players' cars are off for the whole
--     operation, so a car landing on top of another is a non-event.
--   * A stagger. Each client waits (its order in the field) x STAGGER before
--     placing its own car, so the field lands as a sequence, not a pile. No
--     coordination is needed: the server hands out the order with the slot.
--   * A settle window before collisions come back, sized for the WHOLE field
--     rather than our own car, plus a hard timeout so a client that somehow
--     never finishes still gets its collisions back.
--
-- The settle is deliberately a TIMER and not a "wait until the cars stop
-- moving" test. On a grid the cars are frozen for the standing start, so they
-- are already still; a motion test would either fire instantly or never, and
-- collisions have to come back on a held car exactly as reliably as on a rolling
-- one.
local FIELD = {
  STAGGER     = 0.18,   -- seconds between one car landing and the next
  SETTLE      = 1.2,    -- seconds after the last car lands
  SPAWN_GRACE = 0.5,    -- seconds for a spawned vehicle to exist
  TIMEOUT     = 15.0,   -- hard cap: collisions come back regardless
  -- Re-coupling a trailer after the placement ghost lifts. The window is long
  -- because the ghost lift is itself a queued vehicle-side command: how many
  -- frames it takes for collisions to actually come back is not something this
  -- side can know, and a coupler found before they do attaches to nothing.
  COUPLE_FOR   = 3.0,   -- seconds the retry window stays open
  COUPLE_EVERY = 0.4,   -- seconds between attempts inside it
}

local field = {
  active  = false,
  -- Trailer re-coupling: whether this driver had one on the back when the
  -- placement was queued, how long the retry window has left, and when the next
  -- attempt is due.
  hadRig     = false,
  coupleLeft = 0,
  coupleNext = 0,
  step    = nil,     -- wait | spawn | grace | place | settle
  delay   = 0,       -- until OUR car is placed
  grace   = 0,       -- until a just-spawned vehicle is usable
  settle  = 0,       -- until collisions come back
  timeout = 0,
  respawn = false,   -- put our removed car back as part of this operation
  slot    = nil,     -- slot to stand on
  slots   = nil,     -- which slot list that indexes (race grid or derby arena)
  hold    = false,   -- freeze once placed
  holdSource = nil,  -- 'race' | 'derby' -- who owns the hold, so the other mode
                     -- can never release it
}

-- Stand the car on its assigned slot. Called from the scheduler, never directly:
-- placing a car is the part that has to be staggered and ghosted.
local function placeOnAssignedSlot()
  local slot = field.slot
  local list = field.slots or track.startPositions
  local sp = slot and list[slot]
  -- Same fallback as the respawn above, and for the same reason: any placed slot
  -- is a better place to stand than wherever the car happened to appear.
  if not sp then sp = list[1] end
  if not sp then
    pushNotice('grid', 'Start position ' .. tostring(slot) .. ' is not placed on this track')
    log('W', 'raceManager', 'Grid slot ' .. tostring(slot) .. ' has no start position')
    return
  end
  if not placeOnStartPosition(sp) then
    log('W', 'raceManager', 'Could not place the car on grid slot ' .. tostring(slot))
    return
  end
  -- Where this car is meant to be standing, remembered before the hold is asked
  -- for. Everything that verifies or restores the hold measures against this:
  -- the local drift watch, the reset/respawn restores, and the server's
  -- correction. Kept separately from snapshot.pos below because that one belongs
  -- to the reset ruleset and moves as the driver laps.
  if field.hold then
    -- The slot's coordinates are where the car is DROPPED, not where it will
    -- come to rest -- it still has to fall onto its suspension. Anchoring here
    -- would mean every correction teleported the car back up to the drop height,
    -- so the anchor is left unset and captured once the car has settled.
    hold.anchor = nil
    hold.slot   = vec3(sp.x, sp.y, sp.z)
    hold.rot    = headingRot(sp.hx, sp.hy)
    hold.settleLeft  = TUNE.HOLD_SETTLE_GRACE
    hold.corrections = 0
  end
  if field.hold then requestHold(field.holdSource or 'race') end
  -- The grid slot is where the car legitimately stands, so it is also the
  -- position a blocked reset should restore to - facing down the track, not
  -- at whatever identity rotation happens to mean on this circuit.
  snapshot.pos = vec3(sp.x, sp.y, sp.z)
  snapshot.rot = headingRot(sp.hx, sp.hy)
  pushNotice('grid', 'You start from P' .. slot .. ': hold for the countdown')
  log('I', 'raceManager', 'Placed on start slot ' .. slot
    .. ' (' .. tostring(field.holdSource or 'race') .. ')')
end

local function endFieldOperation()
  field.active = false
  field.step   = nil
  field.slot   = nil
  field.slots  = nil
  field.respawn = false
  field.holdSource = nil
  if setGhostReason then setGhostReason('placement', false) end
  -- THE TRAILER GOES BACK ON FROM HERE, not a moment earlier.
  --
  -- The first attempt at this fired in the vehicle-reset echo, which is during
  -- the placement while the car is still GHOSTED -- and a ghosted vehicle has
  -- no collisions for a coupler to find, so attachCouplers did nothing at all.
  -- That is the whole reason the trailer still arrived loose and still had to
  -- be reconnected by hand.
  --
  -- This is the line that hands collisions back, so the window opens on the
  -- other side of it. Retried rather than fired once, because the ghost lift is
  -- itself a queued vehicle-side command and how long it takes to land is not
  -- something this side gets to know.
  if field.hadRig then
    field.coupleLeft = FIELD.COUPLE_FOR
    field.coupleNext = 0
  end
end

-- Queue a placement. A release and a grid slot that arrive on the same tick --
-- which is exactly what forming a grid sends to a driver who was spectating --
-- are ONE operation: put the car back, then stand it on its slot, under a single
-- ghost.
queueFieldPlacement = function (opts)
  local order = math.max(math.floor(tonumber(opts.order) or 1), 1)
  local count = math.max(math.floor(tonumber(opts.count) or order), order)
  local delay  = (order - 1) * FIELD.STAGGER
  local settle = (count - 1) * FIELD.STAGGER + FIELD.SETTLE

  -- Coalesce only while the operation has not placed the car yet. Once it has
  -- (step 'settle', which is just the wait for collisions to come back), a new
  -- request is a NEW placement and has to run from the start -- folding it into
  -- a settling operation would set a slot that nothing ever stands the car on.
  if field.active and field.step ~= 'settle' then
    field.respawn = field.respawn or (opts.respawn == true)
    if opts.slot then
      field.slot  = opts.slot
      field.slots = opts.slots
      field.hold  = opts.hold == true
      field.holdSource = opts.holdSource
    end
    if field.step == 'wait' then field.delay = math.max(field.delay, delay) end
    field.settle  = math.max(field.settle, settle)
    field.timeout = math.max(field.timeout, FIELD.TIMEOUT)
    return
  end

  field.active  = true
  field.step    = 'wait'
  field.delay   = delay
  field.grace   = 0
  field.settle  = settle
  field.timeout = FIELD.TIMEOUT
  field.respawn = opts.respawn == true
  field.slot    = opts.slot
  field.slots   = opts.slots
  field.hold    = opts.hold == true
  field.holdSource = opts.holdSource
  if setGhostReason then setGhostReason('placement', true) end
  -- WAS A TRAILER ON THE BACK? Asked here, before anything moves, because the
  -- placement is what detaches it -- by the time the car has landed there is
  -- nothing left to ask.
  --
  -- core_vehicles.attachedCouplers is the live list of coupled pairs, each
  -- { vehA, vehB, nodeA, nodeB }; a trailer shows up as a pair naming our id on
  -- either side. Behind pcall and a type test, because that is a GE extension
  -- that may not be loaded and a build that renames it should cost the trailer
  -- rather than the placement.
  field.hadRig = false
  do
    local rigVeh = ownVehicle()
    if rigVeh then
      local rigId = vehicleId(rigVeh)
      pcall(function ()
        if not (core_vehicles and type(core_vehicles.attachedCouplers) == 'table') then return end
        for _, pair in ipairs(core_vehicles.attachedCouplers) do
          if pair[1] == rigId or pair[2] == rigId then field.hadRig = true; return end
        end
      end)
    end
  end
  log('I', 'raceManager', string.format(
    'Field placement queued (order %d/%d, +%.2fs, respawn=%s, slot=%s)',
    order, count, delay, tostring(field.respawn), tostring(field.slot)))
end

local function fieldUpdate(dt)
  -- Runs whether or not a placement is in progress: the re-couple window opens
  -- as the operation ENDS, so a guard above it would stop the retry before it
  -- ever ran.
  if field.coupleLeft > 0 then
    field.coupleLeft = field.coupleLeft - dt
    field.coupleNext = field.coupleNext - dt
    if field.coupleNext <= 0 then
      field.coupleNext = FIELD.COUPLE_EVERY
      local rigVeh = ownVehicle()
      if rigVeh then
        -- Attaching an already-attached coupler does nothing, so repeating this
        -- costs a queued command and cannot double-couple anything.
        pcall(function () rigVeh:queueLuaCommand('beamstate.attachCouplers()') end)
      end
    end
    if field.coupleLeft <= 0 then
      field.hadRig = false
      log('I', 'raceManager', 'Trailer re-couple window closed')
    end
  end
  if not field.active then return end
  field.timeout = field.timeout - dt

  -- Timeout: whatever is stuck, the driver gets their car and their collisions
  -- back rather than being left ghosted for the rest of the session.
  if field.timeout <= 0 then
    if field.step ~= 'settle' then
      if field.respawn then respawnRemovedVehicle() end
      if field.slot then placeOnAssignedSlot() end
      bindCameraToOwnVehicle()
      log('W', 'raceManager', 'Field placement timed out: finishing it anyway')
    end
    endFieldOperation()
    pushRouteState()
    return
  end

  if field.step == 'wait' then
    field.delay = field.delay - dt
    if field.delay > 0 then return end
    field.step = 'spawn'
    return
  end

  if field.step == 'spawn' then
    if field.respawn then
      field.respawn = false
      if respawnRemovedVehicle() then
        -- BeamNG spawns asynchronously: the vehicle is not usable on this frame.
        field.grace = FIELD.SPAWN_GRACE
        field.step  = 'grace'
        return
      end
    end
    field.step = 'place'
    return
  end

  if field.step == 'grace' then
    field.grace = field.grace - dt
    if field.grace > 0 and not ownVehicle() then return end
    field.step = 'place'
    return
  end

  if field.step == 'place' then
    if field.slot then placeOnAssignedSlot() end
    -- Explicitly, every time. After a mass respawn the game picks a camera
    -- target on its own, and with a whole field appearing at once its pick is
    -- arbitrary - which is how everyone ended up watching the same car.
    bindCameraToOwnVehicle()
    field.step = 'settle'
    pushRouteState()
    return
  end

  -- 'settle': collisions come back once the whole field has landed.
  field.settle = field.settle - dt
  if field.settle > 0 then return end
  endFieldOperation()
  pushRouteState()
end

-- Run a queued placement to completion right now. For the paths that have no
-- more update ticks coming (the extension unloading, a BeamMP session ending):
-- a car left un-ghosted and unspawned there would stay that way.
local function flushFieldPlacement()
  if not field.active then return end
  if field.respawn then respawnRemovedVehicle() end
  if field.slot then placeOnAssignedSlot() end
  bindCameraToOwnVehicle()
  endFieldOperation()
end

-- Server assigned this client a grid slot: stand the car on it and hold it.
-- `order`/`count` place this driver in the field so the placement can be
-- staggered; they default to the slot number, which is the same thing whenever
-- the grid is complete.
local function applyGridSlot(slot, order, count)
  session.gridSlot = slot
  -- WHICH WAY ROUND THIS CAR IS GOING IS NOT SET HERE, and is not set anywhere.
  --
  -- The slot itself points the car, and every gate for the next checkpoint is
  -- armed for everybody, so a driver launched facing anti-clockwise reaches the
  -- anti-clockwise gate for CP 1 first and clears the checkpoint on it. Nothing
  -- has to be told which direction that was, which is the whole point: there is
  -- no lane to assign, so there is none to get wrong, spin out of, or lock.
  if not slot then
    -- Standing down (withdrawn, or not entered): nothing to place, and nothing
    -- should still be holding this car.
    releaseGridHold('race')
    pushRouteState()
    return
  end
  queueFieldPlacement({
    slot = slot, hold = true, order = order or slot, count = count,
  })
  pushRouteState()
end

-- ===========================================================================
-- Ghosting: qualifying, field placement, and reset
-- ===========================================================================
-- A ghosted car has no vehicle-to-vehicle collision. Three things want that,
-- and they overlap in time, so they are refcounted BY REASON and PER VEHICLE:
--
--   'quali'      -- rivals stop being obstacles during a flying lap
--   'placement'  -- a field being teleported onto a grid has to land through
--                   itself rather than pile up
--   'reset'      -- a driver who reset mid-race is intangible until the space
--                   around them is provably clear (the rest of this section)
--
-- Per vehicle, not one global flag: two drivers resetting a second apart are
-- two independent ghosts, and neither may end the other's.
--
-- HOW COLLISION IS ACTUALLY DROPPED. This used to probe MPVehicleGE for
-- setGhostMode/setGhosts/enableGhostMode, find none of them on any build, and
-- fall back to fading rival cars while leaving them solid -- so ghost
-- qualifying looked like it worked and never did. The toggle is not BeamMP's
-- at all: it is BeamNG's own `obj:setGhostEnabled(bool)`, a VEHICLE-side call
-- reached from here through queueLuaCommand, the same bridge the grid freeze
-- uses. It is per vehicle, it leaves world and terrain collision alone, and the
-- engine drives it itself for instability recovery (lua/ge/main.lua) -- BeamNG's
-- own multiplayer has `ghostOnReset`/`ghostOnTp` vehicle globals that do
-- precisely this feature.
--
-- Because it is per vehicle, every client must ghost the SAME car, which is
-- what the RM_Ghost broadcast is for. A vehicle id is meaningless across
-- clients (it is a local scene-object id), so the wire carries the BeamMP
-- player id -- which MPVehicleGE reports as `ownerID`, and which is the same
-- key the server files everyone under.

-- Walk vehicles. getAllVehicles() is the GE-side, allocation-free way to do it
-- and hands back vehicles only, where be:getObject(i) walks every scene object
-- and has to be filtered; the old loop stays as the fallback. `skipId` drops one
-- car from the walk -- usually ours, sometimes the one being tested.
local function forEachVehicle(skipId, fn)
  if type(getAllVehicles) == 'function' then
    local ok, list = pcall(getAllVehicles)
    if ok and type(list) == 'table' then
      for _, veh in ipairs(list) do
        if veh then
          -- The closure stays, for vehicleId's reason: the index has to happen
          -- inside the pcall or a car deleted mid-walk takes the walk with it.
          local gotId, id = pcall(function () return veh:getID() end)
          if gotId and id ~= skipId then fn(veh, id) end
        end
      end
      return
    end
  end
  if not be then return end
  local count = be:getObjectCount() or 0
  for i = 0, count - 1 do
    local veh = be:getObject(i)
    if veh then
      local ok, id = pcall(function () return veh:getID() end)
      if ok and id ~= skipId then fn(veh, id) end
    end
  end
end

-- Which local vehicle belongs to a given player id. This is the whole reason the
-- broadcast carries a pid: the answer is different on every client.
function ghost.vehicleForPid(pid)
  if pid == nil or not (MPVehicleGE and type(MPVehicleGE.getVehicles) == 'function') then
    return nil, nil
  end
  local ok, list = pcall(MPVehicleGE.getVehicles)
  if not ok or type(list) ~= 'table' then return nil, nil end
  for _, v in pairs(list) do
    if type(v) == 'table' and tostring(v.ownerID) == tostring(pid) and v.gameVehicleID then
      local got, obj = pcall(getObjectByID, v.gameVehicleID)
      if got and obj then return obj, v.gameVehicleID end
    end
  end
  return nil, nil
end

-- Set one car's mesh alpha, and only when it has actually moved. The fade runs
-- every frame for a second, and setMeshAlpha is a call across into the engine
-- per car -- with eleven cars on track, re-sending a value that has not changed
-- is the difference between a fade that is free and one that is measurable.
function ghost.fade(vehId, veh, alpha)
  if not veh then return end
  local was = ghost.alpha[vehId]
  if was and math.abs(was - alpha) < 0.01 then return end
  ghost.alpha[vehId] = alpha
  -- Closure, for vehicleId's reason: the method lookup has to be inside the
  -- pcall, or a car deleted between the fade starting and this frame throws.
  pcall(function () veh:setMeshAlpha(alpha, '', false) end)
end

-- Apply (or lift) the ghost on one car: the collision toggle, then the fade that
-- makes it visible. Both are pcall'd -- a vehicle that has just been deleted
-- must not take the update loop down with it.
--
-- Called on TRANSITIONS only. queueLuaCommand marshals a string into the
-- vehicle's own Lua VM, which is not something to do sixty times a second per
-- car for a value that changes twice per ghost; the per-frame fade goes through
-- ghost.fade above and never touches collision.
function ghost.apply(vehId, veh, on, alpha)
  if not veh then return end
  pcall(function ()
    veh:queueLuaCommand('obj:setGhostEnabled(' .. (on and 'true' or 'false') .. ')')
  end)
  ghost.fade(vehId, veh, on and (alpha or TUNE.GHOST_ALPHA) or 1)
  ghost.applied[vehId] = on or nil
end

-- Add or drop one reason on one vehicle, and make the car match.
--
-- `veh` is the vehicle object when the caller already has it -- which the field
-- sweep does, holding it from the walk it is in the middle of. Looking it up
-- again by id would be a scene lookup per car per sweep for a value already in
-- hand, and with eleven cars on a two-second sweep that adds up for nothing.
-- A REASON, APPLIED TO A WHOLE RIG.
--
-- The reset ghost is the mirror image of the field reasons. Those mean "rivals
-- are ghosts", so our own rig is skipped. This one means "THIS CAR is a ghost",
-- and a trailer on its hitch has to be intangible with it -- half a rig passing
-- through a rival while the other half hits them is worse than no ghost at all,
-- because the driver has been told they are clear.
--
-- The trailer gets no countdown of its own. It carries the same named reason as
-- the car, so it goes solid on exactly the same tick the car does rather than
-- on a second timer that could drift.
function ghost.reasonRig(vehId, reason, on, veh)
  ghost.reason(vehId, reason, on, veh)
  for id in pairs(ghost.rigMates(vehId)) do
    ghost.reason(id, reason, on, nil)
  end
end

function ghost.reason(vehId, reason, on, veh)
  if vehId == nil then return end
  local set = ghost.veh[vehId]
  if on then
    set = set or {}
    set[reason] = true
    ghost.veh[vehId] = set
  elseif set then
    set[reason] = nil
    if next(set) == nil then ghost.veh[vehId] = nil end
  end
  local want = ghost.veh[vehId] ~= nil
  if want then ghost.pending[vehId] = nil end
  if want == (ghost.applied[vehId] == true) then return end
  if not veh then
    local got, found = pcall(getObjectByID, vehId)
    veh = got and found or nil
  end
  -- THE gate every ghost passes through on its way back to solid, and the only
  -- one: no car is handed its collisions back while another car is inside it.
  --
  -- Every reason funnels through here -- the driver's own reset ghost, the pit
  -- stop, and the field-wide ones that ghost rivals during a mass respawn or
  -- qualifying -- so the rule holds for all of them without each having to
  -- remember it. The reason itself is already gone from the set above; what is
  -- deferred is only the moment the car stops being intangible.
  --
  -- A car that cannot go solid yet is parked in `pending` and retried by the
  -- update loop. It cannot get stuck: the cars involved are ghosts, which is
  -- precisely what lets them drive out of each other.
  if not want and veh and ghost.wouldWeld(vehId, veh) then
    ghost.pending[vehId] = true
    return
  end
  ghost.pending[vehId] = nil
  ghost.apply(vehId, veh, want, ghost.alphaFor(vehId))
end

-- Is another car inside this one? Ghost status is deliberately not consulted:
-- see the note in ghost.occupied for why an intangible car in the same space is
-- still a car in the same space.
--
-- Used for cars this client does not own, where there is no countdown and no
-- driver to warn -- just "not yet". ghost.occupied does the same job for our own
-- car and additionally explains itself, because that one has a driver waiting.
function ghost.wouldWeld(vehId, veh)
  local c1, x1, y1, z1 = ghost.bounds(veh, TUNE.GHOST_OVERLAP_MARGIN)
  local mine = ghost.center(veh)
  -- A car the engine will not place at all is no evidence that anything is
  -- inside it, so it does not block. That asymmetry with ghost.occupied is
  -- deliberate: there, the car that cannot be located is OUR OWN and a driver
  -- is waiting on the answer, so the conservative reading is the safe one and a
  -- retry next frame will resolve it. Here the subject is somebody else's car,
  -- usually one mid-spawn or mid-delete, and "stay a ghost until we can measure
  -- you" is how a car ends up intangible for a whole race with nothing able to
  -- undo it -- which is the failure this file has already been through once.
  if not c1 and not mine then return false end
  local weld = false
  -- OUR OWN RIG IS NOT A WELD HAZARD, the same as in ghost.occupied. A coupled
  -- trailer is inside this box permanently and by design -- it is bolted on --
  -- so counting it means waiting for something that can never happen, and the
  -- car and its trailer stay ghosted for the rest of the session.
  --
  -- BOTH checks need this and only one of them having it is what the first
  -- attempt got wrong: occupied governs OUR countdown, wouldWeld governs
  -- whether a restore is deferred at all, and a rig blocked here never even
  -- reached the countdown.
  local mates = ghost.rigMates(vehId)
  forEachVehicle(vehId, function (other, otherId)
    if weld then return end
    if mates[otherId] then return end
    local c2, x2, y2, z2 = ghost.bounds(other, 0)
    if c1 and c2 and type(overlapsOBB_OBB) == 'function' then
      local okHit, hit = pcall(overlapsOBB_OBB, c1, x1, y1, z1, c2, x2, y2, z2)
      if not okHit or hit then weld = true end
      return
    end
    local theirs = ghost.center(other)
    if not (mine and theirs) then return end
    local dx, dy, dz = mine.x - theirs.x, mine.y - theirs.y, mine.z - theirs.z
    if (dx * dx + dy * dy + dz * dz)
        <= (TUNE.GHOST_FALLBACK_RADIUS * TUNE.GHOST_FALLBACK_RADIUS) then
      weld = true
    end
  end)
  return weld
end

-- Alpha for a car mid-ghost. Translucent for most of the ghost, then fading
-- back to solid over the last second -- the warning that contact is about to
-- resume. The occupancy block deliberately does NOT fade: a car that is stuck
-- inside another stays visibly a ghost for as long as that lasts.
function ghost.alphaFor(vehId)
  -- OUR OWN FINISHED CAR IS NEVER FADED, and this is the one place that is
  -- decided, so every path into apply() gets it right: the transition, the
  -- refresh sweep and the per-frame fade all read alpha from here.
  --
  -- A driver who takes the flag keeps seeing their own car exactly as it was.
  -- Its COLLISION is off -- see ghost.setFinished for why that has to include
  -- our own client -- but collision and alpha are separate calls, and only one
  -- of them is any of the driver's business.
  if vehId ~= nil and vehId == ghost.finishedOwn then return 1 end
  local left = ghost.left[vehId]
  local fade = TUNE.GHOST_FADE_OUT_SEC
  if not left or fade <= 0 or left >= fade then return TUNE.GHOST_ALPHA end
  if left <= 0 then return TUNE.GHOST_ALPHA end
  local t = 1 - (left / fade)          -- 0 at fade start, 1 at contact
  return TUNE.GHOST_ALPHA + (1 - TUNE.GHOST_ALPHA) * t
end

-- The oriented bounding box of a car, as the four vectors overlapsOBB_OBB wants,
-- with `margin` meters added to every half-extent.
--
-- getSpawnWorldOOBB is the box BeamNG's own spawn-occupancy test uses
-- (lua/ge/spawn.lua). It is an ORIENTED box: a car lying crossways through
-- another is caught, where a distance between origins reports it as clear.
function ghost.bounds(veh, margin)
  if not veh then return nil end
  -- Preferred: the ORIENTED box. A car lying crossways through another is
  -- caught by it, where an axis-aligned box or a radius would report clear.
  local ok, c, x, y, z = pcall(function ()
    local bb = veh:getSpawnWorldOOBB()
    if not bb then return nil end
    local he = bb:getHalfExtents()
    return bb:getCenter(),
      bb:getAxis(0) * (he.x + margin),
      bb:getAxis(1) * (he.y + margin),
      bb:getAxis(2) * (he.z + margin)
  end)
  if ok and c then return c, x, y, z end
  -- Fallback: the axis-aligned world box, which is what BeamNG's own spawn
  -- occupancy test uses for vehicles that already exist (lua/ge/spawn.lua).
  -- getSpawnWorldOOBB can return nil -- shipping code nil-guards it -- and a
  -- single nil used to mean "assume occupied", which is how one unmeasurable
  -- car anywhere on the map left a driver ghosted for the rest of the race.
  ok, c, x, y, z = pcall(function ()
    local bb = veh:getWorldBox()
    if not bb then return nil end
    local he = bb:getExtents()
    return bb:getCenter(),
      vec3(he.x * 0.5 + margin, 0, 0),
      vec3(0, he.y * 0.5 + margin, 0),
      vec3(0, 0, he.z * 0.5 + margin)
  end)
  if ok and c then return c, x, y, z end
  -- Last measurement: the car's own dimensions, oriented by where it is facing.
  -- Every vehicle knows how big it is even when neither bounding box will say
  -- where it is, and these are physics-side calls that answer for another
  -- player's car as readily as for ours.
  --
  -- This tier matters more than a third fallback usually would. Below it there
  -- is only a flat radius, and a radius wide enough to contain the largest
  -- vehicle pair is several times wider than a car -- in a full field somebody
  -- is nearly always inside it, so a ghost that reached that fallback would stay
  -- up for most of the race. Measuring the actual car keeps the answer the size
  -- of a car.
  ok, c, x, y, z = pcall(function ()
    local p = veh:getPosition()
    local dir = veh:getDirectionVector()
    local up = veh:getDirectionVectorUp()
    local len = veh:getInitialLength() * 0.5
    local wid = veh:getInitialWidth() * 0.5
    local hgt = veh:getInitialHeight() * 0.5
    if not (p and dir and up and len and wid and hgt) then return nil end
    local fwd   = vec3(dir.x, dir.y, dir.z)
    local upv   = vec3(up.x, up.y, up.z)
    local right = fwd:cross(upv)
    return vec3(p.x, p.y, p.z) + upv * hgt,
      right * (wid + margin),
      fwd * (len + margin),
      upv * (hgt + margin)
  end)
  if ok and c then return c, x, y, z end
  return nil
end

-- Where a car is, when nothing will say how big it is. Used only by the
-- last-resort distance test below.
function ghost.center(veh)
  if not veh then return nil end
  local ok, p = pcall(function () return veh:getPosition() end)
  if not ok or not p then return nil end
  return p
end

-- Is anything solid sharing this car's space?
--
-- THE HARD INVARIANT LIVES HERE. Restoring collision on two overlapping cars
-- welds their node structures together, which ends both races and cannot be
-- undone -- so this answers "am I certain it is clear", not "do I think it is".
-- Every way of failing to know (no bounding box, no vehicle list, an engine call
-- that threw) returns BLOCKED. A ghost that lasts too long is a nuisance; a
-- ghost lifted one frame too early is two ruined races.
--
-- Cars that are THEMSELVES ghosts are skipped, and that is load-bearing rather
-- than an optimisation: a ghost cannot weld to anything, so it is not a hazard,
-- and counting it as one would deadlock two overlapping ghosts against each
-- other forever -- which is exactly the three-cars-stacked case.
-- EVERY VEHICLE COUPLED TO THIS ONE, directly or down a chain of them.
--
-- A trailer is a separate vehicle as far as BeamNG and this mod are concerned,
-- and that is the whole source of the trouble: without this, your own trailer
-- counts as a rival. It gets ghosted as one, and it permanently occupies your
-- space so neither of you can ever go solid again -- "too close to another
-- vehicle", about a vehicle bolted to your tow hitch.
--
-- Transitive, because a rig can be a chain: car -> dolly -> trailer. Anything
-- reachable through couplings is part of the same rig and none of it is a
-- hazard to the rest -- they are already physically joined, which is what a
-- coupler IS.
--
-- Behind pcall and a type test like every other read of this list: core_vehicles
-- is a GE extension that may not be loaded, and a build that renames it should
-- cost trailer support rather than ghosting.
function ghost.rigMates(vehId)
  local mates = {}
  if not vehId then return mates end
  pcall(function ()
    if not (core_vehicles and type(core_vehicles.attachedCouplers) == 'table') then return end
    local seen = { [vehId] = true }
    local grew = true
    while grew do
      grew = false
      for _, pair in ipairs(core_vehicles.attachedCouplers) do
        local a, b = pair[1], pair[2]
        if seen[a] and b and not seen[b] then seen[b] = true; mates[b] = true; grew = true end
        if seen[b] and a and not seen[a] then seen[a] = true; mates[a] = true; grew = true end
      end
    end
  end)
  return mates
end

function ghost.occupied(vehId, veh)
  local c1, x1, y1, z1 = ghost.bounds(veh, TUNE.GHOST_OVERLAP_MARGIN)
  local mine = ghost.center(veh)
  -- Nothing to measure ourselves against and nowhere to stand: we genuinely
  -- know nothing, so we stay ghosted. This is the only remaining way to be
  -- blocked without another car being involved, and a car with no position at
  -- all is a car that is being deleted -- which the teardown paths handle.
  if not c1 and not mine then
    ghost.blockReason = 'this car cannot be located'
    return true
  end

  local blocked, sawAny, reason = false, false, nil
  -- Our own rig is not somebody else's car. A coupled trailer sits inside this
  -- box permanently and by design, so counting it would mean waiting for it to
  -- drive away -- which it cannot do, because it is attached.
  local mates = ghost.rigMates(vehId)
  forEachVehicle(vehId, function (other, otherId)
    if blocked then return end
    if mates[otherId] then return end
    -- A car inside this one blocks the restore whether or not it is ITSELF a
    -- ghost right now.
    --
    -- This used to skip ghosts, on the reasoning that a ghost cannot weld: an
    -- intangible car inside ours cannot hit us, so why wait for it. The flaw is
    -- that the other car's ghost is not ours to rely on -- it ends on its own
    -- clock, decided by its own client, and the instant it does there are two
    -- solid bodies in the same space. It also made the rule unusable in the one
    -- place it is needed most: after a race everybody is respawned at once, so
    -- every car is a ghost, so every car looked clear to every other one.
    --
    -- The rule is now simply that a car does not become solid while another car
    -- is inside it, for any ghosted condition. Two ghosts overlapping can always
    -- separate -- being ghosts is exactly what lets them drive apart -- so
    -- waiting for that cannot deadlock.
    sawAny = true
    local c2, x2, y2, z2 = ghost.bounds(other, 0)
    -- The precise test, when both cars can be measured. The margin is on OUR
    -- box only; inflating both would demand double the configured clearance.
    if c1 and c2 and type(overlapsOBB_OBB) == 'function' then
      local okHit, hit = pcall(overlapsOBB_OBB, c1, x1, y1, z1, c2, x2, y2, z2)
      if not okHit then
        reason = 'overlap test failed'
        blocked = true
      elseif hit then
        reason = 'another car is in this space'
        blocked = true
      end
      return
    end
    -- One of the two cannot be measured. That is NOT the same as being inside
    -- it: a car we cannot size up but which is fifty meters away is plainly not
    -- overlapping anything. Treating every measurement failure as an overlap is
    -- what left drivers ghosted for a whole race, because it could never
    -- resolve -- so the fallback is a real (if blunt) test rather than a
    -- verdict. The radius comfortably contains the largest vehicle pair.
    local theirs = ghost.center(other)
    if not (mine and theirs) then
      reason = 'a nearby car cannot be located'
      blocked = true
      return
    end
    local dx, dy, dz = mine.x - theirs.x, mine.y - theirs.y, mine.z - theirs.z
    if (dx * dx + dy * dy + dz * dz)
        <= (TUNE.GHOST_FALLBACK_RADIUS * TUNE.GHOST_FALLBACK_RADIUS) then
      reason = 'a car that cannot be measured is close by'
      blocked = true
    end
  end)
  -- Nothing else on track at all is a clear frame, not an unknown one.
  if not sawAny then
    ghost.blockReason = nil
    return false
  end
  ghost.blockReason = blocked and reason or nil
  return blocked
end

-- Fills the forward declaration made beside the grid hold at the top of the
-- file. These two reasons are field-wide: they ghost every car this client can
-- see other than its own, which is what "rivals are ghosts" means locally.
setGhostReason = function (reason, on)
  -- Turning a reason ON skips our own car: these reasons mean "rivals are
  -- ghosts", and ghosting ourselves is the opposite. ownVehicle() and not
  -- playerVehicle(): once our car is deleted the game attaches us to somebody
  -- else's, and "the car I am attached to" would then exclude a RIVAL. With no
  -- car of our own the answer is nil and everything is ghosted, which is right
  -- for a mass respawn.
  --
  -- Turning a reason OFF skips NOTHING, and that asymmetry is the point. The ON
  -- path can reach our own car whenever ownVehicle() cannot name it, which is
  -- exactly the window a respawn opens. If the OFF path then skipped it because
  -- ownership HAS resolved, the reason would stay on forever with nothing able
  -- to clear it: a car that flashes solid as its reset ghost expires and goes
  -- straight back to being a ghost for the rest of the race. Clearing a reason a
  -- car never had is free.
  local skipId, skipRig = nil, nil
  if on then
    local mine = ownVehicle()
    skipId = mine and vehicleId(mine) or nil
    -- ...AND ANYTHING COUPLED TO IT. These reasons mean "rivals are ghosts", and
    -- a trailer on your own tow hitch is not a rival. Skipping only the car left
    -- the trailer ghosted for the whole race while the car it was bolted to was
    -- solid.
    skipRig = skipId and ghost.rigMates(skipId) or nil
  end
  forEachVehicle(skipId, function (veh, id)
    if skipRig and skipRig[id] then return end
    ghost.reason(id, reason, on, veh)
  end)
  if on then ghost.field[reason] = true else ghost.field[reason] = nil end
end

local function clearGhostReasons()
  ghost.field = {}
  ghost.remote = {}
  ghost.pending = {}
  ghost.left = {}
  ghost.blockReason = nil
  ghost.own = { settling = false, left = 0, total = 0, blocked = 0, warned = false }
  ghost.veh = {}
  ghost.finishedOwn = nil
  ghost.finishedRemote = {}
  -- Swept over EVERY car in the world, not just the ones this client believes
  -- it ghosted. A session ending has to leave nothing ghosted whatever the
  -- bookkeeping thinks -- an entry lost to a vehicle id being reused, or a ghost
  -- applied by an instance of this extension that has since been reloaded, would
  -- otherwise leave a car intangible with nothing left that could ever undo it.
  -- This runs once per session end, so walking the field costs nothing.
  ghost.applied = {}
  ghost.alpha = {}
  ghost.remoteVeh = {}
  forEachVehicle(nil, function (veh, id) ghost.apply(id, veh, false) end)
  ghost.applied = {}
  ghost.alpha = {}
  ghost.pending = {}
end

-- Arm this client's own reset ghost. Called straight from the reset hook and
-- applied LOCALLY on the spot -- no round trip -- because the dangerous frame is
-- this one, not the one the server's acknowledgement arrives on. The broadcast
-- follows so everyone else ghosts the same car.
--
-- A repeat reset while already ghosted RESTARTS the timer. It does not stack.
--
-- It used to say exactly that and do the opposite: each reset added minSec to
-- the PREVIOUS TOTAL, capped at maxSec, so a driver resetting twice in traffic
-- climbed 5s, 10s, 15s and stayed intangible far longer than the rule allows.
-- The cap made it bounded, not correct.
--
-- Restarting is also the safer of the two. The reason a ghost exists is the
-- moment of materialising in the pack; a second reset is a second such moment,
-- not a longer one. Anyone genuinely stuck inside another car is covered by the
-- occupancy check, which has no time limit in either direction and is what
-- actually decides when collision comes back.
function ghost.arm()
  local veh = ownVehicle()
  local vehId = veh and vehicleId(veh) or nil
  if not vehId then return end
  local rules = ghost.rules
  local base = rules.minSec
  ghost.own.pid      = localServerId()
  ghost.own.vehId    = vehId
  ghost.own.total    = base
  ghost.own.left     = base
  ghost.own.blocked  = 0
  ghost.own.warned   = false
  -- The timer must not start on a car that is still being put down. It starts
  -- once the vehicle reports a usable bounding box, which is also the first
  -- moment the occupancy check could mean anything.
  ghost.own.settling   = true
  ghost.own.settleLeft = TUNE.GHOST_SETTLE_MAX
  ghost.left[vehId]  = base
  ghost.reasonRig(vehId, 'reset', true)
  -- Holding the reset key fires the vehicle-reset hook over and over -- the same
  -- reason the blocked-reset notice further up is throttled. The ghost itself is
  -- re-armed every time (it is local, and free), but the SERVER is not told
  -- every time: only when the duration actually changes, which it stops doing
  -- once the repeat extension hits its cap, plus a floor of half a second so a
  -- held key cannot turn into a message per frame either way.
  local changed = base ~= ghost.own.sentBase
  local stale   = (localTime - (ghost.own.sentAt or -math.huge)) >= 0.5
  if inMultiplayer() and (changed or stale) then
    ghost.own.sentBase = base
    ghost.own.sentAt   = localTime
    TriggerServerEvent('RM_GhostStart', jsonEncode({ duration = base }))
  end
  log('I', 'raceManager', string.format(
    'Reset ghost armed on vehicle %s for %.1fs', tostring(vehId), base))
end

-- Lift our own ghost and tell the server, so every other client drops it too.
--
-- `why` is 'clear' when the occupancy check passed -- the only route that
-- restores collision to a car still on track, and the only one the driver is
-- told about. Every other caller is a teardown (the session ended, the driver
-- was stood down, the car was deleted) where there is no longer a race to be
-- careful about, and announcing "contact restored" would be noise.
function ghost.release(why)
  local vehId = ghost.own.vehId
  if vehId then
    ghost.left[vehId] = nil
    ghost.reasonRig(vehId, 'reset', false)
  end
  ghost.own.vehId    = nil
  ghost.own.settling = false
  ghost.own.left     = 0
  ghost.own.total    = 0
  ghost.own.blocked  = 0
  ghost.own.warned   = false
  -- Forget what was last reported, so the NEXT ghost reports its duration even
  -- though it opens with the same number this one did.
  ghost.own.sentBase = nil
  ghost.own.sentAt   = nil
  if inMultiplayer() then TriggerServerEvent('RM_GhostEnd', '') end
  if why == 'clear' then pushNotice('ghost', 'Contact restored') end
  log('I', 'raceManager', 'Reset ghost released on vehicle ' .. tostring(vehId)
    .. ' (' .. tostring(why or 'clear') .. ')')
end

-- Someone else's ghost. `endsAt` is on the SERVER clock, so what gets applied
-- here is whatever is left of it by our reckoning of that clock -- a client
-- 250 ms behind ghosts the car for 250 ms less, never 250 ms more.
--
-- Only an `endsAt` of nil clears the ghost, and an elapsed one does NOT. The
-- server sends nil when the owning client has reported the space around its car
-- clear; until then the ghost stands however long ago its timer nominally ran
-- out, because the owner may be sitting inside somebody and still intangible.
-- Un-ghosting a car here on our own clock would make it solid in OUR physics
-- world while it was still a ghost in its owner's -- and a solid car overlapping
-- another solid car on this client welds the pair on this client. The elapsed
-- time is allowed to drive the fade and nothing else.
function ghost.applyRemote(pid, endsAt)
  if pid == nil then return end
  ghost.remote[pid] = endsAt
  local veh, vehId = ghost.vehicleForPid(pid)
  -- Cache which local car this player owns. Resolving it means asking BeamMP for
  -- its whole vehicle map, which builds a table -- fine here (an event, or the
  -- two-second sweep), not fine on the per-frame fade below, which is why that
  -- reads the cache instead.
  ghost.remoteVeh[pid] = vehId
  -- The car is not in this client's world yet (a join mid-ghost, or a vehicle
  -- still spawning). The intent is remembered above and the refresh sweep
  -- applies it as soon as the car appears.
  if not vehId then return end
  if endsAt ~= nil then
    local left = endsAt - ghost.serverTime
    ghost.left[vehId] = left > 0 and left or nil
    -- Their trailer as well. Coupling is simulated on every client, so this
    -- side can see what is on their hitch without the server saying so -- which
    -- matters, because the ghost broadcast carries a PLAYER id and a player has
    -- one car as far as the server is concerned.
    ghost.reasonRig(vehId, 'reset', true)
    ghost.apply(vehId, veh, true, ghost.alphaFor(vehId))
  else
    ghost.left[vehId] = nil
    -- THE RIG AGAIN, and it has to be the same reach as the line above. Applied
    -- to the whole rig and lifted from the car alone, the trailer keeps a reason
    -- nothing will ever clear: it stays intangible for the rest of the session
    -- on every client except its owner's, who sees it solid. Cars drive through
    -- it, and no sweep or roster undoes it -- `reset` is only ever cleared here
    -- and in the owner's own restore, which is rig-wide already.
    --
    -- The two halves being different functions is what let them drift apart, so
    -- they are named the same way now: whatever a ghost is applied to is what it
    -- comes off.
    ghost.reasonRig(vehId, 'reset', false)
  end
end

-- ---------------------------------------------------------------------------
-- The FINISHED ghost: a driver who has taken the flag, still in their own car
-- ---------------------------------------------------------------------------
-- Taking the flag used to DELETE the car and respawn it at the end of the race.
-- That is two entity events per driver at the exact moment a field is finishing
-- together, plus the network churn of a despawn and a spawn, and it landed
-- hardest on the machines least able to absorb it. Nothing is created or
-- destroyed now: the car stays where it is and changes state.
--
-- THIS REASON IS APPLIED TO OUR OWN CAR TOO, which is what makes it different
-- from every other reason in this file. The field-wide ones mean "rivals are
-- ghosts" and deliberately skip our own; this one means "I am out of the race",
-- and in BeamMP our car is simulated HERE. Leaving it collidable locally would
-- let our own sim bounce us off a racer whose sim felt nothing -- and since our
-- position is what gets synced, that phantom shove would travel to everyone.
-- The race outcome is only provably unaffected if the collision is off on the
-- finisher's own client as well.
--
-- What the driver keeps is the LOOK of their car: alpha stays 1 for them and
-- drops to GHOST_ALPHA for everybody else. ghost.alphaFor is where that is
-- decided, off `finishedOwn`, so no call site has to remember it.
--
-- GHOST-TO-GHOST IS PASS-THROUGH, deliberately. Because setGhostEnabled is per
-- vehicle and every finished car carries this reason on every client, finished
-- drivers already drive through each other and it would be work to stop them.
-- It is also what we want: spectating drivers cannot shunt each other into the
-- racing line.
--
-- World and terrain collision are untouched by setGhostEnabled, so a ghosted
-- car still sits on the map rather than falling through it.
--
-- FINISHING MID-CONTACT CANNOT TELEPORT ANYONE. Nothing on this path writes a
-- position: it is setGhostEnabled plus a mesh alpha, and that is all. A racer
-- who was leaning on the finisher at the moment they crossed simply stops having
-- something to lean on, and their soft body rebounds to its own shape exactly as
-- it would if the other car had driven away. Removing a constraint cannot inject
-- energy; it is the other direction that is dangerous, which is why ghost.reason
-- puts the wouldWeld gate on the way BACK to solid and not on the way here.
function ghost.setFinished(on)
  local veh = ownVehicle()
  local vehId = veh and vehicleId(veh) or nil
  if on then
    if not vehId then return end
    ghost.finishedOwn = vehId
    -- RE-ASSERTED, not just recorded. ghost.reason returns early when what it
    -- wants already matches what it believes it applied -- which is right for
    -- every other caller and wrong here, because the two ways back into this
    -- function are a reset and a respawn, and both of them reload the vehicle's
    -- Lua VM. setGhostEnabled lives in that VM, so the car comes back SOLID with
    -- the bookkeeping still saying "ghosted". Dropping the applied flag first
    -- makes the reason path re-issue the command; the engine call is idempotent,
    -- so a redundant one costs nothing.
    ghost.applied[vehId] = nil
    ghost.reason(vehId, 'finished', true, veh)
  else
    -- Cleared off the RECORDED id, not off ownVehicle(): by the time a race
    -- ends the driver may be sitting in a different car (they reset, or
    -- respawned while spectating), and the one that must be handed its
    -- collisions back is the one that was ghosted.
    local id = ghost.finishedOwn
    ghost.finishedOwn = nil
    if id then
      local got, found = pcall(getObjectByID, id)
      ghost.reason(id, 'finished', false, got and found or nil)
    end
    if vehId and vehId ~= id then ghost.reason(vehId, 'finished', false, veh) end
  end
end

-- Everyone else's finished cars, from the authoritative list on the state
-- broadcast. A list rather than an event for the same reason the reset roster is
-- one: a client that missed the moment (joined late, dropped a packet) still
-- converges, because a pid absent from the list has no ghost.
function ghost.applyFinishedRoster(list)
  local mine = localServerId()
  local seen = {}
  for _, pid in ipairs(list or {}) do
    if pid ~= nil and tostring(pid) ~= tostring(mine) then
      seen[tostring(pid)] = true
      local veh, vehId = ghost.vehicleForPid(pid)
      ghost.remoteVeh[pid] = vehId
      if vehId and not (ghost.finishedRemote[tostring(pid)]) then
        ghost.reason(vehId, 'finished', true, veh)
      end
      ghost.finishedRemote[tostring(pid)] = vehId or true
    end
  end
  -- Anyone no longer in the list is racing again (or has left), so the reason
  -- comes off. Walking what we applied rather than the roster is what makes a
  -- disconnect safe: the pid vanishes from the list and this is what notices.
  for pid, vehId in pairs(ghost.finishedRemote) do
    if not seen[pid] then
      ghost.finishedRemote[pid] = nil
      if type(vehId) == 'number' then
        local got, found = pcall(getObjectByID, vehId)
        ghost.reason(vehId, 'finished', false, got and found or nil)
      end
    end
  end
end

-- The server's whole ghost roster, off the state broadcast:
-- { { pid = ..., endsAt = ... }, ... }, end times on the server clock.
-- Authoritative, so a pid that is NOT in it has no ghost -- which is how a
-- client that missed an RM_Ghost clear (or was not connected for it) stops
-- showing a car as a ghost forever.
--
-- Our own row is skipped. Only this client can know whether the space around our
-- car is clear, so our own ghost is ours to end; the server's copy of it is for
-- everyone else's benefit.
function ghost.applyRoster(list)
  local mine = localServerId()
  local seen = {}
  for _, row in ipairs(list) do
    local pid = row and row.pid
    if pid ~= nil and tostring(pid) ~= tostring(mine) then
      seen[pid] = true
      ghost.applyRemote(pid, tonumber(row.endsAt))
    end
  end
  for pid in pairs(ghost.remote) do
    if not seen[pid] then ghost.applyRemote(pid, nil) end
  end
end

-- The driver's own countdown, and the "you are stuck" warning. Its own guihook
-- channel rather than the notice channel: a countdown moves continuously and the
-- notice channel is for things that are said once.
--
-- Throttled to ~10 Hz, and silent entirely when there is no ghost. A guihook per
-- frame is a message per frame to the UI for a readout a driver cannot read that
-- fast, and this feature is meant to cost nothing with a full grid on track. The
-- UI interpolates between pushes, exactly as it does for the lap clock.
function ghost.pushHud(dt)
  local active = ghost.own.vehId ~= nil
  if not active and not ghost.hudShown then return end
  ghost.hudLeft = ghost.hudLeft - dt
  if active and ghost.hudShown and ghost.hudLeft > 0 then return end
  ghost.hudLeft  = 0.1
  ghost.hudShown = active
  guihooks.trigger('RaceManagerGhost', {
    active  = active,
    left    = ghost.own.left,
    total   = ghost.own.total,
    blocked = ghost.own.blocked > 0,
    warn    = ghost.own.blocked >= TUNE.GHOST_OVERLAP_WARN_SEC,
  })
end

-- One update for all three ghost reasons, in the order they can affect each
-- other: the qualifying rule (armed by the phase, dropped the moment the session
-- changes, so nobody races ghosts), then this client's own reset ghost and the
-- occupancy check that ends it, then everyone else's ghosts and the fade. The
-- sweep at the end re-asserts whatever is wanted onto cars that have appeared
-- since -- a rival who joined or respawned mid-session is ghosted too, rather
-- than showing up solid.
local function ghostUpdate(dt)
  -- Only on a CHANGE. setGhostReason walks every vehicle on track, and calling
  -- it unconditionally would rebuild the vehicle list once a frame to tell it
  -- the same thing it was told last frame. The sweep at the bottom of this
  -- function is what catches cars that appeared since.
  local wantQuali = ghostQuali and session.phase == 'qualifying' and not session.spectatorLock
  if wantQuali ~= (ghost.field.quali == true) then
    setGhostReason('quali', wantQuali)
  end

  -- --- connected in the middle of somebody else's session -----------------
  -- The server refuses to enter a mid-session arrival (see RM_onPlayerJoin) and
  -- flags them instead. A driver who turns up halfway through a race has a car,
  -- a spawn point and no idea a race is running; without this they can put a
  -- leader into a wall before they have finished reading the chat line telling
  -- them not to.
  --
  -- An untimed reason rather than the timed ghost roster, which exists for reset
  -- ghosting and caps out at fifteen seconds. This one lasts exactly as long as
  -- the flag does, and the flag is cleared when the next grid forms.
  if isBystander ~= (ghost.field.bystander == true) then
    setGhostReason('bystander', isBystander)
    if isBystander then
      -- THREE WAYS TO BECOME ONE, and they need different words. A mid-session
      -- arrival is a ghost because a race is running; somebody who pressed
      -- Spectate is a ghost because they asked to sit out, and telling them a
      -- session is running when the panel says WAITING and they just logged in
      -- alone is how a working feature reads as a broken one.
      --
      -- The third is a HEAT NIGHT, and it is the one that most needs saying: the
      -- driver did not ask for this, has not finished anything, and is about to
      -- spend a whole heat wondering whether the mod has broken. Tested FIRST
      -- because a driver waiting out a heat is not spectating and did not join
      -- late, so both of the other two would be a lie.
      local why
      if session.myHeat and session.heatCurrent > 0
         and session.myHeat ~= session.heatCurrent then
        why = 'Heat ' .. session.heatCurrent .. ' is running and you are in heat '
          .. session.myHeat .. '. Drive where you like: your car is a ghost, so '
          .. 'you cannot touch the race or be touched by it.'
      elseif selfSpectating then
        why = 'You are spectating: your car is a ghost, so nobody can hit it.'
      else
        why = 'A session is already running: you are a ghost until it ends'
      end
      pushNotice('spectate', why)
    end
  end

  -- --- this client's own reset ghost -------------------------------------
  local own = ghost.own
  -- Ends the moment the race does. Taking the flag, being stood down, the
  -- session finishing and a return to the lobby all land here, and none of them
  -- leaves a car to be careful around: the field is about to be respawned or
  -- removed wholesale, and the placement ghost covers that.
  if own.vehId and not ((session.phase == 'racing' or session.phase == 'qualifying') and not session.spectatorLock) then
    ghost.release('session ended')
  end
  if own.vehId then
    local got, veh = pcall(getObjectByID, own.vehId)
    veh = got and veh or nil
    if not veh then
      -- The car is gone (deleted, or the driver was stood down). Nothing to
      -- un-ghost, and nothing to keep counting.
      ghost.release('vehicle gone')
    else
      if own.settling then
        -- "Placed and settled": the first frame the car reports a usable box --
        -- or, failing that, a short fixed wait. Waiting on the box ALONE is
        -- another way to be ghosted forever: a car that never reports one would
        -- never start its timer, so the ghost would have nothing to count down
        -- and no way to end. The occupancy check is what actually guards the
        -- restore, and it copes with an unmeasurable car on its own.
        own.settleLeft = own.settleLeft - dt
        if ghost.bounds(veh, 0) or own.settleLeft <= 0 then own.settling = false end
      else
        if own.left > 0 then
          own.left = math.max(own.left - dt, 0)
          ghost.left[own.vehId] = own.left
          -- Drive the fade while it is running. Alpha only: the car is already
          -- ghosted and re-sending that every frame would be a vehicle-VM
          -- command per frame for no change.
          ghost.fade(own.vehId, veh, ghost.alphaFor(own.vehId))
        else
          -- Base timer done: collision comes back on the first CLEAR frame and
          -- not one before it. There is no time limit on this and no force.
          if ghost.occupied(own.vehId, veh) then
            own.blocked = own.blocked + dt
            ghost.left[own.vehId] = nil     -- blocked cars stay visibly ghosts
            ghost.fade(own.vehId, veh, TUNE.GHOST_ALPHA)
            if not own.warned and own.blocked >= TUNE.GHOST_OVERLAP_WARN_SEC then
              own.warned = true
              pushNotice('ghost', 'Still ghosted, MOVE CLEAR of the other car')
              if inMultiplayer() then
                TriggerServerEvent('RM_GhostBlocked',
                  jsonEncode({ seconds = own.blocked }))
              end
              log('W', 'raceManager', string.format(
                'Reset ghost blocked for %.1fs: %s', own.blocked,
                tostring(ghost.blockReason or 'another car is in this space')))
            end
          else
            ghost.release('clear')
          end
        end
      end
    end
  end
  ghost.pushHud(dt)

  -- --- other people's ghosts ---------------------------------------------
  -- The shared clock runs on between server pushes so the last-second fade is
  -- smooth at 60 fps instead of stepping three times a second. Every state
  -- broadcast re-anchors it, so drift cannot accumulate -- the same
  -- interpolate-and-correct arrangement the live lap clock uses.
  ghost.serverTime = ghost.serverTime + dt
  for pid, endsAt in pairs(ghost.remote) do
    local vehId = ghost.remoteVeh[pid]
    if vehId then
      -- A lapsed ghost drops back to a flat translucent rather than staying
      -- opaque: the fade said "contact is coming", and if the ghost is still
      -- standing after it, contact did not come. Showing the car as solid while
      -- it is still intangible would be the more confusing of the two lies.
      local left = endsAt - ghost.serverTime
      ghost.left[vehId] = left > 0 and left or nil
      local got, veh = pcall(getObjectByID, vehId)
      if got and veh then ghost.fade(vehId, veh, ghost.alphaFor(vehId)) end
    end
  end

  -- --- re-assert sweep ----------------------------------------------------
  -- Cars appear (a join, a respawn) after the event that ghosted them, so what
  -- is wanted is re-applied on a slow timer rather than assumed to have stuck.
  -- --- cars still waiting to go solid ------------------------------------
  -- A ghost whose reasons have all gone but which had a car inside it when the
  -- moment came. Retried until the space is clear, because "not while somebody
  -- is inside you" is the whole rule and a timer cannot honor it.
  --
  -- Faster than the re-assert sweep below and slower than a frame: a driver
  -- rolling clear should get their collisions back promptly, and the check
  -- measures every car on track, so it is not something to do sixty times a
  -- second with a full grid.
  ghost.pendingIn = (ghost.pendingIn or 0) - dt
  if ghost.pendingIn <= 0 then
    ghost.pendingIn = 0.2
    for vehId in pairs(ghost.pending) do
      local got, veh = pcall(getObjectByID, vehId)
      veh = got and veh or nil
      if not veh then
        ghost.pending[vehId] = nil
      elseif ghost.veh[vehId] then
        -- A reason came back while it waited; it is a ghost again on its own
        -- account and no longer pending anything.
        ghost.pending[vehId] = nil
      elseif not ghost.wouldWeld(vehId, veh) then
        ghost.pending[vehId] = nil
        ghost.apply(vehId, veh, false, 1)
      end
    end
  end

  ghost.refresh = ghost.refresh - dt
  if ghost.refresh > 0 then return end
  ghost.refresh = 2.0
  for reason in pairs(ghost.field) do setGhostReason(reason, true) end
  for pid, endsAt in pairs(ghost.remote) do ghost.applyRemote(pid, endsAt) end
end

-- ---------------------------------------------------------------------------
-- In-world gate visualization: one flat rectangle per checkpoint
-- ---------------------------------------------------------------------------
-- A checkpoint IS its rectangle, so that is exactly what gets drawn: the four
-- edges of the width x height surface the crossing test uses, standing upright
-- and perpendicular to the direction of travel. Nothing else - no poles, no
-- cage - so what an admin sees on track is the real trigger, and raising the
-- height visibly grows the box up the banking.
-- Colors, built once on the first draw rather than at file scope.
--
-- ColorF/ColorI are engine constructors and do not exist while this file is
-- being loaded (nor in the headless tests), so they cannot be plain constants --
-- but rebuilding six of them per gate per frame, which is what the draw loop
-- used to do, is the same waste with extra steps.
-- ===========================================================================
-- THE RENDERER: its own module now
-- ===========================================================================
-- Eight hundred lines of drawing used to sit here. It moved out for the reason
-- the derby did -- this file is at Lua's 200-local ceiling -- and it could only
-- move once `track` and `session` existed: against loose top-level locals it
-- would have needed nineteen getters, and a module reached through nineteen
-- accessors is the same coupling wearing a hat.
--
-- Everything it needs is handed over ONCE below, and every entry is a stable
-- table or a plain function. No getters: `track.route` is rebound, `track` is
-- not, so the module sees every later change for free.
local render = require('raceManager/render')

render.init({
  track = track, session = session, edit = edit, TUNE = TUNE,
  marker = marker, nudge = nudge, branch = branch, pit = pit,
  gateDims = gateDims, sampledVehicle = sampledVehicle,
  sessionRunning = sessionRunning, jokerClosed = jokerClosed,
})

-- The two this file still calls directly, under the names it already used.
-- palette and drawStartPosition are NOT among them: nothing here calls either,
-- they are only handed to the derby, so they go straight from render to derby
-- rather than resting in a local on the way past. Two names off a chunk that
-- has none to spare.
local drawStartPositions = render.drawStartPositions
local drawGates          = render.drawGates

local derby = require('raceManager/derby')

derby.init({
  -- Plain functions.
  palette = render.palette, drawStartPosition = render.drawStartPosition,
  playerVehicle = playerVehicle, vehiclePlacement = vehiclePlacement,
  placeOnStartPosition = placeOnStartPosition,
  setLocalVehicleFrozen = setLocalVehicleFrozen,
  queueFieldPlacement = queueFieldPlacement, pushNotice = pushNotice,
  inMultiplayer = inMultiplayer, localServerId = localServerId,
  fromCurrentServer = fromCurrentServer,
  releaseGridHold = releaseGridHold, requestHold = requestHold,
  -- Mutable scalars this file owns: getters, never values.
  phase = function () return session.phase end,
  isAdmin = function () return session.isAdmin end,
  editorOpen = function () return edit.open end,
  visualize = function () return edit.visualize end,
  maxResets = function () return session.maxResets end,
  -- Tables, by reference, so both halves see the same object.
  spectate = spectate,
  -- A GETTER, like the drag module's copy of it and for the same reason: the
  -- extension REASSIGNS this table when a layout loads, so a reference taken
  -- here would be the empty one the mod booted with, for ever. Nothing in the
  -- derby reads it today -- an arena carries its own start slots -- so this is
  -- a trap being removed rather than a bug being fixed.
  startPositions = function () return track.startPositions end,
  -- The derby reset allowance is genuinely shared: the reset code above
  -- polices race and derby resets through one path, so it reads what the
  -- module writes. One table rather than three variables and a copy.
  resets = derbyResets,
})

-- NOT ALIASED INTO LOCALS. Eight `local derbyUpdate = derby.derbyUpdate` lines
-- would cost exactly the eight forward declarations this replaced, which is how
-- the first version of this split reclaimed a grand total of one local. Call
-- sites read `derby.x` instead, and the module costs this file one name.
--
-- It also removes a foot-gun: an alias captures the function at load time, so a
-- module that reassigns one later would leave this file calling the old one.

-- The UI reaches the derby through the extension table, so the module's
-- entry points are merged onto it here rather than being redeclared.
for _, name in ipairs({
  'derbyAddMarker', 'derbyAddStartPosition', 'derbyClearBoundary',
  'derbyClearStartPositions', 'derbyDeleteLayout', 'derbyEnd',
  'derbyFormUp', 'derbyLoadLayout', 'derbyMoveMarker',
  'derbyMoveStartPosition', 'derbyPreviewMarker', 'derbyPreviewStartPosition',
  'derbyRemoveMarker', 'derbyRemoveStartPosition', 'derbyRequestLayouts',
  'derbyRequestState', 'derbySaveLayout', 'derbySetBoundaryMode',
  'derbySetConfig', 'derbySetShape',
  'derbySetShapeCenter', 'derbyStart', 'derbyToggleVisualize',
  'setDerbyEditorOpen',
}) do
  M[name] = derby[name]
end


local drag = require('raceManager/drag')

drag.init({
  -- Plain functions.
  inMultiplayer = inMultiplayer, fromCurrentServer = fromCurrentServer,
  localServerId = localServerId,
  sampledVehicle = sampledVehicle, pushNotice = pushNotice,
  queueFieldPlacement = queueFieldPlacement,
  releaseGridHold = releaseGridHold, requestHold = requestHold,
  segmentCrossesGate = segmentCrossesGate,
  -- IS THIS CAR STILL LANDING? The drag module will not lift a hold the
  -- placement queue is about to re-apply, and will not measure a launch from an
  -- anchor taken mid-flight. A getter, not the table: `field` is this file's
  -- and nothing outside it has business writing to it.
  placementActive = function () return field.active end,
  -- THE FINISH LINE, THROUGH A GETTER AND NOT BY REFERENCE. `track.route` is
  -- REASSIGNED when a layout loads rather than cleared in place (see the two
  -- `track.route = ` sites), so a reference captured here would go on pointing
  -- at the gates of whatever track happened to be loaded first. The derby's
  -- tables are the opposite case and come by reference; this one cannot.
  finishGate = function ()
    local n = #track.route
    return n > 0 and track.route[n] or nil
  end,
  -- THE LANES ARE THE LOADED TRACK'S START POSITIONS, and this is a GETTER for
  -- the same reason the finish gate is.
  --
  -- It was passed by reference first, with a comment claiming the table was
  -- cleared in place. It is not: `track.startPositions` is REASSIGNED at four
  -- sites, one of them the layout-apply path -- so the reference captured here
  -- at load stayed pointing at the empty table the mod started with, and every
  -- staged car was placed against it. The symptom is "Start position 1 is not
  -- placed on this track" on a strip that plainly has two.
  --
  -- Reassigned-versus-cleared-in-place is not a detail anybody can hold in
  -- their head per field, so tests/wiring_test.lua now checks it instead.
  startPositions = function () return track.startPositions end,
})

-- NOT ALIASED INTO LOCALS, for the reason spelled out where the derby module is
-- required: an alias costs the forward declaration it was meant to save, and it
-- captures the function at load time.
for _, name in ipairs({
  'dragAbort', 'dragBuild', 'dragClear', 'dragPractice', 'dragRequestState',
  'dragRun', 'dragSetConfig', 'dragSetDial', 'dragSetStaging', 'dragStage',
  'dragWithdraw',
}) do
  M[name] = drag[name]
end

-- Post-join: ask the server for the current state once its socket has had a
-- moment to come up, so a driver who joins a server mid-session sees the live
-- race without having to open the app and press anything.
local function joinRequestUpdate(dt)
  if not joinRequestLeft then return end
  joinRequestLeft = joinRequestLeft - dt
  if joinRequestLeft > 0 then return end
  joinRequestLeft = nil
  M.requestState()
end

function M.onUpdate(dt)
  localTime = localTime + dt
  stickyUpdate(dt)          -- conditions held on the HUD: pace lap, caution, restart
  joinRequestUpdate(dt)     -- deferred state request after joining a server
  checkGates()
  lapTimerUpdate(dt)        -- live lap clock for this driver's own HUD
  whiteFlagWatch()          -- the last-lap flag, waved on the approach
  reportProgress(dt)        -- live position telemetry (distance to next gate)
  drawGates(derby.derbyState.phase == 'running')
  drawStartPositions()      -- starting grid slots
  nudge.update()            -- mouse editing, only while the mode is on
  fieldUpdate(dt)           -- ghosted, staggered grid placement / mass respawn
  holdUpdate(dt)            -- grid hold: verify it is holding, report position
  pit.update(dt)            -- pit stalls: hold, repair in place, release
  snapshotUpdate(dt)        -- Module 1: rolling "last good position"
  resetGuardUpdate(dt)      -- Module 1: teleport-echo window + notice throttle
  resetInputBlockUpdate()   -- Module 1: dead reset keys once the allowance is gone
  spectatorUpdate(dt)       -- Module 1: follow the spectate target when it goes
  -- The node grabber is off for the whole of a derby -- form-up, countdown and
  -- running -- not just while the cars are moving. Dragging a car into position
  -- on the grid before GO is the same cheat with better timing.
  spectate.setGrabberBlocked(derby.derbyState.phase == 'forming'
    or derby.derbyState.phase == 'countdown' or derby.derbyState.phase == 'running')
  ghostUpdate(dt)           -- ghost mode qualifying
  ghost.respawnUpdate(dt)   -- derby respawn ghosts, on the local clock
  vehicleConfigUpdate(dt)   -- Module 4: declare setup changes to the server
  derby.derbyUpdate(dt)
  derby.derbyDrawBoundary()
  -- The drag pass: the tree, the launch, the finish line and the trap speed.
  -- Costs one comparison a frame when no ladder is running.
  drag.dragUpdate(dt)
end

-- ---------------------------------------------------------------------------
-- Checkpoint editor API (called by the UI app)
-- ---------------------------------------------------------------------------
-- Which route the editor is currently building: the main lap or the joker
-- route. Everything below (+ Checkpoint Here, Undo, the list) follows it.
-- Three targets now: the main lap, the joker route, and the starting grid.
-- The UI app tells us whether its editor panel is on screen. Drives the
-- start-slot markers, which are editor furniture rather than driver
-- information. Sent when the admin tab changes, when the app mounts, and when
-- it is torn down (a closed app cannot have an open editor).
-- Diagnostic for the in-game Lua console:
--   dump(raceManager.ghostStatus())
-- Answers "why is this car still a ghost" without needing the log: whether it
-- is ghosted, WHICH source is measuring the space around it, and what is
-- currently blocking the restore. `boundsFrom` is the one that matters -- a
-- field where no bounding box ever resolves behaves very differently from one
-- where they do, and until now there was no way to tell which you had.
function M.ghostStatus()
  local veh = ownVehicle()
  local measured, how = false, 'no vehicle'
  if veh then
    if ghost.bounds(veh, 0) then measured = true end
    local okA, bbA = pcall(function () return veh:getSpawnWorldOOBB() end)
    local okB, bbB = pcall(function () return veh:getWorldBox() end)
    local okC = pcall(function () return veh:getInitialLength() end)
    how = (okA and bbA and 'spawnWorldOOBB')
      or (okB and bbB and 'worldBox')
      or (okC and 'vehicle dimensions')
      or 'nothing - falling back to a plain radius'
  end
  local ghosted = 0
  for _ in pairs(ghost.veh) do ghosted = ghosted + 1 end
  local reasons = {}
  for r in pairs(ghost.field) do reasons[#reasons + 1] = r end
  return {
    ownGhosted     = ghost.own.vehId ~= nil,
    settling       = ghost.own.settling,
    secondsLeft    = ghost.own.left,
    blockedFor     = ghost.own.blocked,
    blockReason    = ghost.blockReason,
    boundsMeasured = measured,
    boundsFrom     = how,
    carsGhosted    = ghosted,
    fieldReasons   = table.concat(reasons, ','),
    phase          = session.phase,
    ghostQuali     = ghostQuali,
  }
end

function M.setEditorOpen(open)
  edit.open = open == true
  -- A closed editor cannot have a mouse mode, and a cursor left released with
  -- nothing to use it is a camera that has stopped answering for no reason.
  if not edit.open then nudge.release() end
end

-- Editor toggle: is this track a sprint or a circuit?
--
-- Told to the server as well as kept locally, because the lap count is the
-- server's and a sprint stage is one traversal by definition -- leaving an
-- admin to also remember "and set laps to 1" is the workaround this replaces.
function M.setPointToPoint(on)
  track.pointToPoint = on == true
  render.invalidateLabels()      -- the gate labels say which mode this is
  if inMultiplayer() then
    TriggerServerEvent('RM_SetPointToPoint', jsonEncode({ enabled = track.pointToPoint }))
  end
  pushRouteState()
  log('I', 'raceManager', 'Track mode: ' .. (track.pointToPoint and 'POINT TO POINT' or 'circuit'))
end

function M.setEditorTarget(target)
  target = tostring(target or 'main')
  if target ~= 'joker' and target ~= 'start' and target ~= 'pit'
     and target ~= 'pitEntry' and target ~= 'pitExit'
     and target ~= 'branch' and target ~= 'marker' then target = 'main' end
  edit.target = target
  pushRouteState()
  log('I', 'raceManager', 'Editor target: ' .. edit.target)
end

local function activeEditorRoute()
  if edit.target == 'joker' then return track.jokerRoute end
  if edit.target == 'pit'   then return track.pitRoute end
  if edit.target == 'pitEntry' then return track.pitEntry end
  if edit.target == 'pitExit'  then return track.pitExit end
  if edit.target == 'start' then return track.startPositions end
  if edit.target == 'branch' then return branch.list end
  if edit.target == 'marker' then return marker.list end
  return track.route
end

-- Nudge mode's behavior. The table itself is declared at the top of the file,
-- beside `branch`, because the frame loop and the drawing code both reach it and
-- both run above this point: a local declared here would be a nil GLOBAL to
-- them, which compiles cleanly and fails only when somebody drags a gate.
--
-- Are the engine pieces this needs present? Resolved once. `ui_imgui` is how
-- every stock tool reads the mouse, and cameraMouseRayCast is the same call the
-- world editor's own object placement uses.
-- Releasing and recapturing the mouse.
--
-- There is NO `core_canvas` global. The cursor helpers live in
-- lua/ge/client/canvas.lua, which is not an extension: the game reaches it with
-- require('client/canvas'), and so does this. Guessing a global that reads like
-- the other core_* ones is what made the first build of this refuse to start
-- with "needs a newer BeamNG build" on a build that had everything.
--
-- Resolved once and remembered as false, because require() on a name that does
-- not resolve walks the whole package path.
function nudge.canvas()
  if nudge.cv ~= nil then return nudge.cv or nil end
  local ok, mod = pcall(require, 'client/canvas')
  nudge.cv = (ok and type(mod) == 'table' and type(mod.showCursor) == 'function')
    and mod or false
  return nudge.cv or nil
end

-- Was the cursor already free when we arrived? Best effort: BeamNG has no
-- Lua-side getter for this anywhere, so this probes the Canvas for a Torque
-- isCursorOn and returns nil when it cannot tell.
--
-- nil is a normal answer, not a failure, and what is done with it is the whole
-- point of nudge.release below.
function nudge.cursorFree()
  local ok, on = pcall(function ()
    local c = scenetree and scenetree.findObject('Canvas')
    return c and c:isCursorOn()
  end)
  if ok and type(on) == 'boolean' then return on end
  return nil
end

-- Show or hide the cursor, preferring the module and falling back to the raw
-- engine call it wraps. canvas.lua is lockMouse plus a setCursorVisible on the
-- scenetree Canvas, so lockMouse alone still frees the mouse from the camera,
-- which is the half that matters here.
function nudge.cursor(show)
  local cv = nudge.canvas()
  if cv then
    local ok = pcall(function ()
      if show then cv.showCursor() else cv.hideCursor() end
    end)
    if ok then return true end
  end
  if type(lockMouse) == 'function' then
    return pcall(lockMouse, not show) and true or false
  end
  return false
end

-- Which pieces are present. Each is named separately so a refusal says what is
-- actually missing rather than blaming the game version.
function nudge.missing()
  local gaps = {}
  local okIm, im = pcall(function () return ui_imgui end)
  nudge.im = (okIm and type(im) == 'table' and type(im.IsMouseDown) == 'function')
    and im or nil
  if not nudge.im then gaps[#gaps + 1] = 'ui_imgui' end
  if type(cameraMouseRayCast) ~= 'function' then gaps[#gaps + 1] = 'cameraMouseRayCast' end
  if not (nudge.canvas() or type(lockMouse) == 'function') then
    gaps[#gaps + 1] = 'the cursor lock'
  end
  return gaps
end

function nudge.available()
  if nudge.ready ~= nil then return nudge.ready end
  local gaps = nudge.missing()
  nudge.ready = (#gaps == 0)
  if not nudge.ready then
    log('W', 'raceManager', 'Nudge mode unavailable, missing: '
      .. table.concat(gaps, ', '))
  end
  return nudge.ready
end

-- Give the mouse back. Called from every exit, including the ones that are not
-- the admin pressing the button: closing the editor, changing tab, unloading.
-- A cursor left released with no mode to use it is a camera that has stopped
-- answering the mouse for no visible reason.
-- TAKING THE CURSOR BACK IS THE DANGEROUS DIRECTION, so it only happens when we
-- know we took it in the first place.
--
-- The first build locked the mouse to the camera on every exit. An admin who
-- already had a free cursor (which they must have had, since clicking the Nudge
-- button needs one) turned the mode off and could no longer click anything at
-- all: the panel, the button to turn it back on, none of it. A dead end with no
-- way out, from a mode meant to be a convenience.
--
-- So: re-lock ONLY when the probe positively said the cursor was locked when we
-- arrived. `nil` means the probe could not tell, and the answer to not knowing
-- is to leave the cursor free. A free cursor costs a keypress on the player's
-- own camera toggle; a captured one costs them the whole UI.
function nudge.release()
  if not nudge.on then return end
  nudge.on, nudge.sel, nudge.dragging, nudge.list = false, nil, false, nil
  if nudge.wasFree == false then
    nudge.cursor(false)
    log('I', 'raceManager', 'Nudge mode off, mouse handed back to the camera')
  else
    log('I', 'raceManager', 'Nudge mode off, cursor left free (it was not ours to take)')
  end
  nudge.wasFree = nil
end

function nudge.set(on)
  on = on and true or false
  if on == nudge.on then return end
  if not on then nudge.release(); pushRouteState(); return end
  if not nudge.available() then
    guihooks.trigger('RaceManagerEditorMsg', {
      msg = 'Place mode cannot start, missing: ' .. table.concat(nudge.missing(), ', ') })
    return
  end
  nudge.on, nudge.sel, nudge.dragging = true, nil, false
  -- Recorded BEFORE the cursor is touched: this is the state to put back.
  nudge.wasFree = nudge.cursorFree()
  nudge.cursor(true)
  log('I', 'raceManager', 'Nudge mode on, mouse released from the camera')
  pushRouteState()
end

-- Nearest gate to the cursor ray, by perpendicular distance from the ray to the
-- gate's center. Behind the camera does not count: a gate at your back is
-- geometrically close to the ray running through it and is never what you meant.
function nudge.pick(list, ray)
  if not (ray and ray.pos and ray.dir) then return nil end
  local ox, oy, oz = ray.pos.x, ray.pos.y, ray.pos.z
  local dx, dy, dz = ray.dir.x, ray.dir.y, ray.dir.z
  local dlen = math.sqrt(dx * dx + dy * dy + dz * dz)
  if dlen < 1e-6 then return nil end
  dx, dy, dz = dx / dlen, dy / dlen, dz / dlen
  local best, bestD = nil, nudge.PICK_RADIUS
  for i, wp in ipairs(list) do
    local vx, vy, vz = wp.x - ox, wp.y - oy, wp.z - oz
    local along = vx * dx + vy * dy + vz * dz
    if along > 0 then
      local px, py, pz = vx - dx * along, vy - dy * along, vz - dz * along
      local d = math.sqrt(px * px + py * py + pz * pz)
      if d < bestD then best, bestD = i, d end
    end
  end
  return best
end

-- Turn a gate in place. Heading is a unit vector on the ground plane, and the
-- gate's rectangle is built perpendicular to it, so rotating this rotates the
-- gate. Renormalized every time because repeated rotation of a stored pair
-- drifts off the unit circle, and a heading that is not unit length silently
-- changes how wide the gate tests.
function nudge.turn(wp, radians)
  if not wp then return end
  local hx, hy = tonumber(wp.hx) or 0, tonumber(wp.hy) or 1
  local c, s = math.cos(radians), math.sin(radians)
  local nx, ny = hx * c - hy * s, hx * s + hy * c
  local len = math.sqrt(nx * nx + ny * ny)
  if len < 1e-6 then return end
  wp.hx, wp.hy = nx / len, ny / len
end

-- Move a gate to a point on the ground, keeping the height it was authored at.
-- The raycast lands ON the terrain, and a gate dropped to ground level is a gate
-- whose lower half is buried: what matters is the height of its CENTER above the
-- road, which is what the original placement captured from the car.
-- `newGround` is the ground at the DESTINATION, and passing it is what stops a
-- gate climbing a tree.
--
-- This used to take its new height from `hit.z`, the cursor raycast. That ray
-- stops at the first thing it meets, which over woodland is the CANOPY: hover a
-- drag across a group of trees and the gate was lifted to treetop height and
-- left there. Reported from a live session, and it is the same class of mistake
-- the ground probe made -- trusting whatever a downward ray met first to be the
-- ground.
--
-- The caller probes for `newGround` starting from the gate's OWN height, which
-- is below the canopy, so the trees are never in the ray at all.
-- Where the cursor ray crosses a horizontal plane at height `z`.
--
-- THIS IS WHAT A DRAG FOLLOWS, instead of the raycast against the world. A
-- raycast hit jumps: drag across a treeline and it flips between the ground and
-- the canopy twenty meters higher, so a centimeter of mouse movement reads as
-- meters of travel, in a direction nobody asked for. Dragging over woodland was
-- unusable for exactly that reason.
--
-- A plane at the gate's own height has none of that. It is continuous, it
-- ignores trees, roofs and terrain completely, and it makes a drag mean the one
-- thing it should mean: move this gate around at the height it is already at.
-- Height is the wheel's job and the Up/Down buttons', not the drag's.
--
-- Returns nil when the ray is too close to horizontal to meet the plane at all,
-- which is the admin looking at the skyline rather than at the track.
function nudge.planeAt(ray, z)
  if not (ray and ray.pos and ray.dir) then return nil end
  local dz = ray.dir.z
  if not dz or math.abs(dz) < 1e-4 then return nil end
  local t = (z - ray.pos.z) / dz
  if t <= 0 or t > TUNE.NUDGE_MAX_REACH * 4 then return nil end
  return ray.pos.x + ray.dir.x * t, ray.pos.y + ray.dir.y * t
end

function nudge.moveTo(wp, hit, ground, newGround)
  if not (wp and hit) then return end
  local lift = wp.z - (ground or wp.z)
  wp.x, wp.y = hit.x, hit.y
  wp.z = (newGround or hit.z) + lift
end

-- Which way should a gate placed by clicking face?
--
-- Driving answers this for free: the car IS the heading. A click has no
-- direction of its own, so it takes the one the route is already traveling,
-- from the previous gate toward the new point. Clicking along a road in order
-- then produces gates that face the way the road goes, which is the whole reason
-- this is faster than driving a long track.
--
-- The first gate on an empty route has no previous, so it falls back to the way
-- the camera is looking, flattened. That is a guess, and the scroll wheel is
-- right there to fix it.
function nudge.headingFor(list, x, y, ray, after)
  local prev = after or list[#list]
  if prev then
    local dx, dy = x - prev.x, y - prev.y
    local len = math.sqrt(dx * dx + dy * dy)
    if len > 1e-3 then return dx / len, dy / len end
  end
  if ray and ray.dir then
    local dx, dy = ray.dir.x, ray.dir.y
    local len = math.sqrt(dx * dx + dy * dy)
    if len > 1e-3 then return dx / len, dy / len end
  end
  return 0, 1
end

-- Ctrl+click on open ground: a new gate there.
--
-- Appends, or inserts AFTER the selected gate when one is picked, which is how a
-- gap noticed halfway round gets filled without re-driving everything after it.
-- Both paths go through the ordinary editor entry points, so the branch rules,
-- the slot shifting and the grid-tool bookkeeping all happen exactly once, in
-- the place that already knew how.
function nudge.place(list, hit, ray)
  if not (hit and hit.pos) then return end
  local x, y = hit.pos.x, hit.pos.y
  -- THE RAY LANDS ON THE GROUND, AND A GATE MUST NOT.
  --
  -- A gate placed by DRIVING takes the car's origin, which is about half a meter
  -- up. A click takes the raycast hit, which is the terrain surface itself, so
  -- clicked gates sat lower than driven ones on the same track -- far enough
  -- that a Last Checkpoint reset onto one put the car half in the dirt, and on a
  -- steep face far enough to bury the gate outright.
  local z = liftAboveGround(x, y, hit.pos.z, TUNE.GROUND_CLEAR)
  -- Derived from the gate this one is going in AFTER, which is not always the
  -- last gate on the route: with a gate selected, this is an INSERT. Reading the
  -- end of the route while inserting into the middle of it aimed the new gate at
  -- wherever the lap happened to finish, which is what stood a car sideways
  -- across the track on a reset.
  local after = (nudge.sel and edit.target ~= 'branch') and list[nudge.sel] or list[#list]
  local hx, hy = nudge.headingFor(list, x, y, ray, after)
  local place = { x = x, y = y, z = z, hx = hx, hy = hy }
  -- A branch gate belongs to a slot rather than a position in an order, so it is
  -- always an add: insertCheckpoint refuses them for the same reason.
  if nudge.sel and edit.target ~= 'branch' then
    local at = nudge.sel + 1
    M.insertCheckpoint(at, place)
    nudge.sel = at
  else
    M.editorAdd(place)
    nudge.sel = #list
  end
  nudge.dragging = false
  pushRouteState()
end

-- Turn the picked gate from the panel. The scroll wheel is the fast way and not
-- everybody has one, so the same step is on a pair of buttons. `dir` is -1 or 1.
function M.nudgeTurn(dir)
  -- Reached only from the panel, so this IS the signal that a CEF click just
  -- happened and the world click it also produced must be ignored.
  nudge.uiGrace = TUNE.NUDGE_UI_GRACE
  if not (nudge.on and nudge.sel and nudge.list) then return end
  local wp = nudge.list[nudge.sel]
  if not wp then return end
  nudge.turn(wp, (tonumber(dir) or 1) >= 0 and nudge.TURN_PER_STEP or -nudge.TURN_PER_STEP)
  if edit.target == 'branch' then branch.rebuild() end
  pushRouteState()
end

-- Delete the picked gate, from the panel rather than a key. Guessing a keybind
-- for a destructive action on a build that cannot be tested here is how the node
-- grabber block shipped listening for names nothing answered to.
-- Raise or lower the picked gate, for a mouse with no wheel and for the times
-- the wheel is too slow: a gate deep in a hillside takes a lot of clicks.
--
-- Floored the same way shift+scroll is, so the control that digs a gate out can
-- never be used to bury one.
function M.nudgeLift(dir)
  -- Reached only from the panel, so this IS the signal that a CEF click just
  -- happened and the world click it also produced must be ignored.
  nudge.uiGrace = TUNE.NUDGE_UI_GRACE
  if not (nudge.on and nudge.sel and nudge.list) then return end
  local wp = nudge.list[nudge.sel]
  if not wp then return end
  if (tonumber(dir) or 1) >= 0 then
    wp.z = liftAboveGround(wp.x, wp.y, wp.z + TUNE.NUDGE_LIFT_PER_PRESS,
      TUNE.GROUND_CLEAR)
  else
    wp.z = lowerToGround(wp.x, wp.y, wp.z, TUNE.NUDGE_LIFT_PER_PRESS,
      TUNE.GROUND_CLEAR)
  end
  if edit.target == 'branch' then branch.rebuild() end
  pushRouteState()
end

function M.nudgeDelete()
  -- Reached only from the panel: see the note on nudgeTurn.
  nudge.uiGrace = TUNE.NUDGE_UI_GRACE
  if not (nudge.on and nudge.sel) then return end
  local i = nudge.sel
  nudge.sel, nudge.dragging = nil, false
  if edit.target == 'start' then
    M.removeStartPosition(i)
  else
    M.removeCheckpoint(i)
  end
  pushRouteState()
end

-- One frame of the mode. Everything here is guarded: a mode that throws inside
-- the frame loop takes the whole mod down with it.
function nudge.update()
  if not nudge.on then return end
  -- The editor closing, the admin logging out, or a session starting all end it.
  -- Authoring a track while it is being raced on is not a thing to allow, and
  -- the cursor has to go back either way.
  if not (edit.open and session.isAdmin) or sessionRunning() then
    nudge.release()
    return
  end
  local im = nudge.im
  if not im then return end
  -- Never steal a click meant for a UI panel. The HUD app is a real window over
  -- the world and the admin is clicking its buttons with this same cursor.
  local wantsUi = false
  pcall(function () wantsUi = im.GetIO().WantCaptureMouse end)
  -- A panel press cannot become a drag. The grace is set when the button's Lua
  -- runs, which may be a frame after the click itself was seen here -- cancelling
  -- `dragging` covers that, because a drag needs several frames of held movement
  -- before it shifts anything.
  if nudge.uiGrace > 0 then
    nudge.uiGrace = nudge.uiGrace - 1
    nudge.dragging = false
    nudge.grabX, nudge.grabY = nil, nil
  end

  local list = activeEditorRoute()
  nudge.list = list
  local ray, hit
  pcall(function () ray = getCameraMouseRay() end)
  pcall(function () hit = cameraMouseRayCast(false) end)

  local down, held, up = false, false, false
  pcall(function ()
    down = im.IsMouseClicked(0)
    held = im.IsMouseDown(0)
    up   = im.IsMouseReleased(0)
  end)

  local ctrl = false
  pcall(function () ctrl = im.GetIO().KeyCtrl == true end)

  -- Ctrl+click PLACES rather than picks. Checked first so the two never both
  -- happen on one click: placing and then immediately dragging the new gate off
  -- the point it was placed at is not what anybody meant.
  if down and ctrl and not wantsUi then
    nudge.place(list, hit, ray)
    return
  end

  -- A CLICK THAT PICKS NOTHING LEAVES THE SELECTION ALONE.
  --
  -- It used to clear it, and that is what grayed the movement buttons out the
  -- instant one was pressed: the panel is a CEF overlay, so the press arrives
  -- here as a world click too, the ray behind the panel hits no gate, and the
  -- gate being worked on was dropped. Pressing Up therefore disabled Up.
  --
  -- Keeping it is the better behavior on its own terms too. A miss is ambiguous
  -- -- the panel, a mis-aim, a gate hidden behind another -- and none of those
  -- are a request to forget what is being edited. Picking a different gate still
  -- switches, and leaving the mode still clears.
  if down and not wantsUi and nudge.uiGrace <= 0 then
    local picked = nudge.pick(list, ray)
    if picked and picked ~= nudge.sel then
      nudge.sel = picked
      pushRouteState()
    end
    nudge.dragging = picked ~= nil
    -- WHERE THE CURSOR WAS WHEN THE GATE WAS GRABBED.
    --
    -- A drag moves the gate BY how far the cursor has travelled since this
    -- point, never TO where the cursor ray happens to land. Those are only the
    -- same thing when the ray lands exactly on the gate, and it never does: a
    -- gate is a debug drawing with no collision, so the ray goes straight
    -- through it to the ground behind, which from any raised camera is meters
    -- away and at whatever height is under THERE.
    --
    -- Moving TO the landing point is what teleported a gate under the map the
    -- instant it was picked. Skipping the down-frame did not fix that, because
    -- the frame after it -- button still held, cursor not yet moved -- did
    -- exactly the same thing. A click is several frames long.
    local wpSel = picked and list[picked]
    if wpSel then
      nudge.grabX, nudge.grabY = nudge.planeAt(ray, wpSel.z)
    else
      nudge.grabX, nudge.grabY = nil, nil
    end
  end
  if up then
    nudge.dragging = false
    nudge.grabX, nudge.grabY = nil, nil
  end

  local wp = nudge.sel and list[nudge.sel]
  if not wp then
    if nudge.sel ~= nil then
      nudge.sel, nudge.dragging = nil, false
      pushRouteState()
    end
    nudge.dragging = false
    return
  end

  -- NO EARLY RETURNS IN HERE. The scroll handling below shares this frame, and
  -- a drag that declines to move must not take the wheel with it: bailing out of
  -- the whole update was how shift+scroll stopped working while the button was
  -- held, which is exactly when an admin uses it.
  --
  -- A DRAG IS PURELY HORIZONTAL. It follows the cursor across a plane at the
  -- gate's own height and never touches z, so whatever height the wheel or the
  -- Up/Down buttons put a gate at is the height it keeps while you slide it
  -- around. The only thing that may change z here is the floor at the end, and
  -- that can only ever raise a gate out of a hillside it was dragged into.
  if nudge.dragging and held and nudge.grabX then
    local cx, cy = nudge.planeAt(ray, wp.z)
    if cx then
      local dx, dy = cx - nudge.grabX, cy - nudge.grabY
      local d2 = dx * dx + dy * dy
      if d2 > TUNE.NUDGE_MAX_REACH * TUNE.NUDGE_MAX_REACH then
        -- The cursor swung past the horizon and the plane crossing shot off with
        -- it. Re-anchor rather than apply it, so it does not come back later as
        -- one enormous accumulated leap.
        nudge.grabX, nudge.grabY = cx, cy
      elseif d2 >= TUNE.NUDGE_DRAG_MIN * TUNE.NUDGE_DRAG_MIN then
        nudge.grabX, nudge.grabY = cx, cy
        wp.x, wp.y = wp.x + dx, wp.y + dy
        -- Dragged into rising ground, a gate would end up inside the hill. This
        -- is the only height change a drag can make, and it only ever lifts.
        wp.z = liftAboveGround(wp.x, wp.y, wp.z, TUNE.GROUND_CLEAR)
        if edit.target == 'branch' then branch.rebuild() end
        if edit.target == 'start' then branch.gridTool.generated = false end
        pushRouteState()
      end
    end
  end

  -- Scroll turns the selected gate. The tedious half of a fine adjustment is the
  -- heading, because re-driving a corner is the only other way to change it.
  --
  -- SHIFT+SCROLL RAISES AND LOWERS IT INSTEAD, and that is the only control that
  -- moves a gate vertically. The Gate size sliders look like they should and do
  -- not: those set a gate's HEIGHT and DEPTH, which is how far it extends up and
  -- down from where it sits, not where it sits. A gate that ended up under the
  -- map was therefore unrecoverable by any control in the editor -- the sliders
  -- would grow it until its top poked through the ground, which is not the same
  -- as digging it out.
  local wheel, shift = 0, false
  pcall(function ()
    local io_ = im.GetIO()
    wheel = io_.MouseWheel or 0
    shift = io_.KeyShift == true
  end)
  if wheel ~= 0 and not wantsUi then
    if shift then
      -- Floored at ground clearance, so the control that exists to dig a gate
      -- out cannot be used to bury one. Up and down go through different helpers
      -- for the reason spelled out on lowerToGround: a failed probe must leave a
      -- lift alone and must refuse a drop outright.
      if wheel > 0 then
        wp.z = liftAboveGround(wp.x, wp.y,
          wp.z + wheel * TUNE.NUDGE_LIFT_PER_STEP, TUNE.GROUND_CLEAR)
      else
        wp.z = lowerToGround(wp.x, wp.y, wp.z,
          -wheel * TUNE.NUDGE_LIFT_PER_STEP, TUNE.GROUND_CLEAR)
      end
    else
      nudge.turn(wp, wheel * nudge.TURN_PER_STEP)
    end
    if edit.target == 'branch' then branch.rebuild() end
    pushRouteState()
  end
end

-- Rebuild the per-checkpoint lookup from the authored list. Called after every
-- edit, so what the editor shows and what the crossing code arms are the same
-- thing -- an admin standing on a branch gate sees it go green.
--
-- A slot with no branch gate gets no entry at all rather than an empty table,
-- because the crossing path tests `bySlot[i]` for nil to skip the whole business
-- on an ordinary track.
function branch.rebuild()
  local bySlot = {}
  for _, g in ipairs(branch.list) do
    local slot = tonumber(g.slot)
    if slot then
      slot = math.floor(slot)
      local at = bySlot[slot]
      if not at then at = {}; bySlot[slot] = at end
      at[#at + 1] = g
    end
  end
  branch.bySlot = bySlot
end

-- The lowest checkpoint with no branch gate yet, so placing a full mirror lap is
-- drive-and-click without touching the checkpoint picker once.
function branch.nextFreeSlot()
  for i = 1, math.max(#track.route, 1) do
    if not branch.bySlot[i] then return i end
  end
  return math.max(#track.route, 1)
end

-- Which checkpoint the next placed branch gate belongs to.
function M.setBranchSlot(slot)
  slot = math.floor(tonumber(slot) or 1)
  if slot < 1 then slot = 1 end
  if #track.route > 0 and slot > #track.route then slot = #track.route end
  branch.editSlot = slot
  pushRouteState()
end

-- Re-point an already-placed branch gate at a different checkpoint. Nothing is
-- displaced: a checkpoint holding two branch gates is the feature, not a clash.
function M.setBranchGateSlot(index, slot)
  index = math.floor(tonumber(index) or 0)
  local g = branch.list[index]
  if not g then return end
  slot = math.floor(tonumber(slot) or 1)
  if slot < 1 then slot = 1 end
  if #track.route > 0 and slot > #track.route then slot = #track.route end
  g.slot = slot
  branch.rebuild()
  pushRouteState()
end

-- Drop one branch gate. The checkpoint it belonged to keeps its main gate and
-- any other branch gates, so removing one is never removing a checkpoint.
function M.removeBranchGate(index)
  index = math.floor(tonumber(index) or 0)
  if not branch.list[index] then return end
  table.remove(branch.list, index)
  branch.rebuild()
  pushRouteState()
  log('I', 'raceManager', 'Branch gate ' .. index .. ' removed')
end

-- Place a marker where the car is standing.
--
-- A gate is given its size HERE, once, and keeps it. It inherits from the gate
-- placed before it, so a creator sets the size once and drives the rest of the
-- route; the first gate of a fresh route takes the standard default.
--
-- This replaced a global width/height that every gate without an override read
-- live. That setting was a footgun: nudging a slider resized the entire circuit
-- at once, retroactively, with nothing to undo it -- and the gates it hit were
-- exactly the ones the creator had never thought about. A size that is decided
-- when a gate is placed can only ever be wrong for that gate.
--
-- Start positions are placements, not gates, so they get no dimensions.
function M.editorAdd(place)
  place = place or vehiclePlacement()
  if not place then
    log('W', 'raceManager', 'Editor: no player vehicle, cannot place')
    return
  end
  local target = activeEditorRoute()
  if edit.target ~= 'start' then
    local prev = target[#target]
    place.width  = clampWidth(prev and prev.width  or track.checkpointWidth)
    place.height = clampHeight(prev and prev.height or track.checkpointHeight)
    place.depth  = clampDepth(prev and prev.depth  or track.checkpointDepth)
  end
  -- A branch gate is placed AGAINST A CHECKPOINT: it is not a new checkpoint, it
  -- is the other way of taking one that already exists. Placing it is what makes
  -- the track a split lane or a head-on layout rather than a longer lap.
  --
  -- Placing a second one on a checkpoint that already has one ADDS it. That is
  -- the difference from every other editor target: a checkpoint is allowed as
  -- many ways through it as an admin cares to place, and "move the existing one"
  -- would make three ways through a corner impossible. Move is Nudge, or Move Here.
  if edit.target == 'branch' then
    if #track.route == 0 then
      guihooks.trigger('RaceManagerEditorMsg', { msg = 'Place the main route first' })
      return
    end
    local slot = math.floor(branch.editSlot or 1)
    if slot < 1 then slot = 1 end
    if slot > #track.route then slot = #track.route end
    place.slot = slot
    branch.list[#branch.list + 1] = place
    branch.rebuild()
    branch.editSlot = branch.nextFreeSlot()
    pushRouteState()
    log('I', 'raceManager', 'Branch gate added for CP ' .. slot)
    return
  end
  -- A marker carries the symbol the editor is currently set to. Stamped at
  -- placement rather than chosen through seven different placement buttons:
  -- driving the route dropping signs and then going back to say what each one
  -- means is how somebody actually builds a stage, and the symbol stays
  -- changeable afterwards either way.
  if edit.target == 'marker' then
    place.kind = marker.validKind(marker.kind) or 'right'
  end
  target[#target + 1] = place
  -- A slot placed by hand after a generate leaves the generator's block no
  -- longer the last `count` of them, so it stops claiming to own one.
  if edit.target == 'start' then branch.gridTool.generated = false end
  pushRouteState()
end

-- The symbol new markers get, and the one an already-placed marker shows.
--
-- Two jobs in one entry point because they are the same decision from the
-- admin's side: `index` nil means "what I am about to place", a number means
-- "that one there". A marker whose kind is changed is not moved, so the sign
-- can be corrected from the panel without driving back to it.
function M.setMarkerKind(kind, index)
  local k = marker.validKind(kind)
  if not k then return end
  local i = tonumber(index)
  if i then
    i = math.floor(i)
    local m = marker.list[i]
    if not m then return end
    m.kind = k
    log('I', 'raceManager', 'Marker ' .. i .. ' set to ' .. k)
  else
    marker.kind = k
    log('I', 'raceManager', 'Next marker will be ' .. k)
  end
  pushRouteState()
end

function M.editorUndo()
  local target = activeEditorRoute()
  if #target > 0 then
    target[#target] = nil
    if edit.target == 'joker' then
      if session.jokerArmed > #track.jokerRoute then session.jokerArmed = math.max(#track.jokerRoute, 1) end
    elseif edit.target == 'main' and session.armedWp > #track.route then
      session.armedWp = math.max(#track.route, 1)
    elseif edit.target == 'branch' then
      branch.rebuild()
      branch.editSlot = branch.nextFreeSlot()
    end
    pushRouteState()
  end
end

function M.editorClear()
  -- Clearing the joker route or the grid on its own must not wipe the main lap.
  if edit.target == 'pit' then
    track.pitRoute = {}
    pushRouteState()
    log('I', 'raceManager', 'Pit stalls cleared')
    return
  end
  -- Signage only. Without this branch, clearing while the Marker tab is open
  -- falls through to the bottom of this function and wipes the MAIN ROUTE --
  -- the whole track, from a button that says it clears markers.
  if edit.target == 'marker' then
    marker.list = {}
    pushRouteState()
    log('I', 'raceManager', 'Markers cleared')
    return
  end
  if edit.target == 'joker' then
    track.jokerRoute   = {}
    session.jokerArmed   = 1
    session.jokerTaken   = false
    session.jokerLapUsed = nil
    pushRouteState()
    log('I', 'raceManager', 'Joker route cleared')
    return
  end
  if edit.target == 'start' then
    track.startPositions = {}
    session.gridSlot = nil
    branch.gridTool.generated = false
    pushRouteState()
    log('I', 'raceManager', 'Start positions cleared')
    return
  end
  -- Clears the branch gates, not the main route: the other way round a track is
  -- a thing an admin iterates on, and the lap it branches off has to survive it.
  if edit.target == 'branch' then
    branch.list   = {}
    branch.bySlot = {}
    branch.editSlot = 1
    pushRouteState()
    log('I', 'raceManager', 'Branch gates cleared')
    return
  end
  clearTrackState('editor clear')
end

-- --- Start position editing -------------------------------------------------
-- Placed slots stay editable: move one to where the car is standing now, or
-- drop it and let the rest of the grid close up.
function M.moveStartPosition(index)
  index = math.floor(tonumber(index) or 0)
  if not track.startPositions[index] then
    log('W', 'raceManager', 'moveStartPosition: no start position at ' .. tostring(index))
    return
  end
  local place = vehiclePlacement()
  if not place then
    guihooks.trigger('RaceManagerEditorMsg', { msg = 'Get in a vehicle first' })
    return
  end
  track.startPositions[index] = place
  -- Hand-placed now, so the sliders let go of it: they own a block of slots by
  -- count, and a slot moved by hand is no longer where that count says it is.
  branch.gridTool.generated = false
  pushRouteState()
  log('I', 'raceManager', 'Start position ' .. index .. ' moved to the current vehicle')
end

function M.removeStartPosition(index)
  index = math.floor(tonumber(index) or 0)
  if not track.startPositions[index] then return end
  table.remove(track.startPositions, index)
  if session.gridSlot and session.gridSlot > #track.startPositions then session.gridSlot = nil end
  branch.gridTool.generated = false
  pushRouteState()
end

-- Preview: stand the car on a placed slot so the creator can check spacing
-- without starting a race. Never freezes - this is an editor convenience.
function M.previewStartPosition(index)
  index = math.floor(tonumber(index) or 0)
  local sp = track.startPositions[index]
  if not sp then return end
  if not placeOnStartPosition(sp) then
    guihooks.trigger('RaceManagerEditorMsg', { msg = 'Could not move the vehicle' })
  end
end

-- Move a placed gate to where the car is standing, and stand the car on a
-- placed gate. The same pair the starting grid has had all along -- an editor
-- where a marker can be placed but never adjusted means deleting and re-driving
-- the whole route to fix one gate that landed a meter wide.
--
-- Both work on whichever list the editor is pointed at, so they serve the main
-- route, the joker route and the pit stalls without three copies of the code.
-- The gate keeps its own width/height override: this moves it, nothing else.
function M.moveCheckpoint(index)
  index = math.floor(tonumber(index) or 0)
  local list = activeEditorRoute()
  local wp = list[index]
  if not wp then
    log('W', 'raceManager', 'moveCheckpoint: nothing at index ' .. tostring(index))
    return
  end
  local place = vehiclePlacement()
  if not place then
    guihooks.trigger('RaceManagerEditorMsg', { msg = 'Get in a vehicle first' })
    return
  end
  wp.x, wp.y, wp.z = place.x, place.y, place.z
  wp.hx, wp.hy = place.hx, place.hy
  pushRouteState()
  log('I', 'raceManager', string.format('%s %d moved to the current vehicle',
    edit.target, index))
end

-- Stand the car on a placed gate, facing the way through it, so the creator can
-- see what a driver will see. Never freezes: this is an editor convenience.
function M.previewCheckpoint(index)
  index = math.floor(tonumber(index) or 0)
  local wp = activeEditorRoute()[index]
  if not wp then return end
  if not placeOnStartPosition(wp) then
    guihooks.trigger('RaceManagerEditorMsg', { msg = 'Could not move the vehicle' })
  end
end

-- --- Taking things back -----------------------------------------------------
-- Undo removes the LAST gate, which for a while was the only way to remove one
-- at all: a gate placed out of order, or one missing from the middle, meant
-- undoing back to it and re-driving everything after. These are the three
-- operations that were missing, and they work on whichever list the editor is
-- pointed at, so one implementation serves the main route, the joker route and
-- the pit stalls -- the same reasoning moveCheckpoint is written under.
--
-- Every one of them has to renumber the BRANCH GATES in step. A branch gate
-- addresses its checkpoint by number, so inserting, deleting or moving a main
-- gate changes what those numbers mean; one left un-renumbered silently comes to
-- describe a different corner of the track.
function branch.shiftSlots(from, delta)
  for _, g in ipairs(branch.list) do
    local s = tonumber(g.slot)
    if s and s >= from then g.slot = s + delta end
  end
end

-- Drop the branch gates for a checkpoint that is going away, and say so rather
-- than leaving one pointing at a checkpoint that no longer exists.
function branch.dropSlot(slot)
  local dropped = 0
  for i = #branch.list, 1, -1 do
    if tonumber(branch.list[i].slot) == slot then
      table.remove(branch.list, i)
      dropped = dropped + 1
    end
  end
  return dropped
end

function M.removeCheckpoint(index)
  index = math.floor(tonumber(index) or 0)
  local list = activeEditorRoute()
  if not list[index] then
    log('W', 'raceManager', 'removeCheckpoint: nothing at index ' .. tostring(index))
    return
  end
  table.remove(list, index)
  if edit.target == 'main' then
    local dropped = branch.dropSlot(index)
    branch.shiftSlots(index + 1, -1)
    branch.rebuild()
    if dropped > 0 then
      guihooks.trigger('RaceManagerEditorMsg', {
        msg = 'Checkpoint ' .. index .. ' removed: ' .. dropped
          .. ' branch gate(s) on that slot dropped with it',
      })
    end
    if session.armedWp > #track.route then session.armedWp = math.max(#track.route, 1) end
  elseif edit.target == 'joker' then
    if session.jokerArmed > #track.jokerRoute then session.jokerArmed = math.max(#track.jokerRoute, 1) end
  elseif edit.target == 'branch' then
    branch.rebuild()
    branch.editSlot = branch.nextFreeSlot()
  end
  pushRouteState()
  log('I', 'raceManager', string.format('%s %d removed', edit.target, index))
end

-- Place a gate BEFORE an existing one, at the car. The missing half of "add":
-- a route is driven in order, and noticing a gap after the fact used to cost
-- every gate placed since.
function M.insertCheckpoint(index, place)
  index = math.floor(tonumber(index) or 0)
  local list = activeEditorRoute()
  if index < 1 then index = 1 end
  if index > #list + 1 then index = #list + 1 end
  place = place or vehiclePlacement()
  if not place then
    guihooks.trigger('RaceManagerEditorMsg', { msg = 'Get in a vehicle first' })
    return
  end
  if edit.target ~= 'start' then
    local prev = list[index] or list[#list]
    place.width  = clampWidth(prev and prev.width  or track.checkpointWidth)
    place.height = clampHeight(prev and prev.height or track.checkpointHeight)
    place.depth  = clampDepth(prev and prev.depth  or track.checkpointDepth)
  end
  if edit.target == 'branch' then
    guihooks.trigger('RaceManagerEditorMsg', {
      msg = 'Branch gates are placed against a slot, not in an order',
    })
    return
  end
  table.insert(list, index, place)
  if edit.target == 'main' then
    branch.shiftSlots(index, 1)
    branch.rebuild()
  end
  pushRouteState()
  log('I', 'raceManager', string.format('%s inserted at %d', edit.target, index))
end

-- Move one gate (or grid slot) to a different place in the order. Slot 1 of the
-- grid is pole, so this is also how a grid built in the wrong order is fixed.
function M.reorderCheckpoint(from, to)
  from = math.floor(tonumber(from) or 0)
  to   = math.floor(tonumber(to) or 0)
  local list = activeEditorRoute()
  if not list[from] or from == to then return end
  if to < 1 then to = 1 end
  if to > #list then to = #list end
  local item = table.remove(list, from)
  table.insert(list, to, item)
  if edit.target == 'main' then
    -- The main route's slots moved, so every branch override addressing one of
    -- them has to move with it. Worked out from the shift the item made rather
    -- than re-derived: exactly one slot changed position, everything between
    -- `from` and `to` shifted one step the other way.
    local lo, hi, step = math.min(from, to), math.max(from, to), (from < to) and -1 or 1
    for _, g in ipairs(branch.list) do
      local s = tonumber(g.slot)
      if s == from then g.slot = to
      elseif s and s >= lo and s <= hi then g.slot = s + step end
    end
    branch.rebuild()
  end
  pushRouteState()
  log('I', 'raceManager', string.format('%s %d moved to %d', edit.target, from, to))
end

-- --- Building a grid without driving it -------------------------------------
-- A head-on layout needs two blocks of slots facing opposite ways, and placing
-- them one car at a time is the tedious part of authoring one.

-- The grid generator's own state. One table for the register budget, and
-- because these three genuinely travel together: what was generated, from where,
-- and how far apart -- which is exactly what the sliders need to re-lay it out
-- without the creator driving anywhere again.
branch.gridTool = {
  generated = false,   -- was this grid laid out by the generator?
  anchor    = nil,     -- { x, y, z, hx, hy } the row-1 slot it was built from
  count     = 0,
  spacing   = 8,       -- meters between rows
  stagger   = 6,       -- meters between the cars ACROSS a row
  width     = 2,       -- cars per row
}

-- Lay N slots out from an anchor, back down its heading, `width` cars abreast.
-- Nothing here is novel geometry: it is a placement plus arithmetic on the
-- heading it already carries.
--
-- The row is CENTERD on the anchor, whatever it is made of. Two abreast puts a
-- car half a gap either side of where the creator stood; three puts one on that
-- spot and one either side; one puts every car on it, single file. Centring is
-- what makes the width a free choice -- a row that grew off one edge would walk
-- the whole grid sideways every time it changed, and on an oval it would walk it
-- into the wall.
--
-- `stagger` is the gap between ADJACENT cars across a row, not the distance from
-- some center line. That is the measurement a creator can actually check against
-- the track: it is how much room each car has beside the one next to it.
function branch.layOutGrid(anchor, count, spacing, stagger, width, replace)
  local fx, fy = anchor.hx, anchor.hy
  local rx, ry = fy, -fx        -- the right-hand perpendicular
  width = math.floor(tonumber(width) or 2)
  if width < 1 then width = 1 end
  if width > TUNE.GRID_MAX_WIDTH then width = TUNE.GRID_MAX_WIDTH end
  if replace then track.startPositions = {} end
  local mid = (width - 1) * 0.5
  -- EVERY SLOT FINDS ITS OWN GROUND.
  --
  -- This used to hand every slot `anchor.z` -- the height of wherever the car
  -- generating the grid happened to be standing. On flat ground that is right by
  -- accident. On anything else the grid is a horizontal plane laid through a
  -- hill: the rows behind a car parked on a crest end up inside the slope, and
  -- the rows behind one parked in a dip float above it.
  --
  -- What is preserved is the anchor's height ABOVE THE GROUND, not its absolute
  -- z, so a grid generated from a car sitting on a bridge still sits on the
  -- bridge rather than being dropped into the river.
  local anchorGround = groundAt(anchor.x, anchor.y, anchor.z)
  local lift = anchorGround and (anchor.z - anchorGround) or TUNE.GROUND_CLEAR
  if lift < TUNE.GROUND_CLEAR then lift = TUNE.GROUND_CLEAR end
  for i = 0, count - 1 do
    local row  = math.floor(i / width)
    local col  = i % width
    local back = row * spacing
    local side = (col - mid) * stagger
    local x = anchor.x - fx * back + rx * side
    local y = anchor.y - fy * back + ry * side
    -- Probed from the ANCHOR's height rather than the slot's, because the slot
    -- has no height yet. A probe that starts fifty meters above the anchor still
    -- clears anything the grid is being laid across.
    local g = groundAt(x, y, anchor.z)
    track.startPositions[#track.startPositions + 1] = {
      x  = x,
      y  = y,
      z  = g and (g + lift) or anchor.z,
      hx = fx, hy = fy,
    }
  end
end

-- Generate a grid.
--
-- `from` picks the anchor: a slot number uses that ALREADY PLACED start position
-- and its heading, and anything else uses the car. Anchoring on a placed slot is
-- what makes the sliders below work -- pole is a decision the creator makes once,
-- by standing on it, and everything after it is arithmetic.
-- NOT M.generateGrid. That name belongs to the admin control further down this
-- file which asks the SERVER to form the race grid -- it teleports the whole
-- field onto its slots and holds them for the countdown. Lua assignment is
-- last-one-wins and that one is defined later, so a start-position generator
-- called generateGrid was simply erased at load: pressing Generate Slots sent
-- RM_GenerateGrid and started the race instead.
--
-- The same collision happened one layer up, in app.js, and was renamed there
-- first -- which fixed nothing, because both layers had it.
function M.generateStartPositions(count, spacing, stagger, from, width)
  count   = math.floor(tonumber(count) or 0)
  spacing = tonumber(spacing) or 8
  stagger = tonumber(stagger) or 6
  width   = math.floor(tonumber(width) or 2)
  if width < 1 then width = 1 end
  if width > TUNE.GRID_MAX_WIDTH then width = TUNE.GRID_MAX_WIDTH end
  if count < 1 then return end
  if count > 60 then count = 60 end

  local anchor, replace
  local slot = math.floor(tonumber(from) or 0)
  if track.startPositions[slot] then
    -- Rebuild the grid from an existing slot, keeping everything before it.
    local sp = track.startPositions[slot]
    anchor = { x = sp.x, y = sp.y, z = sp.z, hx = sp.hx, hy = sp.hy }
    for i = #track.startPositions, slot, -1 do table.remove(track.startPositions, i) end
    replace = false
  else
    anchor = vehiclePlacement()
    if not anchor then
      guihooks.trigger('RaceManagerEditorMsg', { msg = 'Get in a vehicle first' })
      return
    end
    replace = false
  end

  branch.layOutGrid(anchor, count, spacing, stagger, width, replace)
  -- Remembered so the sliders can re-lay the same grid out without the creator
  -- driving back to pole to do it.
  branch.gridTool.generated = true
  branch.gridTool.anchor    = anchor
  branch.gridTool.count     = count
  branch.gridTool.spacing   = spacing
  branch.gridTool.stagger   = stagger
  branch.gridTool.width     = width
  pushRouteState()
  guihooks.trigger('RaceManagerEditorMsg', {
    msg = 'Generated ' .. count .. ' start positions, ' .. width .. ' abreast ('
      .. spacing .. 'm between rows, ' .. stagger .. 'm across)',
  })
  log('I', 'raceManager', 'Generated ' .. count .. ' start positions, '
    .. width .. ' abreast')
end

-- Re-lay the generated grid out at a new spacing. What the sliders drive.
--
-- Only ever touches a grid this generator built, and only the slots it built:
-- respacing a grid somebody placed by hand would throw their work away, and the
-- sliders are hidden until there is a generated one to move.
function M.respaceGrid(spacing, stagger, width)
  if not branch.gridTool.generated or not branch.gridTool.anchor then return end
  spacing = tonumber(spacing) or branch.gridTool.spacing
  stagger = tonumber(stagger) or branch.gridTool.stagger
  width   = math.floor(tonumber(width) or branch.gridTool.width)
  if spacing < 1 then spacing = 1 end
  if spacing > 60 then spacing = 60 end
  if stagger < 0 then stagger = 0 end
  if stagger > 30 then stagger = 30 end
  if width < 1 then width = 1 end
  if width > TUNE.GRID_MAX_WIDTH then width = TUNE.GRID_MAX_WIDTH end
  -- The slots this generator owns are the last `count` of them; anything placed
  -- before the generate stays exactly where the creator put it.
  local keep = #track.startPositions - branch.gridTool.count
  if keep < 0 then keep = 0 end
  -- HEADINGS SURVIVE THE MOVE. A heading belongs to the slot, and respacing moves
  -- slots rather than replacing them.
  --
  -- This is what makes a head-on grid survive a slider. One is generated as a
  -- single block with half of it turned around, and the way a car faces is now
  -- the ONLY thing saying which direction that driver races. Re-laying from the
  -- anchor alone would face every car the anchor's way again, so nudging a
  -- slider would silently un-turn half the field and the two directions would
  -- set off together.
  local held = {}
  for i = keep + 1, #track.startPositions do
    local sp = track.startPositions[i]
    held[i - keep] = sp and { hx = sp.hx, hy = sp.hy } or nil
  end
  for i = #track.startPositions, keep + 1, -1 do table.remove(track.startPositions, i) end
  branch.layOutGrid(branch.gridTool.anchor, branch.gridTool.count,
    spacing, stagger, width, false)
  for i = 1, branch.gridTool.count do
    local sp, was = track.startPositions[keep + i], held[i]
    if sp and was and was.hx and was.hy then sp.hx, sp.hy = was.hx, was.hy end
  end
  -- Changing the width re-flows the SAME slots into different rows -- slot 5 of a
  -- three-wide grid is row 2 where it was row 3 two-wide -- and the headings above
  -- follow the slot, not the row. That is the right way round: a head-on grid is
  -- turned round "from slot 7 on", and it stays that way whatever shape the rows
  -- are.
  branch.gridTool.spacing = spacing
  branch.gridTool.stagger = stagger
  branch.gridTool.width   = width
  pushRouteState()
end

-- Turn a range of grid slots around. Build one block, then flip half of it: the
-- head-on grid without driving the second half of it.
function M.flipStartPositions(from, to)
  from = math.floor(tonumber(from) or 1)
  to   = math.floor(tonumber(to) or #track.startPositions)
  if from < 1 then from = 1 end
  if to > #track.startPositions then to = #track.startPositions end
  local n = 0
  for i = from, to do
    local sp = track.startPositions[i]
    if sp then
      sp.hx, sp.hy = -(sp.hx or 0), -(sp.hy or 1)
      n = n + 1
    end
  end
  pushRouteState()
  guihooks.trigger('RaceManagerEditorMsg', { msg = 'Turned ' .. n .. ' start position(s) around' })
end

-- NOTHING TAGS A GRID SLOT WITH A DIRECTION any more, which is why there is no
-- stripeStartLanes or setStartLane here.
--
-- Splitting a head-on field used to mean dealing lane tags across the grid so the
-- server could tell each driver which way they were racing. A start position
-- already points the car somewhere, and every gate for the next checkpoint is
-- armed for everybody, so the direction a driver goes is settled by the slot they
-- are standing on and nothing has to be told about it. Turn half the grid round
-- with Flip and the field is split.

function M.setCheckpointWidth(w)
  track.checkpointWidth = clampWidth(w)
  pushRouteState()
end

function M.setCheckpointHeight(h)
  track.checkpointHeight = clampHeight(h)
  pushRouteState()
end

function M.setCheckpointDepth(d)
  track.checkpointDepth = clampDepth(d)
  pushRouteState()
end

-- Per-checkpoint override editor. index is 1-based into the placed route; a
-- nil/blank/non-positive value for a dimension clears that override so the gate
-- falls back to the global default. Pass both blank to fully reset a gate.
function M.setCheckpointOverride(index, w, h, d)
  index = math.floor(tonumber(index) or 0)
  local wp = activeEditorRoute()[index]
  if not wp then
    log('W', 'raceManager', 'setCheckpointOverride: no checkpoint at index ' .. tostring(index))
    return
  end
  -- Blank means inherit, and for width and height a zero is blank: neither has
  -- any meaning at zero.
  local function opt(v, clamp)
    v = tonumber(v)
    if not v or v <= 0 then return nil end
    return clamp(v)
  end
  wp.width  = opt(w, clampWidth)
  wp.height = opt(h, clampHeight)
  -- DEPTH IS DIFFERENT, and reusing `opt` for it was a bug: zero is a real
  -- depth, a gate that stops dead at the surface, and `opt` treats zero as blank
  -- and substitutes the session default. So a depth of 0 could not be set at
  -- all. Only nil and a non-number mean inherit here.
  local dv = tonumber(d)
  wp.depth = dv and clampDepth(dv) or clampDepth(track.checkpointDepth)
  pushRouteState()
end

-- The local scratch route file (editorSave/editorLoad) is gone. Loading it
-- rebuilt the route while emptying the joker route and the grid, so a Load there
-- followed by a Save here overwrote a server layout with a partial one. Server
-- layouts are the only copy now.
-- Diagnostic for the in-game Lua console:
--   dump(raceManager.nudgeStatus())
-- Answers "why will nudge mode not turn on" without reading the log: which
-- engine pieces resolved, and whether a cursor call actually succeeded.
function M.nudgeStatus()
  local gaps = nudge.missing()
  return {
    on          = nudge.on,
    selected    = nudge.sel,
    usable      = #gaps == 0,
    missing     = gaps,
    imgui       = nudge.im ~= nil,
    rayCast     = type(cameraMouseRayCast) == 'function',
    mouseRay    = type(getCameraMouseRay) == 'function',
    canvas      = nudge.canvas() ~= nil,
    lockMouse   = type(lockMouse) == 'function',
    -- nil here means the build has no isCursorOn to ask, so turning the mode off
    -- leaves the cursor free rather than guessing.
    cursorProbe = nudge.cursorFree(),
    cursorWasFree = nudge.wasFree,
    editorOpen  = edit.open,
    isAdmin     = session.isAdmin,
  }
end

-- Admin: show the field a flag. Advisory, and the server is what decides
-- whether this session is in a state to be flagged at all.
-- Put yourself in or out of the field. Their own participation, so no admin
-- rights are involved; the server enforces the one rule that matters, which is
-- that you cannot rejoin a session already under way.
-- Pull out of the session you are in. A classified retirement, not a
-- disappearance: the server keeps you in the results and scores you like any
-- other DNF.
function M.retire()
  if inMultiplayer() then TriggerServerEvent('RM_Retire', '') end
end

function M.setSpectating(on)
  if inMultiplayer() then
    TriggerServerEvent('RM_SetSpectating', jsonEncode({ spectating = on == true }))
  end
end

-- ---------------------------------------------------------------------------
-- Broadcast camera: put the view on a named driver
-- ---------------------------------------------------------------------------
-- The spectator board sends a BeamMP PLAYER id, not a vehicle id, and that is
-- the whole reason this function exists on the client at all. A vehicle id is a
-- local scene-object id: it means a different car on every machine, so nothing
-- that travels between clients can carry one. A pid is the key the server files
-- everyone under and the key RM_Ghost already crosses the wire with, and
-- resolving it to a car is a question only the local client can answer.
--
-- IT SETS THE CAMERA MODE, which is the one place in this file that does.
-- Everywhere else the rule is the opposite and bindCameraToOwnVehicle spells it
-- out: which car you are attached to is the mod's business, how you look at it
-- is the driver's. This is the exception because here the view IS the request. A
-- broadcaster clicking a name is asking to be put on that car in a chase
-- camera; landing them in whatever seat they last used -- a cockpit, or a bumper
-- cam pointing at somebody else's boot -- is not what they clicked.
--
-- Not gated on being a spectator. It moves a camera and touches no session
-- state, and the board that calls it only renders for somebody watching; a rule
-- here would be a second opinion about a question the server already owns.
function M.spectateDriver(pid)
  pid = tonumber(pid)
  if pid == nil then return false end
  -- Our own row goes through ownVehicle(), not the pid lookup. vehicleForPid
  -- walks MPVehicleGE's list, which is about OTHER people's cars -- and
  -- ownVehicle is the answer this file already trusts for "which one is mine",
  -- including offline, where there is no MPVehicleGE to ask.
  local veh = nil
  if pid == localServerId() then veh = ownVehicle() end
  if not veh then veh = ghost.vehicleForPid(pid) end
  if not veh then
    -- A car not loaded here yet is the ordinary case for a driver who has only
    -- just joined, and saying nothing about it reads as a dead row.
    pushNotice('spectate', 'No car on this client for that driver yet')
    guihooks.trigger('RaceManagerWatch', { pid = pid, ok = false })
    return false
  end
  -- FREE CAM FIRST. enterVehicle attaches the player to a car; free cam is a
  -- camera that does not care which car that is, so from inside it the click
  -- would appear to do nothing at all.
  if commands and commands.isFreeCamera and commands.setGameCamera then
    local inFree = false
    pcall(function () inFree = commands.isFreeCamera() == true end)
    if inFree then pcall(commands.setGameCamera) end
  end
  local switched = false
  if be and be.enterVehicle then
    switched = pcall(function () be:enterVehicle(0, veh) end)
  end
  if switched and core_camera and core_camera.setByName then
    pcall(core_camera.setByName, 0, 'orbit')
  end
  -- Reported either way, so the board marks the row the camera actually landed
  -- on rather than the row that was clicked. Those differ whenever the switch
  -- fails, and a board marking the wrong car is worse than one marking none.
  guihooks.trigger('RaceManagerWatch', { pid = pid, ok = switched })
  log('I', 'raceManager', 'Broadcast camera -> pid ' .. tostring(pid)
    .. (switched and '' or ' FAILED (enterVehicle unavailable)'))
  return switched
end

function M.setFlag(f)
  f = tostring(f or '')
  if f ~= 'green' and f ~= 'yellow' and f ~= 'red' then return end
  if inMultiplayer() then TriggerServerEvent('RM_SetFlag', jsonEncode({ flag = f })) end
end

function M.setNudgeMode(on)
  nudge.set(on == true or on == 'true')
end

function M.editorToggleVisualize()
  edit.visualize = not edit.visualize
  pushRouteState()
end

-- ---------------------------------------------------------------------------
-- Track layouts (server-side, persistent, per-map)
-- ---------------------------------------------------------------------------
-- Unlike editorSave/editorLoad (a single local scratch file), named layouts
-- live on the BeamMP server in layouts.json, keyed by map, and survive server
-- restarts. Saving bundles the currently placed checkpoints; loading is pushed
-- by the server to every client at once via RM_ApplyLayout.
local function editorMsg(msg)
  guihooks.trigger('RaceManagerEditorMsg', { msg = msg })
end

-- `confirmDrop` is the admin having accepted that this save empties a section
-- the stored layout has. Without it the server holds the save and answers with
-- RM_SaveHeld. See the silent-drop guard there.
function M.saveLayout(name, confirmDrop)
  name = tostring(name or ''):gsub('^%s+', ''):gsub('%s+$', '')
  print('[raceManager] saveLayout("' .. name .. '") with ' .. #track.route .. ' checkpoint(s)')
  if name == '' then
    log('W', 'raceManager', 'saveLayout: no layout name given, nothing sent')
    editorMsg('Enter a layout name first')
    return
  end
  if #track.route == 0 then
    log('W', 'raceManager', 'saveLayout: no checkpoints placed, nothing sent')
    editorMsg('Place checkpoints before saving a layout')
    return
  end
  if not inMultiplayer() then
    log('W', 'raceManager', 'saveLayout: not connected to a BeamMP server, nothing sent')
    editorMsg('Layouts need a BeamMP server (use Save/Load for offline routes)')
    return
  end
  -- Bundle a sanitized copy of the route: plain numeric fields only, so the
  -- payload always JSON-encodes as the flat checkpoint array the server's
  -- sanitizeCheckpoints expects (never vec3 userdata or stray keys).
  local function bundle(src, what)
    local out = {}
    for i, wp in ipairs(src) do
      local x, y, z = tonumber(wp.x), tonumber(wp.y), tonumber(wp.z)
      if not (x and y and z) then
        log('E', 'raceManager', 'saveLayout: ' .. what .. ' checkpoint ' .. i
          .. ' has non-numeric coordinates, aborting')
        editorMsg('Save failed: ' .. what .. ' checkpoint ' .. i .. ' is invalid')
        return nil
      end
      out[i] = { x = x, y = y, z = z, hx = tonumber(wp.hx) or 0, hy = tonumber(wp.hy) or 1 }
      -- Carry per-checkpoint overrides through only when set.
      if tonumber(wp.width)  then out[i].width  = clampWidth(wp.width)   end
      if tonumber(wp.height) then out[i].height = clampHeight(wp.height) end
      if tonumber(wp.depth)  then out[i].depth  = clampDepth(wp.depth)   end
      if wp.oneWay == true   then out[i].oneWay = true end
      -- A marker's SYMBOL is the only thing that distinguishes one from
      -- another, so it travels with the geometry. Validated on the way out
      -- rather than trusted: a layout carrying kind = "banana" would draw
      -- nothing at all on reload, and silently.
      if wp.kind ~= nil then out[i].kind = marker.validKind(wp.kind) or 'right' end
    end
    return out
  end
  local cps = bundle(track.route, 'route')
  if not cps then return end
  -- The joker route rides along with the layout so a rallycross track is a
  -- single saved object. Omitted entirely when no joker gates are placed.
  local jokerCps = nil
  if #track.jokerRoute > 0 then
    jokerCps = bundle(track.jokerRoute, 'joker')
    if not jokerCps then return end
  end
  -- The starting grid travels with the layout too: a track is its gates AND
  -- where the cars line up.
  local starts = nil
  if #track.startPositions > 0 then
    starts = bundle(track.startPositions, 'start position')
    if not starts then return end
  end
  -- The branch gates travel with the layout, like the joker route and the grid: a
  -- head-on oval is one saved object, not a circuit an admin has to remember to
  -- rebuild the other half of. Bundled by hand rather than through `bundle`
  -- because a branch gate carries the checkpoint it belongs to, which is the
  -- whole point of it.
  local alts = nil
  if #branch.list > 0 then
    alts = {}
    for i, g in ipairs(branch.list) do
      local x, y, z, slot = tonumber(g.x), tonumber(g.y), tonumber(g.z), tonumber(g.slot)
      if not (x and y and z and slot) then
        log('E', 'raceManager', 'saveLayout: branch gate ' .. i .. ' is invalid, aborting')
        editorMsg('Save failed: branch gate ' .. i .. ' is invalid')
        return
      end
      local out = {
        slot = math.floor(slot), x = x, y = y, z = z,
        hx = tonumber(g.hx) or 0, hy = tonumber(g.hy) or 1,
      }
      if tonumber(g.width)  then out.width  = clampWidth(g.width)   end
      if tonumber(g.height) then out.height = clampHeight(g.height) end
      if tonumber(g.depth)  then out.depth  = clampDepth(g.depth)   end
      if g.oneWay == true   then out.oneWay = true end
      alts[#alts + 1] = out
    end
    if #alts == 0 then alts = nil end
  end
  local payload = jsonEncode({
    name        = name,
    width       = clampWidth(track.checkpointWidth),
    height      = clampHeight(track.checkpointHeight),
    depth       = clampDepth(track.checkpointDepth),
    checkpoints = cps,
    joker       = jokerCps,
    startPositions = starts,
    branches       = alts,
    -- Does this grid sit away from the start/finish line? Inferred rather than
    -- asked for: an admin who placed the grid somewhere else has already said so
    -- by placing it there, and a switch they have to remember is one they will
    -- forget. A head-on layout always trips it, because two directions cannot
    -- share one row of slots.
    gridOffLine    = branch.gridIsOff(),
    pits           = bundle(track.pitRoute, 'pit stall') or {},
    -- The lane's mouth and its exit travel with the layout like every other
    -- gate set. Empty tables rather than nil: the server sanitises either into
    -- the same thing, and a layout that loses its entry gate on a re-save would
    -- put the whole lane back on screen for the rest of the race.
    pitEntry       = bundle(track.pitEntry, 'pit entry') or {},
    pitExit        = bundle(track.pitExit, 'pit exit') or {},
    -- Signage rides with the track it points around. A stage without its
    -- markers is a stage nobody can follow, so they are part of the layout
    -- rather than something placed again every session.
    markers        = bundle(marker.list, 'marker') or {},
    -- Whether this track is a sprint stage or a circuit is a property of the
    -- TRACK, so it is stored with it. An admin who built a point-to-point stage
    -- should not have to remember to set it again every race night.
    pointToPoint   = track.pointToPoint,
    confirmDrop    = confirmDrop == true,
  })
  print('[raceManager] saveLayout: sending RM_SaveLayout (' .. #payload .. ' bytes) to server')
  TriggerServerEvent('RM_SaveLayout', payload)
end

function M.requestLayouts()
  if inMultiplayer() then TriggerServerEvent('RM_RequestLayouts', '') end
end

function M.loadLayout(name, forEditing)
  name = tostring(name or '')
  if name == '' then return end
  if not inMultiplayer() then
    editorMsg('Layouts need a BeamMP server')
    return
  end
  -- PRESSING LOAD IS THE ADMIN SAYING YES.
  --
  -- The buffer guard exists to stop somebody ELSE's layout landing on unsaved
  -- work; it must never stop the admin loading one deliberately. Standing it
  -- down here rather than special-casing the reply keeps the guard itself with
  -- no notion of who asked, which is the only reason it stays this small.
  --
  -- It clears whether or not the load succeeds. A refused or missing layout
  -- leaves the buffer exactly as it was, and the next apply re-stamps it.
  edit.stamp   = nil
  edit.refused = nil
  -- `forEditing` asks for the PRIVATE load: the server sends the layout back to
  -- this client alone and leaves the raced track, the grid and the joker count
  -- where they are. Without it this is the public load it has always been, and
  -- the whole server moves onto the track.
  --
  -- Sent as nil rather than false when unset, so an older server that has never
  -- heard of the flag sees exactly the payload it used to get.
  TriggerServerEvent('RM_LoadLayout', jsonEncode({
    name       = name,
    forEditing = forEditing and true or nil,
  }))
end

-- Admin: open or close a saved layout for practice.
--
-- Allowed while a session is under way, unlike the other layout commands: it
-- changes nothing about the running race, only what a driver may pull up on
-- their own afterwards.
function M.setLayoutPractice(name, on)
  name = tostring(name or '')
  if name == '' then return end
  if not inMultiplayer() then
    editorMsg('Layouts need a BeamMP server')
    return
  end
  TriggerServerEvent('RM_SetLayoutPractice', jsonEncode({
    name = name, practice = on == true,
  }))
end

-- --- Free practice ---------------------------------------------------------

-- Pull up an approved track to practice on. Any player, admin or not.
--
-- The same RM_LoadLayout event with a different flag, rather than a channel of
-- its own: it is the same question ("send me this track"), and the server
-- answers it the same targeted way. What differs is what it is allowed to do,
-- and the server decides that -- this end cannot approve its own layout.
function M.practiceLayout(name)
  name = tostring(name or '')
  if name == '' then return end
  if not inMultiplayer() then
    editorMsg('Practice needs a BeamMP server')
    return
  end
  TriggerServerEvent('RM_LoadLayout', jsonEncode({ name = name, forPractice = true }))
end

-- How many laps the driver wants. 0 (or blank) is unlimited, which is the
-- default: practice with a target is the unusual case.
function M.setPracticeLaps(n)
  practice.lapTarget = math.max(0, math.floor(tonumber(n) or 0))
  pushRouteState()
end

-- Stop practising. The gates stay drawn -- the track is still loaded, and a
-- driver who has stopped timing has not stopped looking at where it goes.
function M.endPractice()
  practice.on = false
  practice.lapsDone = 0
  timingReset()
  pushNotice('session', 'Practice ended')
  pushRouteState()
end

-- The server has put this client on a practice track.
local function onPractice(rawData)
  -- rawData, NOT data. Every handler in the DISPATCH table below is handed the
  -- raw JSON string off the wire and decodes it itself. Taking a table here
  -- meant the real payload -- a string -- failed the type check and returned,
  -- so practice never switched on: the gates rendered exactly as they always do
  -- outside a session, and nothing was ever armed.
  --
  -- The test did not catch it because it called this handler with a table
  -- directly, which a decode-first handler also accepts (the harness's
  -- jsonDecode is the identity function). It passed because it had been written
  -- against the same mistake.
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then return end
  practice.on     = data.on == true
  practice.layout = data.layout
  practice.lapsDone = 0
  session.localLap  = 1
  session.lapStart  = localTime
  session.armedWp   = 1
  timingReset()
  if practice.on then
    -- STAND THE CAR ON THE GRID BEFORE TIMING ANYTHING.
    --
    -- Practice starts from wherever the driver happens to be, which on a track
    -- they have just loaded is usually nowhere near it -- so the first lap was
    -- the drive out to the circuit plus a lap, timed as one, and the delta on
    -- lap two was meaningless. Placing them on a start position makes lap one a
    -- lap.
    --
    -- Through the same queue the grid and the derby use: ghosted, dropped, and
    -- solid again once it has settled. NOT held: a hold is a starting
    -- procedure, and there is nobody to be fair to.
    --
    -- No start positions saved with the track is not an error. Plenty of
    -- layouts have none, and the driver is simply left where they are.
    if #track.startPositions > 0 then
      queueFieldPlacement({
        slot  = 1,
        slots = track.startPositions,
        hold  = false,
        holdSource = 'practice',
        order = 1, count = 1,     -- one car, no field to stagger behind
      })
    end
    pushNotice('session', 'PRACTICE: ' .. tostring(data.layout or 'track')
      .. ' -- your laps are timed for you only')
  end
  pushRouteState()
end

function M.deleteLayout(name)
  name = tostring(name or '')
  if name == '' then return end
  if not inMultiplayer() then
    editorMsg('Layouts need a BeamMP server')
    return
  end
  TriggerServerEvent('RM_DeleteLayout', jsonEncode({ name = name }))
end

-- Console helper: creates a one-gate circuit (a bare start/finish line).
-- raceManager.setFinishLine(x, y, z [, headingX, headingY])
function M.setFinishLine(x, y, z, hx, hy)
  local len = math.sqrt((hx or 0) ^ 2 + (hy or 0) ^ 2)
  if len > 1e-4 then hx, hy = hx / len, hy / len else hx, hy = 0, 1 end
  track.route = { { x = x, y = y, z = z, hx = hx, hy = hy } }
  session.armedWp = 1
  pushRouteState()
end

-- ---------------------------------------------------------------------------
-- The editor is closed while a session is running
-- ---------------------------------------------------------------------------
-- ENFORCED, not asked for. Every function below mutates the route buffer, and
-- until now not one of them checked anything: the only thing standing between a
-- driver at speed and a gate moving under them was an ng-disabled attribute in
-- the panel. Those attributes tested for 'countdown' and 'racing' and missed
-- QUALIFYING in all fourteen places, so the entire editor was live for the whole
-- of every qualifying session.
--
-- Wrapped in one pass over a list rather than a guard pasted into twenty-two
-- functions, because the guard pasted into twenty-two functions is how the
-- fourteenth one gets forgotten. A new editor action is covered by adding its
-- name here, and an action that is NOT in this list is one that does not touch
-- the buffer -- the previews, the visualisation toggle and the panel's own
-- open/closed state are all deliberately absent, since blocking those would
-- stop an admin looking at a track they are not allowed to change.
--
-- saveLayout, loadLayout and deleteLayout are absent too, and that is not an
-- oversight: the SERVER refuses those mid-session on its own terms, and its
-- terms are not quite these (it permits a load while a grid is formed). Copying
-- the rule here would silently change which of them work.
for _, name in ipairs({
  'editorAdd', 'editorUndo', 'editorClear', 'setFinishLine',
  'moveCheckpoint', 'removeCheckpoint', 'insertCheckpoint', 'reorderCheckpoint',
  'setCheckpointWidth', 'setCheckpointHeight', 'setCheckpointDepth',
  'setCheckpointOverride', 'setPointToPoint',
  'moveStartPosition', 'removeStartPosition',
  'generateStartPositions', 'respaceGrid', 'flipStartPositions',
  'setBranchSlot', 'setBranchGateSlot', 'removeBranchGate',
  'nudgeTurn', 'nudgeLift', 'nudgeDelete',
}) do
  local inner = M[name]
  -- A name that is not there is a typo in the list above, and a silent one:
  -- wrapping nil would replace the function with a guard that returns nothing
  -- and the action would simply stop working. Say so at load instead.
  if type(inner) ~= 'function' then
    log('E', 'raceManager', 'editor guard: no such action "' .. name .. '"')
  else
    M[name] = function (...)
      if not edit.canConfigure() then
        editorMsg('Not while a session is running: end it first.')
        return
      end
      return inner(...)
    end
  end
end

-- ---------------------------------------------------------------------------
-- Server -> client
-- ---------------------------------------------------------------------------
-- SCOPED, and that is not cosmetic. Lua allows 200 locals per function, the top
-- level of this file IS a function, and it was within a couple of that ceiling
-- -- going over is not a warning, the file does not compile and the whole mod is
-- simply absent. The limit counts locals that are ACTIVE AT ONCE, so a `do ...
-- end` block hands its registers back at `end` while the closures defined inside
-- keep the values alive as upvalues.
--
-- Everything from here to the bottom of the file is the server -> client half:
-- twenty-odd handlers, the dispatch table that routes to them, the teardown and
-- the session hooks. Nothing above needs any of it by name -- the handlers are
-- reached through DISPATCH and the lifecycle through M -- so the whole tail
-- costs the outer function nothing.
do
local function onServerUpdate(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then return end
  if not fromCurrentServer(data) then return end

  -- League regulations arrive with every state broadcast (Modules 1 & 2).
  if type(data.maxResets) == 'number' then session.maxResets = math.floor(data.maxResets) end
  if data.resetMode == 'checkpoint' or data.resetMode == 'inplace' then
    session.resetMode = data.resetMode
  end
  if type(data.youSpectating) == 'boolean' then selfSpectating = data.youSpectating end
  session.jokerEnabled = data.jokerEnabled == true
  -- THE PACE LAP, and the notice on its edge.
  --
  -- Announced from here rather than from the phase change below, because the
  -- phase does not change: a pace lap IS the racing phase, released under
  -- yellow. The flag notice a line further down fires too and says YELLOW FLAG,
  -- which is true and is not the instruction -- "caution, race back to the line"
  -- is the opposite of what a driver forming up should do. This one is pushed
  -- second so it is the one left on screen.
  local wasPacing = session.pacing
  session.paceLap = data.paceLap == true
  session.pacing  = data.pacing == true
  -- The caution, and its own notice on the edge. The yellow flash a line below
  -- says CAUTION already, but "race back to the line" is what an advisory
  -- yellow means and it is the opposite of what a neutralised race wants -- so
  -- the caution's own instruction is pushed over the top of it.
  local wasCaution = session.caution
  local wasPending = session.cautionPending
  local wasRestart = session.restartPending
  session.caution = data.caution == true
  session.cautionPending = data.cautionPending == true
  session.restartPending = data.restartPending == true
  if type(data.cautionLaps) == 'number' then session.cautionLaps = data.cautionLaps end
  -- The heat program, and only the parts the lap target needs. The panel gets
  -- the rest straight off the broadcast; this side wants the distance because it
  -- is the side that waves the white and checkered flags.
  session.heatCount   = tonumber(data.heatCount) or 0
  session.heatCurrent = tonumber(data.heatCurrent) or 0
  session.heatLaps    = tonumber(data.heatLaps) or 0
  -- The flag, and a notice the moment it CHANGES. A caution that only appears
  -- on a panel is a caution the driver watching the road never sees.
  local wasFlag = session.raceFlag
  if data.flag == 'green' or data.flag == 'yellow' or data.flag == 'red' then
    session.raceFlag = data.flag
  end
  if session.raceFlag ~= wasFlag and sessionRunning() then
    -- The instruction moves to the second line and the flag itself becomes the
    -- headline. On a full-panel flash the first line is what gets read at
    -- speed, and "RED FLAG" is the part that has to survive a glance.
    if session.raceFlag == 'red' then
      pushNotice('flag', 'RED FLAG',
        { sub = 'Stop where you are and wait', color = 'red' })
    elseif session.raceFlag == 'yellow' then
      pushNotice('flag', 'YELLOW FLAG',
        { sub = 'Caution: race back to the line', color = 'yellow' })
    else
      pushNotice('flag', 'GREEN FLAG', { sub = 'Racing', color = 'green' })
    end
  end
  -- ...and the pace lap's own, over the top of the yellow it was released under.
  -- Both units, because this is a league with drivers on both sides of the
  -- Atlantic and a speed half the grid has to convert is a speed half the grid
  -- guesses at.
  if session.pacing and not wasPacing then
    pushNotice('flag', 'PACE LAP',
      { sub = 'Hold position - 40 mph / 64 km/h', color = 'yellow' })
  end
  -- THREE EDGES, THREE DIFFERENT INSTRUCTIONS, and the order they are written in
  -- is the order a driver meets them. Collapsing them into one CAUTION notice is
  -- how a driver ends up holding station on a lap they were supposed to race
  -- back on, or coasting through a green they were never warned about.
  if session.cautionPending and not wasPending then
    pushNotice('flag', 'CAUTION - RACE BACK TO THE LINE',
      { sub = 'Positions lock as you complete this lap', color = 'yellow' })
  end
  if session.caution and not wasCaution then
    pushNotice('flag', 'CAUTION',
      { sub = 'Hold position, no overtaking - places are frozen', color = 'yellow' })
  elseif session.restartPending and not wasRestart then
    -- The one warning that matters under a caution: the green is coming, and it
    -- is coming at the line rather than whenever the marshal pressed a button.
    pushNotice('flag', 'RESTART THIS LAP',
      { sub = 'Green as the leader reaches the line - get ready', color = 'green' })
  elseif wasRestart and not session.restartPending and session.caution then
    pushNotice('flag', 'RESTART WAVED OFF',
      { sub = 'Stay under caution, hold your position', color = 'yellow' })
  elseif wasCaution and not session.caution and sessionRunning() then
    -- The restart gets its own word rather than leaving the plain GREEN FLAG
    -- notice to carry it: coming out of a caution is the one green a driver has
    -- to be READY for, and "racing" does not say that.
    pushNotice('flag', 'RESTART - GREEN FLAG',
      { sub = 'Racing resumes', color = 'green' })
  end
  -- Per-player admin status. Present only on a targeted reply (RM_RequestState),
  -- so the global broadcast never disturbs it. The server is the authority here:
  -- if it says this session is not authenticated, the local flag is wrong and
  -- gets corrected (server restart, or an admin logged out from elsewhere).
  if type(data.youAreAdmin) == 'boolean' and data.youAreAdmin ~= session.isAdmin then
    session.isAdmin = data.youAreAdmin
    guihooks.trigger('RaceManagerAuth', { success = session.isAdmin, restored = true })
    pushRouteState()
  end
  -- The qualifying clock has expired and this driver is on their last lap. Read
  -- off the state broadcast rather than a one-shot event, so a client that joins
  -- or reconnects mid-final-lap is told too - but announced only on the EDGE, or
  -- a 3 Hz broadcast would repeat the notice several times a second.
  local wasFinalLap = finalLap
  finalLap = data.finalLap == true
  if finalLap and not wasFinalLap then
    -- Same flag, two sessions, and the sentence has to say which. In qualifying
    -- the clock expiring IS the final lap; in a race this is the checkered flag
    -- falling after the leader is already home.
    pushNotice('session', session.phase == 'qualifying'
      and 'TIME EXPIRED: FINAL LAP. Your session ends as you cross the line.'
      or  'CHECKERED FLAG: the winner is home. Your race ends as you cross the line.')
  end

  -- TIMED RACE, both edges. Read off the state broadcast for the same reason
  -- finalLap is: a client that joins or reconnects mid-race is told, and the
  -- edge test is what keeps a 3 Hz broadcast from repeating the notice several
  -- times a second.
  local wasExpired, wasLastLap = session.raceExpired, session.lastLapNum
  session.raceExpired = data.raceExpired == true
  session.lastLapNum  = (type(data.lastLapNum) == 'number') and data.lastLapNum or nil
  if type(data.raceMode) == 'string' then session.raceMode = data.raceMode end
  if session.raceExpired and not wasExpired and not session.lastLapNum then
    pushNotice('session', 'TIME UP: the FINAL LAP starts when the leader takes the line.')
  end
  if session.lastLapNum and not wasLastLap then
    pushNotice('session', 'FINAL LAP: finish lap ' .. session.lastLapNum .. ' to take the flag.')
  end
  -- Race entry + qualifying rules.
  if type(data.pointToPoint) == 'boolean' then track.pointToPoint = data.pointToPoint end
  ghostQuali = data.ghostQuali == true
  qualiOutLap = data.qualiOutLap == true
  if type(data.qualiLapLimit)  == 'number' then qualiLapLimit  = data.qualiLapLimit  end
  if type(data.qualiTimeLimit) == 'number' then qualiTimeLimit = data.qualiTimeLimit end
  -- Reset-ghosting rules are the server's, so every client in a league runs the
  -- same numbers rather than whatever its own copy of the mod was shipped with.
  -- Re-anchor the shared clock every push. Ghost end times are expressed on it.
  if type(data.raceTime) == 'number' then ghost.serverTime = data.raceTime end
  if type(data.ghostOnReset) == 'boolean' then ghost.rules.onReset = data.ghostOnReset end
  if type(data.ghostMinSec)  == 'number'  then ghost.rules.minSec  = data.ghostMinSec  end
  if type(data.ghostMaxSec)  == 'number'  then ghost.rules.maxSec  = data.ghostMaxSec  end
  -- Authoritative per-vehicle ghost state, carried on the state broadcast for
  -- the same reason finalLap is: it is what makes a client that joined (or
  -- reconnected) DURING a ghost see it, instead of only clients that happened to
  -- be listening when the one-shot event went out.
  if type(data.ghosts) == 'table' then ghost.applyRoster(data.ghosts) end
  -- The finished-driver ghosts. Applied unconditionally when the key is present,
  -- INCLUDING when it is empty: an empty list is the un-ghost at the flag, and
  -- skipping it would leave the field intangible for the rest of the session.
  if type(data.ghostFinished) == 'table' then
    ghost.applyFinishedRoster(data.ghostFinished)
  end
  -- Whether we turned up in the middle of somebody else's session, read off our
  -- own driver row. ghostUpdate acts on this: a car that is not in the race is a
  -- ghost to the cars that are.
  local myId = localServerId()
  local wasLapped  = session.beingLapped
  local wasLapping = session.lappingAhead
  session.beingLapped, session.lappingAhead = false, false
  -- WHICH HEAT WE WERE DRAWN INTO, off the same row. On the session table rather
  -- than in a local of its own for the reason everything else here is: this file
  -- is close enough to Lua's 200-local ceiling that a new one is a real cost, and
  -- the ceiling fails by making the whole mod vanish with no error.
  session.myHeat = nil
  if myId and type(data.drivers) == 'table' then
    for _, d in ipairs(data.drivers) do
      if tonumber(d.id) == myId then
        isBystander = d.bystander == true
        -- The blue flag rides on the row rather than on a field of its own,
        -- because it is a fact about ONE driver and this loop is already here
        -- looking for that driver. A top-level field would be a second walk of
        -- the same array, or a targeted send per driver, for two booleans.
        session.beingLapped  = d.blue == true
        session.lappingAhead = d.lapping == true
        session.myHeat       = tonumber(d.heat)
        break
      end
    end
  end
  -- TOLD ON THE EDGE, both of them. The flag itself sits in the header for as
  -- long as it applies (see driverFlag), but a driver whose eyes are on the road
  -- is not reading the header -- and this is the one instruction in the mod that
  -- is aimed at somebody who is, by definition, about to be caught.
  if session.beingLapped and not wasLapped and sessionRunning() then
    pushNotice('flag', 'BLUE FLAG',
      { sub = 'Faster car a lap up behind you - let them by', color = 'blue' })
  end
  -- The other half, and it is not a flag: no series waves anything at the car
  -- doing the lapping. It is a heads-up, so it goes on the strip rather than
  -- flashing over the road -- the driver it is aimed at is the one with room to
  -- read it.
  if session.lappingAhead and not wasLapping and sessionRunning() then
    pushNotice('session', 'Backmarker ahead: they are being shown the blue flag')
  end

  -- Display names on BeamMP's nametags. The switch is the server's so every
  -- client agrees; the suffix itself is applied locally, because a nametag is
  -- drawn on each machine out of that machine's own player list.
  if type(data.nametags) == 'boolean' and data.nametags ~= nametag.on then
    nametag.on = data.nametags
    if not nametag.on then nametag.clearAll() end
  end
  if type(data.drivers) == 'table' then nametag.apply(data.drivers) end

  -- Fastest lap of the session. The leaderboard paints that driver's time gold
  -- for everyone; the driver who set it is told, once, on the notice channel the
  -- reset and joker rulings already use.
  --
  -- Keyed on the TIME as well as the holder. Keying on the holder alone meant a
  -- driver who beat their own fastest lap was told nothing -- the pid had not
  -- changed -- which is the one case where the driver is most likely to want to
  -- know they did it. Every state broadcast carries the standing best, so what
  -- distinguishes "they set a new one" from "this is the same one again" is the
  -- time moving, and that is what is compared.
  local bestPid  = tonumber(data.bestLapPid)
  local bestTime = tonumber(data.bestLapTime)
  if bestPid ~= lastBestLapPid or bestTime ~= lastBestLapTime then
    if bestPid and myId and bestPid == myId and bestTime then
      local mins = math.floor(bestTime / 60)
      pushNotice('fastest', 'FASTEST LAP', {
        sub = string.format('%d:%06.3f', mins, bestTime - mins * 60),
      })
    end
    lastBestLapPid  = bestPid
    lastBestLapTime = bestTime
  end

  local newPhase = data.phase or 'waiting'
  local phaseChanged = newPhase ~= session.phase
  if newPhase ~= session.phase then
    session.phase = newPhase
    -- Any session transition re-arms local detection from a clean slate:
    -- lap 1 starts at the line, from the grid, for both kinds of session.
    resetLapTracking()
    -- A session that owes an out lap says so at the moment the lights go out.
    -- The lap readout carries it for the whole lap; this is the one push that
    -- arrives while the driver is still stationary and reading.
    --
    -- BOTH SESSION KINDS, which it did not use to be. onOutLap() dropped its
    -- phase test when a race gridded away from the line started owing one too,
    -- and this push kept it -- so the race case existed ONLY as the server's
    -- chat line, on the reasoning that chat "reaches a driver who has not opened
    -- the app". It does not reach one who has not opened chat, which is most of
    -- them. The two branches mirror the server's two exactly.
    if qualiOutLap and newPhase == 'qualifying' then
      pushNotice('session',
        'OUT LAP: this lap is NOT timed. Timing starts as you cross the line.')
    end
    -- THE RACING BRANCH IS GONE ON PURPOSE. It read "Your first lap COUNTS but
    -- is not timed", which is a distinction about the RESULTS table shown to a
    -- driver on the grid, where the only question is when to go. Qualifying
    -- keeps its notice because there the lap genuinely does not count and a
    -- driver pushing on the out lap is wasting one.
    --
    -- Put it back by restoring the `elseif qualiOutLap and newPhase == 'racing'`
    -- arm; the server's matching line in notifyField came out with it.
    -- Leaving the start procedure must never leave a car frozen.
    if newPhase ~= 'grid' and newPhase ~= 'countdown' then releaseGridHold('race') end
    if newPhase ~= 'grid' and newPhase ~= 'countdown' and not sessionRunning() then
      session.gridSlot = nil
    end
  end
  session.totalLaps = data.totalLaps or session.totalLaps

  -- State broadcasts arrive several times a second while racing; only re-push
  -- the route/entry state to the UI when something in it actually moved.
  -- (resetLapTracking already pushes on a phase change.)
  -- THE FLAG RIDES THIS BROADCAST, which arrives three times a second.
  --
  -- It used to travel only on pushRouteState, which fires on edits and events
  -- and not on any clock, so calling a caution changed the flag on the client
  -- and the panel went on showing the old one until something unrelated pushed
  -- route state. Logging out and back in is such a thing, which is why that
  -- looked like the cure.
  data.driverFlag = driverFlag()
  guihooks.trigger('RaceManagerUpdate', data)
end

-- Server assigned this client a starting slot (Generate Grid, or an admin
-- editing the order). Stand the car on it and hold it for the countdown.
local function onGridAssign(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then return end
  local slot = tonumber(data.slot)
  applyGridSlot(slot and math.floor(slot) or nil, tonumber(data.order), tonumber(data.count))
end

-- A ghost started or ended on some client. This is the one-shot companion to the
-- roster carried on the state broadcast, and it exists for latency alone: the
-- state push runs three times a second, and a third of a second is long enough
-- for a car to teleport into a pack and be hit before anyone's client had been
-- told it was a ghost. The roster is what makes the state RIGHT; this is what
-- makes it right IN TIME.
--
-- Our own ghost is ignored here. We applied it locally the instant the reset
-- fired, without waiting for this round trip, and only we can decide when it
-- ends.
-- A car is coming back on a derby life: make it intangible for a few seconds on
-- THIS client, whoever's car it is -- our own included, which is the difference
-- between this and the field-wide reasons. Those mean "everyone else is a
-- ghost"; this one means "that car is", and the driver it belongs to needs it
-- most of all.
--
-- Going solid again still goes through ghost.reason's weld gate, so the few
-- seconds are a floor rather than a promise: a car with somebody inside it at
-- the end of them waits, and is retried, until the space is actually clear.
function ghost.onDerbyRespawn(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then return end
  local pid = data.pid
  if pid == nil then return end
  local seconds = tonumber(data.seconds) or 0
  if seconds <= 0 then return end
  local veh, vehId
  if tostring(pid) == tostring(localServerId()) then
    veh = ownVehicle()
    vehId = veh and vehicleId(veh) or nil
  else
    veh, vehId = ghost.vehicleForPid(pid)
  end
  if not vehId then return end
  ghost.respawn[vehId] = seconds
  ghost.reason(vehId, 'derbyRespawn', true, veh)
  log('I', 'raceManager', ('Derby respawn ghost: vehicle %s for %.1fs')
    :format(tostring(vehId), seconds))
end

-- Tick those countdowns. Its own pass rather than a branch inside the ghost
-- sweep: this is the only ghost in the mod measured on the local clock, and
-- folding it into machinery that reasons about the server's would invite
-- somebody to "tidy" it onto the wrong one.
function ghost.respawnUpdate(dt)
  if next(ghost.respawn) == nil then return end
  for vehId, left in pairs(ghost.respawn) do
    left = left - dt
    if left <= 0 then
      ghost.respawn[vehId] = nil
      ghost.reason(vehId, 'derbyRespawn', false)
    else
      ghost.respawn[vehId] = left
    end
  end
end

local function onGhost(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then return end
  local pid = data.pid
  if pid == nil then return end
  if tostring(pid) == tostring(localServerId()) then return end
  local startedAt = tonumber(data.startedAt)
  local duration  = tonumber(data.duration)
  local endsAt    = nil
  if data.active ~= false and startedAt and duration then
    endsAt = startedAt + duration
  end
  ghost.applyRemote(pid, endsAt)
end

-- The server has seen this car off its grid slot and is pulling it back. The
-- server owns the hold; this is it exercising that, and it arrives whether or
-- not the local guard did its job - which is the point of having it.
local function onHoldCorrect(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then data = {} end
  if not holdWanted then return end
  -- The server may know the slot coordinates when this client's view of them is
  -- stale (a layout loaded after this client joined). Prefer what it sends.
  if tonumber(data.x) and tonumber(data.y) and tonumber(data.z) then
    -- The SLOT, not the anchor: this is a drop position, and the car has to be
    -- allowed to settle onto it exactly as it did when it was first placed.
    hold.slot   = vec3(tonumber(data.x), tonumber(data.y), tonumber(data.z))
    hold.anchor = nil
    if tonumber(data.hx) and tonumber(data.hy) then
      hold.rot = headingRot(tonumber(data.hx), tonumber(data.hy))
    end
  end
  hold.correctLeft = 0        -- a server correction is never rate-limited away
  hold.restore('server correction: ' .. tostring(data.reason or 'moved off the grid'))
  pushNotice('grid', 'Held on the grid, wait for the lights')
end

-- THE SERVER HAS GIVEN THIS DRIVER A LAP. The free pass under a caution, today;
-- anything that credits a lap without a crossing, tomorrow.
--
-- IT IS NOT A NOTIFICATION, it is a correction, and skipping it would break more
-- than a message. localLap is this client's own lap counter: it stamps every
-- progress report (the server DROPS any whose lap number disagrees with its
-- own), it decides the joker lap number, and it is what the white and checkered
-- flags are waved off. Leaving it a lap behind the server would silently kill
-- this driver's live position and gap for the rest of the race and then hand
-- them their flags a lap late.
--
-- The server sends the lap it has arrived at rather than a delta, so a message
-- that goes missing is corrected by the next one instead of compounding.
local function onLapCredit(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then return end
  local lap = math.floor(tonumber(data.lap) or 0)
  if lap <= 0 or lap == session.localLap then return end
  session.localLap = lap
  if data.reason == 'luckydog' then
    pushNotice('flag', 'FREE PASS - YOU GET YOUR LAP BACK',
      { sub = 'Restart at the tail of the lead lap', color = 'green' })
  else
    pushNotice('session', 'Lap credited: you are on lap ' .. lap)
  end
  log('I', 'raceManager', 'Server credited a lap: now on lap ' .. lap
    .. ' (' .. tostring(data.reason or 'no reason given') .. ')')
end

-- The server has something to tell this driver, on the channel they can read.
-- Routed straight through pushNotice, so it reaches the panel's strip and the
-- game's own HUD by exactly the same path as every notice raised locally --
-- there is no second presentation to keep in step.
local function onNotice(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then return end
  local msg = data.msg and tostring(data.msg) or ''
  if msg == '' then return end
  pushNotice(tostring(data.kind or 'session'), msg,
    { sub = data.sub and tostring(data.sub) or nil })
end

-- --- Module 1: forced spectator mode (server -> client) --------------------
-- 1st, 2nd, 3rd, 4th. The teens are the trap and they are why this is a function
-- rather than a lookup on the last digit: 11th, 12th and 13th take "th" while 21st,
-- 22nd and 23rd do not.
local function ordinal(n)
  n = math.floor(tonumber(n) or 0)
  if n <= 0 then return tostring(n) end
  local suffix = 'th'
  local last, teen = n % 10, n % 100
  if teen < 11 or teen > 13 then
    if last == 1 then suffix = 'st'
    elseif last == 2 then suffix = 'nd'
    elseif last == 3 then suffix = 'rd' end
  end
  return tostring(n) .. suffix
end

-- Exposed for tests/ghost_test.lua. The teens rule is easy to get wrong and easy
-- to regress, and it is not reachable through any other entry point.
M.ordinalForTest = ordinal

local function onForceSpectate(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then data = {} end
  local source = data.source and tostring(data.source) or 'race'
  enterSpectator(data.reason and tostring(data.reason) or nil, source)
  -- The placement toast. A MOMENT, so it is a transient notice: the standing
  -- itself is on the leaderboard and the checkered flag is the persistent half
  -- of saying the race is over for this driver.
  -- THE CHECKERED FLAG, for this driver, once.
  --
  -- Every driver gets one as they finish, including a backmarker taking it long
  -- after the leader: this fires off that driver's own removal from the session,
  -- not off the race being decided. A derby elimination is not a finish and has
  -- an overlay of its own, so it is left out here exactly as it is in
  -- driverFlag().
  --
  -- The placing rides along as the second line rather than as a notice of its
  -- own. Two arriving together would rank the flag first and hold the placing
  -- behind it for six seconds, which is a strange way to tell somebody they won.
  if source ~= 'derby' and not flags.checkered then
    flags.checkered = true
    local place = tonumber(data.place)
    local placed = (place and place > 0) and ('You placed ' .. ordinal(place)) or nil
    if flags.checkeredSeen then
      -- The flag was already waved on the approach, seconds ago. Saying it again
      -- the instant they cross is the same news twice; what they do not know yet
      -- is where they came.
      if placed then
        pushNotice('finish', placed)
      end
    else
      -- No approach flash happened: the driver was retired by something other
      -- than crossing the line (time expired, a DNF, an admin ending it), so
      -- this is the first and only time they see it.
      pushNotice('flag', 'CHECKERED FLAG', { sub = placed, color = 'checkered' })
    end
  end
end

local function onReleaseSpectate(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then data = {} end
  local source = data.source and tostring(data.source) or nil
  local order, count = tonumber(data.order), tonumber(data.count)
  -- The server snapshots the participant list before releasing anyone and hands
  -- each driver its place in it, so the field respawns as a sequence.
  if session.spectatorLock then
    releaseSpectator(source, order, count)
    return
  end
  -- Nothing of OURS to put back -- this driver never lost their car, because
  -- they were still running when the session ended. They are released all the
  -- same, and the rest of the field is about to materialise around them, so
  -- they get the placement ghost for the same window everyone else does.
  --
  -- Without this the only cars ghosted through an end-of-session respawn were
  -- the ones being respawned. A driver sitting on track was the one solid
  -- object in the middle of a field landing on top of them.
  if queueFieldPlacement then
    queueFieldPlacement({ order = order, count = count })
  end
end

-- --- Module 4: the server refused this client's vehicle/setup --------------
--
-- Two outcomes on one event. `remove` is the ordinary case: the car goes, here,
-- because the server cannot delete it itself (see deleteOwnVehicleNow). Without
-- it the driver is told the setup is illegal and keeps driving it, which is what
-- the whole feature was doing before.
--
-- `remove` false is the ADMIN case. An admin who is also racing gets the same
-- message and the same audit entry on the server, and keeps their car: they
-- have to be able to drive an unapproved setup to capture it in the first
-- place. Told, listed, not kicked.
local function onVehicleRejected(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  local msg = (ok and type(data) == 'table' and data.message)
    and tostring(data.message) or 'Vehicle/Setup not allowed in this session.'
  local detail = (ok and type(data) == 'table' and data.detail) and tostring(data.detail) or ''
  local remove = ok and type(data) == 'table' and data.remove == true
  guihooks.trigger('RaceManagerVehicleError', { message = msg, detail = detail })
  -- The detail rides as `sub` so the HUD copy carries it. The notice strip
  -- shows only `msg` (sub is a flash-template field), and the red banner above
  -- already prints the detail on its own line, so nothing is lost by it.
  pushNotice('vehicle', msg, { sub = detail ~= '' and detail or nil })
  local gone = false
  if remove then gone = deleteOwnVehicleNow() end
  log('W', 'raceManager', 'Vehicle rejected by the server: ' .. msg .. ' (' .. detail .. ')'
    .. (remove and (gone and ' [car deleted]' or ' [CAR NOT DELETED]') or ' [advisory only]'))

  -- WHICH REJECTION IS THIS? There are two, they look identical from the panel,
  -- and they need opposite fixes.
  --
  -- If the car is declaring exactly what was captured, the signature is stable
  -- and the Garage List simply does not hold this car -- a different vehicle, a
  -- different map's entry, or a list captured before the last change to how a
  -- signature is built. Re-capturing fixes it.
  --
  -- If it has MOVED, the identity is drifting under an untouched car, and no
  -- amount of re-capturing will ever hold. That was the bug for most of a day
  -- and it must never be diagnosed by guesswork again.
  if garage.lastCaptured then
    if garage.lastDeclared == garage.lastCaptured then
      log('W', 'raceManager', 'The car is declaring exactly what was captured ('
        .. tostring(garage.lastCaptured) .. '), so its identity is STABLE: this '
        .. 'is a Garage List that does not contain this car')
    else
      log('E', 'raceManager', 'THE SIGNATURE MOVED since it was captured. '
        .. 'captured: ' .. tostring(garage.lastCaptured)
        .. ' | declaring: ' .. tostring(garage.lastDeclared)
        .. ' -- re-capturing will not hold while it keeps moving')
    end
  else
    log('W', 'raceManager', 'Nothing was captured from this client, so there is '
      .. 'nothing to compare: whitelist this car (with enforcing OFF) and the '
      .. 'next rejection will say whether its identity holds still')
  end
end

-- Server confirmed (or refused) a Whitelist Current Vehicle capture.
-- Server ruled on an alias change. Surfaced as a notice so the admin always
-- gets an answer -- the name applied, or why it did not.
local function onAliasResult(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then return end
  local msg = tostring(data.message or '')
  if msg == '' then return end
  pushNotice(data.success == true and 'alias' or 'vehicle', msg)
  log('I', 'raceManager', 'Alias result: ' .. msg)
end

local function onGarageResult(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then return end
  editorMsg(tostring(data.message or ''))
  guihooks.trigger('RaceManagerGarageResult', data)
end

local function onServerCountdown(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then return end
  -- GO (0) or an aborted countdown (-1): the grid hold ends here. This is the
  -- authoritative release - everyone's car is let go by the same broadcast, so
  -- nobody can creep away early or be held a moment longer than their rivals.
  local count = tonumber(data.count)
  if count and count <= 0 then releaseGridHold('race') end
  guihooks.trigger('RaceManagerCountdown', data)
end

-- Map-filtered layout list from the server (includes checkpoint arrays so the
-- UI can draw the 2D track preview before anything is loaded).
local function onLayoutList(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then
    log('E', 'raceManager', 'RM_Layouts: undecodable payload: ' .. tostring(rawData):sub(1, 120))
    return
  end
  -- An empty list can arrive JSON-encoded as {} instead of []; hand the UI a
  -- real array either way so its iteration/preview code never breaks.
  if type(data.layouts) ~= 'table' or #data.layouts == 0 then data.layouts = {} end
  log('I', 'raceManager', 'RM_Layouts: ' .. #data.layouts .. ' layout(s) for map ' .. tostring(data.map))
  guihooks.trigger('RaceManagerLayouts', data)
end

-- Cup standings and scoring rules, on their own channel.
--
-- A pure relay, and it stays one: the cup is decided entirely on the server,
-- this client owns nothing about it and caches nothing. There is no physics
-- here to police and no local rule to mirror, which is exactly why the cup
-- needs none of the machinery the derby needs.
local function onCupUpdate(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then
    log('E', 'raceManager', 'RM_CupUpdate: undecodable payload')
    return
  end
  if not fromCurrentServer(data) then return end
  -- Empty arrays can arrive JSON-encoded as {} rather than []; hand the UI a
  -- real array either way so an ng-repeat never sees an object.
  for _, key in ipairs({ 'standings', 'presets', 'bonuses', 'roster', 'connected',
                         'racePoints', 'derbyPoints', 'qualiPoints' }) do
    if type(data[key]) ~= 'table' or #data[key] == 0 then data[key] = {} end
  end
  guihooks.trigger('RaceManagerCup', data)
end

-- Server pushed a layout to everyone: purge the current track state, then
-- spawn the saved gates immediately.
local function onApplyLayout(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' or type(data.checkpoints) ~= 'table' then
    log('E', 'raceManager', 'RM_ApplyLayout: undecodable payload: ' .. tostring(rawData):sub(1, 120))
    return
  end
  local function unbundle(src, what)
    local out = {}
    for i, cp in ipairs(src) do
      local x, y, z = tonumber(cp.x), tonumber(cp.y), tonumber(cp.z)
      if not (x and y and z) then
        log('E', 'raceManager', 'RM_ApplyLayout: ' .. what .. ' checkpoint ' .. i
          .. ' has invalid coordinates, layout rejected')
        return nil
      end
      out[i] = { x = x, y = y, z = z, hx = tonumber(cp.hx) or 0, hy = tonumber(cp.hy) or 1 }
      -- A gate saved before sizes were per-gate has none of its own; it is
      -- given the layout's stored default here, so it keeps exactly the size it
      -- was drawn with and never depends on a live setting again.
      if what ~= 'start position' then
        out[i].width = clampWidth(tonumber(cp.width) or data.width or track.checkpointWidth)
        local h = tonumber(cp.height) or data.height
        local d = tonumber(cp.depth)  or data.depth
        if d == nil and h ~= nil then
          -- A layout saved before height and depth were separate. Back then
          -- height was the FULL span, centerd on the placement point, so half of
          -- it goes each way. Converted HERE, once, as it loads, which means the
          -- gate keeps the exact shape it has always had and the next save
          -- writes it in the new form.
          out[i].height = clampHeight(h * 0.5)
          out[i].depth  = clampDepth(h * 0.5)
        else
          out[i].height = clampHeight(h or track.checkpointHeight)
          out[i].depth  = clampDepth(d or track.checkpointDepth)
        end
      end
    end
    return out
  end
  local cps = unbundle(data.checkpoints, 'route')
  if not cps or #cps == 0 then
    log('E', 'raceManager', 'RM_ApplyLayout: empty or invalid checkpoint list, layout rejected')
    return
  end
  local jokerCps = {}
  if type(data.joker) == 'table' and #data.joker > 0 then
    jokerCps = unbundle(data.joker, 'joker') or {}
  end
  local starts = {}
  if type(data.startPositions) == 'table' and #data.startPositions > 0 then
    starts = unbundle(data.startPositions, 'start position') or {}
  end
  local pits = {}
  if type(data.pits) == 'table' and #data.pits > 0 then
    pits = unbundle(data.pits, 'pit stall') or {}
  end
  local pitIn, pitOut = {}, {}
  if type(data.pitEntry) == 'table' and #data.pitEntry > 0 then
    pitIn = unbundle(data.pitEntry, 'pit entry') or {}
  end
  if type(data.pitExit) == 'table' and #data.pitExit > 0 then
    pitOut = unbundle(data.pitExit, 'pit exit') or {}
  end
  -- Markers, with their symbols. unbundle only carries geometry, so the kind is
  -- re-attached here from the payload and validated on the way in -- a layout
  -- hand-edited to an unknown symbol gets the default rather than a marker that
  -- draws nothing.
  local marks = {}
  if type(data.markers) == 'table' and #data.markers > 0 then
    marks = unbundle(data.markers, 'marker') or {}
    for i = 1, #marks do
      marks[i].kind = marker.validKind(data.markers[i] and data.markers[i].kind) or 'right'
    end
  end
  -- Branch gates, resolved into the per-checkpoint lookup the crossing code
  -- reads. Done ONCE, here, rather than searched per frame: the gates for a
  -- checkpoint have to be found sixty times a second and this is what makes that
  -- one table index.
  --
  -- A gate whose checkpoint does not exist in this layout is DROPPED, not
  -- clamped. Clamping would silently move it to another corner of the track and
  -- arm it there.
  local alts, bySlot = {}, {}
  if type(data.branches) == 'table' then
    for _, g in ipairs(data.branches) do
      local slot = tonumber(g.slot)
      local x, y, z = tonumber(g.x), tonumber(g.y), tonumber(g.z)
      if slot and x and y and z and slot >= 1 and slot <= #cps then
        slot = math.floor(slot)
        local gate = {
          slot = slot, x = x, y = y, z = z,
          hx = tonumber(g.hx) or 0, hy = tonumber(g.hy) or 1,
          width  = clampWidth(tonumber(g.width) or data.width or track.checkpointWidth),
          height = clampHeight(tonumber(g.height) or data.height or track.checkpointHeight),
          depth  = clampDepth(tonumber(g.depth) or data.depth
            or ((tonumber(g.height) or data.height or 0) * 0.5)),
        }
        if g.oneWay == true then gate.oneWay = true end
        alts[#alts + 1] = gate
        local at = bySlot[slot]
        if not at then at = {}; bySlot[slot] = at end
        at[#at + 1] = gate
      end
    end
  end

  -- REFUSED WHILE THE LOCAL EDITOR HOLDS THE BUFFER. See edit.holdsBuffer.
  --
  -- Checked here rather than at the top of the handler on purpose: the payload
  -- is validated first, so a malformed broadcast is still rejected as malformed
  -- and never reads as somebody else's layout arriving.
  --
  -- Nothing is queued. The admin either saves what they have and presses Load,
  -- or presses Load to take the server's copy; both go through M.loadLayout,
  -- which stands the guard down for the reply it is expecting. Holding the
  -- payload to apply later would mean applying a layout that may since have
  -- been deleted or overwritten.
  if edit.holdsBuffer() then
    edit.refused = tostring(data.name or '')
    editorMsg('"' .. edit.refused .. '" was loaded on the server. Your unsaved '
      .. 'editor work has been kept: Save it, or press Load to take the server\'s.')
    log('W', 'raceManager', 'RM_ApplyLayout("' .. edit.refused
      .. '") refused: the local editor buffer has unsaved changes')
    return
  end

  clearTrackState('applying layout "' .. tostring(data.name) .. '"')
  track.route      = cps
  track.jokerRoute = jokerCps
  track.pitRoute   = pits
  track.pitEntry   = pitIn
  track.pitExit    = pitOut
  -- A new track is a new lane: whatever the last one had us doing, we are not
  -- in this one's pits until we drive into them.
  pit.inLane = false
  marker.list = marks
  track.startPositions = starts
  branch.list   = alts
  branch.bySlot = bySlot
  branch.gridOffLine = data.gridOffLine == true
  track.checkpointWidth  = clampWidth(data.width or track.checkpointWidth)
  -- The layout's DEFAULT is migrated the same way its gates are, or the two
  -- disagree: every placed gate would keep the shape it always had while a
  -- newly placed one, or one whose override was cleared, took the old full-span
  -- number as a height and stood twice as tall.
  if data.depth == nil and data.height ~= nil then
    track.checkpointHeight = clampHeight(data.height * 0.5)
    track.checkpointDepth  = clampDepth(data.height * 0.5)
  else
    track.checkpointHeight = clampHeight(data.height or track.checkpointHeight)
    track.checkpointDepth  = clampDepth(data.depth or track.checkpointDepth)
  end
  track.pointToPoint     = data.pointToPoint == true
  resetLapTracking()
  -- The buffer now matches what the server handed over, so this is the baseline
  -- every later drift is measured against. Stamped AFTER the whole apply, not
  -- beside the route assignment above: branch.list lands further up and a stamp
  -- taken before it would read as dirty from the moment it was written.
  edit.stamp   = edit.fingerprint()
  edit.refused = nil
  editorMsg('Loaded layout "' .. tostring(data.name) .. '" ('
    .. (track.pointToPoint and 'point to point, ' or '') .. #track.route .. ' gates'
    .. (#track.jokerRoute > 0 and (' + ' .. #track.jokerRoute .. ' joker') or '')
    .. (#track.startPositions > 0 and (', ' .. #track.startPositions .. ' grid slots') or '') .. ')')
  log('I', 'raceManager', 'Applied server layout "' .. tostring(data.name)
    .. '" with ' .. #track.route .. ' checkpoints, ' .. #track.jokerRoute .. ' joker gates and '
    .. #track.startPositions .. ' start positions')
end

-- The server refused an overwrite that would have emptied part of a layout. The
-- UI asks the admin and re-sends confirmed if that is what they meant.
local function onSaveHeld(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then return end
  local lost = type(data.lost) == 'table' and data.lost or {}
  local label = {
    joker = 'joker gates', pits = 'pit stalls',
    pitEntry = 'pit entry gates', pitExit = 'pit exit gates',
    startPositions = 'start positions', branches = 'branch gates',
  }
  local parts = {}
  for key, n in pairs(lost) do
    parts[#parts + 1] = tostring(n) .. ' ' .. (label[key] or key)
  end
  table.sort(parts)
  guihooks.trigger('RaceManagerSaveHeld', {
    name = tostring(data.name or ''),
    lost = lost,
    summary = table.concat(parts, ', '),
  })
  log('W', 'raceManager', 'Save held back: overwriting "' .. tostring(data.name)
    .. '" would drop ' .. table.concat(parts, ', '))
end

-- Server ordered a full purge (server startup, pre-layout-load, or an
-- explicit clear): delete every checkpoint and its 3D poles right now.
local function onClearTrack(rawData)
  local reason = 'server'
  local ok, data = pcall(jsonDecode, rawData)
  if ok and type(data) == 'table' and data.reason then reason = tostring(data.reason) end
  -- THE OTHER DOOR INTO THE SAME BUG, and the more destructive of the two.
  --
  -- A server-side layout load purges every client BEFORE it broadcasts the new
  -- gates, so an admin editing elsewhere took the wipe here and the refusal in
  -- onApplyLayout, and was left holding an EMPTY editor. Guarding the apply
  -- alone would have turned "your work was replaced" into "your work is gone",
  -- which is worse than the bug being fixed.
  if edit.holdsBuffer() then
    log('W', 'raceManager', 'RM_ClearTrack (' .. reason
      .. ') refused: the local editor buffer has unsaved changes')
    return
  end
  clearTrackState('server: ' .. reason)
  -- The buffer belongs to the server again, so the stamp it was measured
  -- against is meaningless. Dropping it is what stops the APPLY that follows a
  -- load-purge being refused against a fingerprint this purge just invalidated:
  -- an open but CLEAN editor would otherwise be wiped by the clear, read as
  -- dirty a moment later, and refuse the very layout it was waiting for.
  edit.stamp = nil
end

-- Server replied to a login attempt: forward the success flag to the UI, which
-- reveals the admin controls on success and shows a rejection otherwise.
local function onLoginResult(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  if not ok or type(data) ~= 'table' then return end
  -- Remember it here as well as telling the UI: the UI's copy dies with the
  -- app, this one outlives the pause menu.
  session.isAdmin = data.success == true
  -- `lapsed` means this was not an answer to a login attempt: the server refused
  -- a command because the session is no longer authenticated. Worth saying out
  -- loud, because from the panel it looks exactly like the mod has stopped
  -- working rather than like being logged out.
  guihooks.trigger('RaceManagerAuth', { success = session.isAdmin, lapsed = data.lapsed == true })
  if data.lapsed == true then
    pushNotice('server', 'Admin session expired: log in again to run the session')
  end
  log('I', 'raceManager', 'Login result: ' .. tostring(session.isAdmin)
    .. (data.lapsed == true and ' (session lapsed)' or ''))
end

-- Server broadcast that an admin rotated the master password (never the value).
local function onPasswordChanged(rawData)
  local ok, data = pcall(jsonDecode, rawData)
  local by = (ok and type(data) == 'table' and data.changedBy) and tostring(data.changedBy) or 'an admin'
  editorMsg('Admin password changed by ' .. by)
  -- Dedicated channel so the admin bar can confirm the change even when the
  -- editor panel (where editorMsg is shown) isn't open.
  guihooks.trigger('RaceManagerPasswordChanged', { by = by })
  log('I', 'raceManager', 'Master password changed by ' .. by)
end

-- ---------------------------------------------------------------------------
-- Admin authentication (called by the UI app)
-- ---------------------------------------------------------------------------
-- Submit the master password to the server. The reply (RM_LoginResult) drives
-- the UI show/hide of the admin controls via the RaceManagerAuth guihook.
function M.login(password)
  if inMultiplayer() then
    TriggerServerEvent('RM_Login', jsonEncode({ password = tostring(password or '') }))
  else
    -- Offline: no server to authenticate against, but the checkpoint editor is
    -- meant to stay usable single-player, so grant local admin outright. Recorded
    -- here too, so the offline editor also survives the pause menu.
    session.isAdmin = true
    guihooks.trigger('RaceManagerAuth', { success = true, offline = true })
    pushRouteState()
  end
end

-- Drop admin rights (UI "Log out" / back-to-login). Offline there is no server
-- session to clear, so this is purely a UI-side action there.
function M.logout()
  -- Clear the durable copy FIRST. If it stayed set, the next route push would
  -- hand admin straight back to the UI that just logged out.
  session.isAdmin = false
  if inMultiplayer() then TriggerServerEvent('RM_Logout', '') end
  pushRouteState()
end

-- Authenticated admin rotates the master password on the server.
function M.changePassword(newPassword)
  newPassword = tostring(newPassword or '')
  if newPassword == '' then
    editorMsg('Enter a new password first')
    return
  end
  if inMultiplayer() then
    TriggerServerEvent('RM_ChangePassword', jsonEncode({ password = newPassword }))
  end
end

-- ---------------------------------------------------------------------------
-- Session commands (called by the UI app) -- all go to the server
-- ---------------------------------------------------------------------------
function M.startQualifying()
  if inMultiplayer() then TriggerServerEvent('RM_StartQualifying', '') end
end

function M.generateGrid()
  if inMultiplayer() then TriggerServerEvent('RM_GenerateGrid', '') end
end

-- Admin sets or clears a driver's display alias (presentation only). Passed
-- straight through to the server, which validates it and owns the result; this
-- client keeps no alias state of its own and never uses one as a key.
function M.setAlias(targetId, alias)
  -- BeamMP player ids are ZERO-BASED: the first player on the server is id 0.
  -- Rejecting `<= 0` therefore throws away a perfectly real driver, which is
  -- exactly what made Set do nothing at all for the first player to join --
  -- the row rendered, the click fired, and the command died here. Only a
  -- missing/non-numeric id or a negative one is invalid.
  targetId = tonumber(targetId)
  if not targetId then
    log('W', 'raceManager', 'setAlias: no target driver id')
    return
  end
  targetId = math.floor(targetId)
  if targetId < 0 then
    log('W', 'raceManager', 'setAlias: invalid target driver id ' .. tostring(targetId))
    return
  end
  if not inMultiplayer() then
    editorMsg('Display names need a BeamMP server')
    return
  end
  -- Logged on the way out so the game console (~) shows the attempt. If this
  -- line appears and no result notice follows, the request left this client and
  -- the server plugin did not answer -- which points at the server side, not
  -- the app.
  log('I', 'raceManager', string.format('setAlias -> driver %d = "%s"', targetId, tostring(alias or '')))
  TriggerServerEvent('RM_SetAlias', jsonEncode({
    target = targetId,
    alias  = tostring(alias or ''),
  }))
end

function M.setTotalLaps(n)
  n = math.floor(tonumber(n) or 0)
  if n < 1 then return end
  if inMultiplayer() then
    TriggerServerEvent('RM_SetTotalLaps', jsonEncode({ laps = n }))
  end
end

-- Module 1: how many vehicle resets each driver gets this session.
-- A negative value (or nil) means unlimited; 0 forbids resets entirely.
function M.setMaxResets(n)
  n = math.floor(tonumber(n) or -1)
  if n < 0 then n = -1 end
  if inMultiplayer() then
    TriggerServerEvent('RM_SetMaxResets', jsonEncode({ maxResets = n }))
  else
    session.maxResets = n
    pushRouteState()
  end
end

-- Module 1: what a legal reset does while racing - repair in place (default)
-- or respawn at the last checkpoint the driver crossed.
function M.setResetMode(mode)
  mode = (tostring(mode or 'inplace') == 'checkpoint') and 'checkpoint' or 'inplace'
  if inMultiplayer() then
    TriggerServerEvent('RM_SetResetMode', jsonEncode({ mode = mode }))
  else
    session.resetMode = mode
    pushRouteState()
  end
end

-- Module 5: arm/disarm the pace lap. With it on, the race is started with Start
-- Race rather than Start Countdown: the field is released under yellow and the
-- green falls as the leader comes back to the line.
function M.setPaceLap(enabled)
  enabled = enabled and true or false
  if inMultiplayer() then
    TriggerServerEvent('RM_SetPaceLap', jsonEncode({ enabled = enabled }))
  else
    session.paceLap = enabled
    pushRouteState()
  end
end

-- Module 2: arm/disarm the joker lap requirement for the next race.
function M.setJokerEnabled(enabled)
  enabled = enabled and true or false
  if inMultiplayer() then
    TriggerServerEvent('RM_SetJokerEnabled', jsonEncode({ enabled = enabled }))
  else
    session.jokerEnabled = enabled
    pushRouteState()
  end
end

-- --- Qualifying rules ------------------------------------------------------
-- Ghost mode: rivals stop being obstacles during qualifying.
-- Display names on BeamMP nametags. A thin relay like every other setting: the
-- server holds the switch so all clients agree, and each client does the local
-- half when the broadcast comes back.
function M.setNametags(enabled)
  if inMultiplayer() then
    TriggerServerEvent('RM_SetNametags',
      jsonEncode({ enabled = enabled and true or false }))
  end
end

function M.setGhostQuali(enabled)
  enabled = enabled and true or false
  if inMultiplayer() then
    TriggerServerEvent('RM_SetGhostQuali', jsonEncode({ enabled = enabled }))
  else
    ghostQuali = enabled
    pushRouteState()
  end
end

-- Session length: a lap count, a time limit, or neither (0 = unlimited).
-- A race runs to a lap count or to a clock, never both. Sending 0 seconds is
-- what puts it back on laps, which is exactly what the panel's mode toggle does.
-- `mode` is 'laps', 'timed' or 'endurance'. Sent explicitly rather than left to
-- be inferred from which number is non-zero, because endurance has BOTH set and
-- there is no reading of two numbers that tells it apart from the other two.
function M.setRaceLimits(laps, seconds, mode)
  laps    = math.max(math.floor(tonumber(laps) or 0), 0)
  seconds = math.max(math.floor(tonumber(seconds) or 0), 0)
  mode    = tostring(mode or '')
  if mode ~= 'laps' and mode ~= 'timed' and mode ~= 'endurance' then mode = 'laps' end
  if inMultiplayer() then
    TriggerServerEvent('RM_SetRaceLimits',
      jsonEncode({ laps = laps, seconds = seconds, mode = mode }))
  end
end

function M.setQualiLimits(laps, seconds)
  laps    = math.max(math.floor(tonumber(laps) or 0), 0)
  seconds = math.max(math.floor(tonumber(seconds) or 0), 0)
  if inMultiplayer() then
    TriggerServerEvent('RM_SetQualiLimits', jsonEncode({ laps = laps, seconds = seconds }))
  end
end

-- --- Starting grid ---------------------------------------------------------
-- How the server fills the grid: quali order, a random draw, or an order the
-- admin sets by hand.
function M.setGridMode(mode)
  mode = tostring(mode or 'quali')
  -- Every mode the server accepts has to be named here too. This list was left
  -- behind when reverse grids were added, so pressing Reverse normalized to
  -- 'quali' on the way out and the panel lit Quali back up -- a dead button that
  -- looked like it had picked the wrong one.
  if mode ~= 'random' and mode ~= 'custom' and mode ~= 'reverse'
     and mode ~= 'heats' and mode ~= 'points' and mode ~= 'pointsrev' then
    mode = 'quali'
  end
  if inMultiplayer() then
    TriggerServerEvent('RM_SetGridMode', jsonEncode({ mode = mode }))
  end
end

-- Custom grid: put one driver on one slot (the rest shuffle around them).
function M.setDriverGridSlot(pid, slot)
  -- BeamMP player ids are ZERO-BASED, so `pid <= 0` threw away whoever joined
  -- the server first -- the box accepted a slot number and nothing was ever
  -- sent. Slots themselves genuinely are 1-based (slot 1 is pole), so that
  -- half of the guard stays. The server accepts target 0 either way.
  pid  = tonumber(pid)
  slot = tonumber(slot)
  if not pid or not slot then
    log('W', 'raceManager', 'setDriverGridSlot: missing driver id or slot')
    return
  end
  pid, slot = math.floor(pid), math.floor(slot)
  if pid < 0 or slot < 1 then
    log('W', 'raceManager', string.format(
      'setDriverGridSlot: invalid driver id %d or slot %d', pid, slot))
    return
  end
  if inMultiplayer() then
    TriggerServerEvent('RM_SetDriverGrid', jsonEncode({ pid = pid, slot = slot }))
  end
end

function M.startCountdown()
  if inMultiplayer() then TriggerServerEvent('RM_StartCountdown', '') end
end

-- Start the race behind the pace car. The alternative to a countdown rather than
-- a step before one -- the server refuses it unless the pace lap is armed.
function M.startRace()
  if inMultiplayer() then TriggerServerEvent('RM_StartRace', '') end
end

-- Throw a full-course yellow, and end it again. Both are admin controls the
-- server polices; this end only forwards the intention.
function M.caution()
  if inMultiplayer() then TriggerServerEvent('RM_Caution', '') end
end

function M.restart()
  if inMultiplayer() then TriggerServerEvent('RM_Restart', '') end
end

-- Wave a called restart off. Only the CALL goes: the race stays neutralised.
function M.cancelRestart()
  if inMultiplayer() then TriggerServerEvent('RM_CancelRestart', '') end
end

-- The free pass rule: whether the first car a lap down takes its lap back.
function M.setLuckyDog(enabled)
  if inMultiplayer() then
    TriggerServerEvent('RM_SetLuckyDog', jsonEncode({ enabled = enabled == true }))
  end
end

-- Module 6: the heat program. How many heats and how many transfer from each,
-- the draw that splits the field, and which heat is set up next (0 = feature).
function M.setHeats(count, transfer, laps)
  if inMultiplayer() then
    TriggerServerEvent('RM_SetHeats', jsonEncode({
      count    = math.max(0, math.floor(tonumber(count) or 0)),
      transfer = math.max(0, math.floor(tonumber(transfer) or 0)),
      -- 0 is "run the race distance", so it is sent as a value. nil is left out
      -- entirely and the server keeps whatever is already set.
      laps     = laps ~= nil and math.max(0, math.floor(tonumber(laps) or 0)) or nil,
    }))
  end
end

function M.drawHeats()
  if inMultiplayer() then TriggerServerEvent('RM_DrawHeats', '') end
end

-- What the next draw is seeded on: 'quali', 'random' or 'points'. Setting it
-- does not redraw; the draw is its own button.
function M.setHeatDraw(mode)
  if inMultiplayer() then
    TriggerServerEvent('RM_SetHeatDraw', jsonEncode({ mode = tostring(mode or '') }))
  end
end

function M.setHeatCurrent(heat)
  if inMultiplayer() then
    TriggerServerEvent('RM_SetHeatCurrent',
      jsonEncode({ heat = math.max(0, math.floor(tonumber(heat) or 0)) }))
  end
end

function M.endRace()
  if inMultiplayer() then TriggerServerEvent('RM_EndRace', '') end
end

function M.resetLeaderboard()
  if inMultiplayer() then TriggerServerEvent('RM_ResetLeaderboard', '') end
end

-- Clear the server-side results cache (deletes the saved .txt result files).
function M.clearResults()
  if inMultiplayer() then TriggerServerEvent('RM_ClearResults', '') end
end

-- ---------------------------------------------------------------------------
-- Cup / series points (called by the UI app) -- all go to the server
-- ---------------------------------------------------------------------------
-- Thin relays with no local state behind them. The cup is scored, stored and
-- decided entirely on the server; this client only forwards the admin's
-- intention and renders whatever comes back on RM_CupUpdate.
function M.cupRequestState()
  if inMultiplayer() then TriggerServerEvent('RM_CupRequestState', '') end
end

function M.cupSetEnabled(enabled)
  if inMultiplayer() then
    TriggerServerEvent('RM_CupSetEnabled',
      jsonEncode({ enabled = enabled and true or false }))
  end
end

function M.cupStart(name)
  if not inMultiplayer() then
    editorMsg('Cup points need a BeamMP server')
    return
  end
  TriggerServerEvent('RM_CupStart', jsonEncode({ name = tostring(name or '') }))
end

function M.cupReset()
  if inMultiplayer() then TriggerServerEvent('RM_CupReset', '') end
end

-- `target` picks which points table the preset fills: 'race' (the default) or
-- 'derby'. A cup can be all races, all derbies or a mixture, and the two score
-- on separate tables.
function M.cupSetPreset(preset, target)
  if inMultiplayer() then
    TriggerServerEvent('RM_CupSetPreset', jsonEncode({
      preset = tostring(preset or ''),
      target = (tostring(target or 'race') == 'derby') and 'derby' or 'race',
    }))
  end
end

-- Save the race table as a named scoring system, and delete one again. The
-- server holds them beside the live scoring in cup.json, which is deliberately
-- what End Cup does not clear.
function M.cupSavePreset(name)
  if inMultiplayer() then
    TriggerServerEvent('RM_CupSavePreset', jsonEncode({ name = tostring(name or '') }))
  end
end

function M.cupDeletePreset(key)
  if inMultiplayer() then
    TriggerServerEvent('RM_CupDeletePreset', jsonEncode({ preset = tostring(key or '') }))
  end
end

-- A points table arrives from the app as "30,27,25,..." and goes up as an
-- array. A comma-separated string rather than a structure because every other
-- command in this bridge takes numbers and strings, and the app would otherwise
-- have to hand-build a Lua table literal.
--
-- Only the shape is fixed here. Range clamping stays on the server, which has
-- to do it anyway for anything arriving from a client it did not write.
local function cupParsePoints(csv)
  local out = {}
  for field in tostring(csv or ''):gmatch('[^,]+') do
    local n = tonumber(field)
    out[#out + 1] = n and math.floor(n) or 0
  end
  return out
end

-- Each of these sends ONE part of the scoring rules. The server replaces just
-- the part it is given, so a panel that edits the bonus values never has to
-- resend the position table it did not touch.
function M.cupSetRacePoints(csv)
  if inMultiplayer() then
    TriggerServerEvent('RM_CupSetScoring', jsonEncode({ race = cupParsePoints(csv) }))
  end
end

-- Derbies score on a table of their own. An empty string switches derby scoring
-- off, exactly as it does for qualifying.
function M.cupSetDerbyPoints(csv)
  if inMultiplayer() then
    TriggerServerEvent('RM_CupSetScoring', jsonEncode({ derby = cupParsePoints(csv) }))
  end
end

-- The drag ladder's own table, on the same contract: an empty string sends an
-- empty table, which on the server is what "drag racing does not score in this
-- cup" means -- and it means it completely, bonuses included.
function M.cupSetDragPoints(csv)
  if inMultiplayer() then
    TriggerServerEvent('RM_CupSetScoring', jsonEncode({ drag = cupParsePoints(csv) }))
  end
end

-- An empty string is how qualifying points are switched OFF: it sends an empty
-- table, and on the server an empty table is what "qualifying does not score"
-- means. One representation, no separate flag to disagree with it.
function M.cupSetQualiPoints(csv)
  if inMultiplayer() then
    TriggerServerEvent('RM_CupSetScoring', jsonEncode({ quali = cupParsePoints(csv) }))
  end
end

function M.cupSetBonus(key, value)
  key = tostring(key or '')
  if key == '' then return end
  local n = math.floor(tonumber(value) or 0)
  if n < 0 then n = 0 end
  if inMultiplayer() then
    TriggerServerEvent('RM_CupSetScoring', jsonEncode({ bonus = { [key] = n } }))
  end
end

-- What a DNF is worth: 'none', 'classified' (its place in the final order) or
-- 'held' (the place it was running in when it stopped).
function M.cupSetDnfScoring(mode)
  mode = tostring(mode or 'none')
  if mode ~= 'none' and mode ~= 'classified' and mode ~= 'held' then return end
  if inMultiplayer() then
    TriggerServerEvent('RM_CupSetScoring', jsonEncode({ dnfScoring = mode }))
  end
end

function M.cupSetFastestLapRule(required)
  if inMultiplayer() then
    TriggerServerEvent('RM_CupSetScoring',
      jsonEncode({ fastestLapRequiresFinish = required and true or false }))
  end
end

-- --- Driver identity (admin-controlled) ------------------------------------
-- Assign a connected player to a roster entry, which is how a driver gets
-- their name and their accumulated points back after a reconnect. An admin has
-- to do this: BeamMP issues a fresh random guest name on every join, so nothing
-- on either side can tell a returning regular from a stranger.
--
-- entryId 0 unassigns.
-- Put a driver on the roster who is not connected. A league's entry list is
-- known before the night; typing it in advance is what turns naming somebody on
-- race night into picking a name instead of spelling it.
function M.rosterAdd(name)
  name = tostring(name or '')
  if name == '' then return end
  if not inMultiplayer() then
    editorMsg('The roster needs a BeamMP server')
    return
  end
  TriggerServerEvent('RM_RosterAdd', jsonEncode({ name = name }))
end

function M.cupBindDriver(targetPid, entryId)
  targetPid = tonumber(targetPid)
  if not targetPid or targetPid < 0 then return end
  if not inMultiplayer() then
    editorMsg('Driver assignment needs a BeamMP server')
    return
  end
  TriggerServerEvent('RM_CupBindDriver', jsonEncode({
    pid     = math.floor(targetPid),
    entryId = math.floor(tonumber(entryId) or 0),
  }))
end

function M.cupForgetDriver(entryId)
  entryId = tonumber(entryId)
  if not entryId then return end
  if inMultiplayer() then
    TriggerServerEvent('RM_CupForgetDriver', jsonEncode({ entryId = math.floor(entryId) }))
  end
end

-- --- Manual adjustments ----------------------------------------------------
-- Correcting a cup by hand: a penalty, a driver who dropped out through no
-- fault of their own, a race administered badly. Keyed on the CUP ENTRY, not on
-- a session id, so an adjustment lands on the driver rather than on whoever
-- currently holds that connection.
function M.cupAdjust(entryId, delta, reason)
  entryId = tonumber(entryId)
  delta   = tonumber(delta)
  if not entryId or not delta or delta == 0 then return end
  if inMultiplayer() then
    TriggerServerEvent('RM_CupAdjust', jsonEncode({
      entryId = math.floor(entryId),
      delta   = math.floor(delta),
      reason  = tostring(reason or ''),
    }))
  end
end

function M.cupRemoveAdjust(entryId, index)
  entryId = tonumber(entryId)
  index   = tonumber(index)
  if not entryId or not index then return end
  if inMultiplayer() then
    TriggerServerEvent('RM_CupRemoveAdjust', jsonEncode({
      entryId = math.floor(entryId), index = math.floor(index),
    }))
  end
end

function M.cupDropRound(entryId, round)
  entryId = tonumber(entryId)
  round   = tonumber(round)
  if not entryId or not round then return end
  if inMultiplayer() then
    TriggerServerEvent('RM_CupDropRound', jsonEncode({
      entryId = math.floor(entryId), round = math.floor(round),
    }))
  end
end

function M.requestState()
  pushRouteState()
  if inMultiplayer() then
    TriggerServerEvent('RM_RequestState', '')
    TriggerServerEvent('RM_RequestLayouts', '')
    TriggerServerEvent('RM_CupRequestState', '')
  else
    -- Not on a BeamMP server: still push a state so the UI renders, and the
    -- editor remains fully usable for building circuits offline. Grant local
    -- admin so the (offline) editor controls are visible without a password.
    -- The flag has to be set here too, not just announced to the UI: every
    -- later route push carries it, and a push saying "not admin" would take the
    -- offline editor's own controls away again on the next gate placed.
    session.isAdmin = true
    guihooks.trigger('RaceManagerUpdate', { phase = 'waiting', raceTime = 0, totalLaps = session.totalLaps, drivers = {} })
    guihooks.trigger('RaceManagerAuth', { success = true, offline = true })
    log('W', 'raceManager', 'Racing is multiplayer-only; the checkpoint editor works offline')
  end
end

-- Server -> client event wiring. Handlers are reached through a GLOBAL
-- dispatch table that every (re)load of this extension overwrites: older
-- BeamMP builds have an AddEventHandler with no matching remove, so registering
-- the local closures directly left every previous instance's handlers alive
-- across a reload - a stale instance pushing its own (empty) state to the UI
-- between the live instance's pushes is one way the UI ends up flickering
-- between two states. With the indirection the bridge binds to BeamMP exactly
-- once per game session and always dispatches into the newest instance's
-- handlers.
--
-- Recent BeamMP builds also key handlers by a SOURCE and replace (rather than
-- stack) a re-registration from the same source. That source defaults to
-- whatever debug.getinfo() makes of the calling file, so it is passed
-- explicitly below: with a fixed source the binding is idempotent on those
-- builds even if the global guard is lost, and older builds simply ignore the
-- extra argument.
local HANDLER_SOURCE = 'raceManager'
local DISPATCH = {
  RM_Practice        = onPractice,
  RM_Update          = onServerUpdate,
  RM_Countdown       = onServerCountdown,
  RM_Layouts         = onLayoutList,
  RM_ApplyLayout     = onApplyLayout,
  RM_SaveHeld        = onSaveHeld,
  RM_ClearTrack      = onClearTrack,
  RM_LoginResult     = onLoginResult,
  RM_PasswordChanged = onPasswordChanged,
  -- Module 1: forced spectator mode (used by racing and, separately, by derby)
  RM_ForceSpectate   = onForceSpectate,
  RM_ReleaseSpectate = onReleaseSpectate,
  -- Module 4: garage list enforcement feedback
  RM_VehicleRejected = onVehicleRejected,
  RM_GarageResult    = onGarageResult,
  RM_AliasResult     = onAliasResult,
  -- Starting grid: the server hands out slots, this client places the car.
  RM_GridAssign      = onGridAssign,
  -- Reset ghosting: someone's car went intangible (or came back).
  RM_Ghost           = onGhost,
  -- A derby car coming back on a life: everyone ghosts it while it lands.
  RM_DerbyGhost      = ghost.onDerbyRespawn,
  -- Grid hold: the server pulling a car back onto its slot.
  RM_HoldCorrect     = onHoldCorrect,
  -- Something the FIELD needs to read, pushed by the server.
  RM_Notice          = onNotice,
  -- A lap handed to this driver without a crossing (the caution's free pass).
  RM_LapCredit       = onLapCredit,
  -- Cup / series points
  RM_CupUpdate       = onCupUpdate,
  -- A copy of a results file, for an admin who cannot reach the server's.
  RM_ResultsFile     = M.onResultsFile,
  -- Demo Derby module
  RM_DerbyUpdate     = derby.onDerbyUpdate,
  RM_DerbyLayouts    = derby.onDerbyLayoutList,
  RM_DerbyGridAssign = derby.onDerbyGridAssign,
  RM_DerbyLifeLost   = derby.onDerbyLifeLost,
  RM_DerbyCountdown  = derby.onDerbyCountdown,
  -- Drag racing module
  RM_DragUpdate      = drag.onDragUpdate,
  RM_DragLane        = drag.onDragLane,
  RM_DragTree        = drag.onDragTree,
  RM_DragTreeWatch   = drag.onDragTreeWatch,
  RM_DragAborted     = drag.onDragAborted,
}

local function bindServerHandlers()
  if not (inMultiplayer() and AddEventHandler) then return false end
  rawset(_G, 'raceManagerDispatch', DISPATCH)
  if rawget(_G, 'raceManagerHandlersBound') then return true end
  rawset(_G, 'raceManagerHandlersBound', true)
  for name in pairs(DISPATCH) do
    AddEventHandler(name, function (rawData)
      local d = rawget(_G, 'raceManagerDispatch')
      local fn = d and d[name]
      if fn then fn(rawData) end
    end, HANDLER_SOURCE)
  end
  return true
end

-- A RESET THE INPUT FILTER SWALLOWED.
--
-- Once the allowance is spent the reset actions are filtered out in C++, so the
-- key press never becomes a vehicle reset and onVehicleResetted never fires.
-- That is deliberate -- a reset REPAIRS the car, and letting it through and
-- teleporting the car back afterwards would hand out free repairs -- but it
-- also meant the driver pressed reset and got nothing at all: no movement, no
-- message, no way to tell the rule from a broken key.
--
-- INERT ON THE CURRENT BUILD, and kept anyway.
--
-- This was the one place a swallowed press looked like it might still be
-- visible, and a live session settled it: BeamNG does NOT deliver filtered
-- actions here. The filtering happens in C++ inside ActionMap, and a blocked
-- action is dropped before any Lua hook runs -- onFilteredInputChanged means
-- "input that got through the filter", not "input the filter stopped".
--
-- Not deleted, because it costs one boolean test per input event and it is the
-- exact shape the answer would take if a future build ever did route blocked
-- actions through a hook. The panel carries a standing OUT marker instead,
-- which needs nothing from the engine.
--
-- Guarded on block.resetInputs first, which is false for almost the whole of
-- every session: an analog axis fires this hook constantly and nothing below
-- the guard should run for steering.
function M.onFilteredInputChanged(devName, action, value)
  if not block.resetInputs then return end
  -- Presses only. Releases come through as 0 and are not a second attempt.
  if not value or value <= 0 then return end
  if type(action) ~= 'string' then return end
  local wanted = false
  for i = 1, #block.RESET_ACTIONS do
    if block.RESET_ACTIONS[i] == action then wanted = true; break end
  end
  if not wanted then return end
  if block.noticeLeft > 0 then return end
  block.noticeLeft = block.NOTICE_EVERY
  -- Recorded on the server as well, so a driver leaning on the key still shows
  -- up in the live table and the results the same way a reset the filter could
  -- not see already does.
  if inMultiplayer() then TriggerServerEvent('RM_ResetDenied', '') end
  if derbyResetsEnforced() then
    pushNotice('resetsout', "Uh oh! You're out of resets",
      { sub = 'All ' .. derbyResets.max .. ' derby resets used', color = 'amber' })
  elseif session.maxResets == 0 then
    pushNotice('resetsout', 'No resets in this session',
      { sub = 'You are on your own out there', color = 'amber' })
  else
    pushNotice('resetsout', "Uh oh! You're out of resets",
      { sub = 'All ' .. session.maxResets .. ' used', color = 'amber' })
  end
  log('W', 'raceManager', 'Reset key pressed with no allowance left (input filtered)')
end

function M.onExtensionLoaded()
  bindServerHandlers()
  log('I', 'raceManager', 'Race Manager client bridge loaded (build ' .. RM_BUILD
    .. ', multiplayer=' .. tostring(inMultiplayer()) .. ')')
end

-- Everything this client enforces locally, switched off. Called both when the
-- extension is unloaded and when the BeamMP session ends (see below), because
-- every one of these is a rule the SERVER owns and only this client can apply -
-- with no server left to lift them they would otherwise stay applied.
local function resetToIdle(reason)
  session.phase = 'waiting'
  -- The server drops authenticatedPlayers on disconnect, so a session that has
  -- ended takes the admin rights with it. Forget them here or the next server
  -- would inherit an admin flag it never granted.
  session.isAdmin = false
  edit.open = false
  clearTrackState(reason)
  releaseSpectator(nil)
  -- No more update ticks are coming, so anything the placement queue still owes
  -- this driver -- their car, their camera, their collisions -- is settled now.
  flushFieldPlacement()
  releaseGridHold()
  clearGhostReasons()
  setResetInputsBlocked(false)   -- never leave the reset keys dead after unload
  spectate.setPropulsionBlocked(false)  -- nor the throttle
  -- Same rule for the two filters this mod added. Unloading with the driving or
  -- the node grabber still filtered off would leave the player in a car they
  -- cannot drive with nothing on screen explaining why -- and nothing left
  -- loaded that could give it back.
  spectate.setInputsBlocked(false)
  spectate.setGrabberBlocked(false)
  holdWanted = nil               -- nothing is meant to be held any more
  session.maxResets       = -1
  session.resetsUsed      = 0
  session.resetMode       = 'inplace'
  lastGate        = nil
  block.selfTeleport.left = 0
  block.noticeLeft = 0
  session.jokerEnabled    = false
  -- Both halves of the pace lap. The rule as much as the condition: it belongs
  -- to the server that granted it, and a client that carried it to the next
  -- server would count that server's races one lap long.
  session.paceLap         = false
  session.pacing          = false
  session.caution         = false
  session.cautionLaps     = 0
  session.cautionPending  = false
  session.restartPending  = false
  session.beingLapped     = false
  session.lappingAhead    = false
  session.heatCount       = 0
  session.heatCurrent     = 0
  session.heatLaps        = 0
  session.myHeat          = nil
  track.pitRoute        = {}
  pit.active      = false
  pit.left        = 0
  pit.settleLeft  = 0
  pit.cooldown    = 0
  pit.promptLeft  = 0
  -- clearGhostReasons above has already swept every car in the world clean, so
  -- this is only dropping our record of what we ghosted -- left set, the next
  -- stop would think it was already ghosted and never ghost at all.
  pit.ghostVeh    = nil
  pit.ghostSent   = false
  edit.target    = 'main'
  lastReportedSig = nil
  session.gridSlot        = nil
  finalLap        = false
  ghostQuali      = false
  -- Same purge for the isolated derby module: markers and warnings must not
  -- survive into the next session.
  derby.derbyState.phase    = 'idle'
  derby.derbyState.boundary = {}
  derby.derbyState.boundaryMode = 'polygon'
  derby.derbyState.shape    = nil
  derby.derbyState.editorOpen = false
  -- Not invalidation (the empty table above already is that) -- this drops the
  -- cache's reference to the arena that has just gone, so it can be collected.
  derby.derbyState.draw     = nil
  derby.derbyState.starts   = {}
  derby.derbyState.slot     = nil
  derby.derbyState.out      = false
  derbyResets.max  = -1
  derbyResets.used = 0
  derby.derbyClearWarnings()
  -- clearTrackState pushed a state part-way through the purge, while the
  -- regulation values below it were still the old ones. Push again now that
  -- everything is actually idle, or the UI keeps showing the allowance and the
  -- entry status of a session that has ended.
  pushRouteState()
end

function M.onExtensionUnloaded()
  -- The extension stays resident across sessions (manual unload mode), so an
  -- explicit purge here is what stops checkpoints leaking into the next one.
  resetToIdle('extension unloaded')
end

-- ---------------------------------------------------------------------------
-- BeamMP session lifecycle
-- ---------------------------------------------------------------------------
-- Leaving a BeamMP server used to leave this client mid-race forever. Every
-- regulation the server owns is APPLIED here - the reset keys are switched off
-- at the input filter, the car is frozen on its grid slot, a finished or
-- eliminated driver is held in freecam - and all of them are lifted by a
-- server broadcast that is never coming once the session is gone. A driver who
-- disconnected mid-race was dropped back into singleplayer with a dead reset
-- key and, if they had finished or been knocked out, no car and a camera that
-- reasserted freecam every second.
--
-- BeamMP hooks every extension when a session starts and ends, so that is the
-- signal to purge. v4.22.0 renamed those hooks with an onBeamMP* prefix
-- (onServerLeave -> onBeamMPServerLeave, runPostJoin -> onBeamMPPostJoin);
-- both names are registered, so whichever BeamMP build is installed, the mod
-- hears it. Only one of the pair fires on any given build, and a second purge
-- would be harmless anyway.
local function onSessionLeave()
  log('I', 'raceManager', 'BeamMP session ended: clearing local race state')
  nametag.clearAll()
  resetToIdle('BeamMP session ended')
end

M.onBeamMPServerLeave = onSessionLeave   -- BeamMP v4.22.0+
M.onServerLeave       = onSessionLeave   -- BeamMP v4.21.1 and earlier

-- Joining is the other half: the extension can be mounted and loaded before
-- BeamMP's own network extension is ready, in which case onExtensionLoaded
-- bound nothing and the mod would sit deaf for the whole session. Binding again
-- here closes that race (the bind is guarded, and on builds that key handlers
-- by source it is idempotent regardless). The state request is deferred a beat
-- rather than sent immediately, because the launcher socket is still being
-- brought up as this hook runs.
local function onSessionJoin()
  bindServerHandlers()
  joinRequestLeft = 1.0
  log('I', 'raceManager', 'BeamMP session joined: handlers bound, requesting state')
end

M.onBeamMPPostJoin = onSessionJoin       -- BeamMP v4.22.0+
M.runPostJoin      = onSessionJoin       -- BeamMP v4.21.1 and earlier
end

return M
